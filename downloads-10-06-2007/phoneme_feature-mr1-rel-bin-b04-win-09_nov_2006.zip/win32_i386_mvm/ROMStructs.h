/*
 * Copyright  1990-2006 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation. 
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt). 
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA 
 * 
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa
 * Clara, CA 95054 or visit www.sun.com if you need additional
 * information or have any questions. 
 */

/* This file is auto-generated. Do not edit*/



#ifndef _ROM_STRUCTS_H_
#define _ROM_STRUCTS_H_

#ifdef __cplusplus
extern "C" {
#endif
#define _ROM_STRUCTS_VERSION_ "b04-0611091812"

/* Define JVM_LIMIT_OBJECT_FIELD_WRITES=0 if your C
   compiler does not allow the 'const' modifier
   in the ROM structs */
#ifndef JVM_LIMIT_OBJECT_FIELD_WRITES
#define JVM_LIMIT_OBJECT_FIELD_WRITES 0 /* IMPL_NOTE: TMP */
#endif
#if !JVM_LIMIT_OBJECT_FIELD_WRITES
#define JVM_FIELD_CONST
#else
#define JVM_FIELD_CONST const
#endif

typedef struct {
    void * dummy;
    int length;
    jboolean elements[1];
} jboolean_array;
typedef struct {
    void * dummy;
    int length;
    jchar elements[1];
} jchar_array;
typedef struct {
    void * dummy;
    int length;
    jbyte elements[1];
} jbyte_array;
typedef struct {
    void * dummy;
    int length;
    jshort elements[1];
} jshort_array;
typedef struct {
    void * dummy;
    int length;
    jint elements[1];
} jint_array;
typedef struct {
    void * dummy;
    int length;
    jlong elements[1];
} jlong_array;
typedef struct {
    void * dummy;
    int length;
    struct Java_java_lang_Object * JVM_FIELD_CONST elements[1];
} jobject_array;
typedef struct {
    void * dummy;
    int length;
    jfloat elements[1];
} jfloat_array;
typedef struct {
    void * dummy;
    int length;
    jdouble elements[1];
} jdouble_array;

struct Java_java_lang_Object {
    /* java/lang/Object */
	void * __do_not_use__;
};

struct Java_java_lang_String {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/String */
    /*  @4 */	jchar_array * JVM_FIELD_CONST value;
    /*  @8 */	jint offset;
    /* @12 */	jint count;
};

struct Java_java_lang_Class {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Class */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST vmClass;
    /*  @8 */	jint status;
    /* @12 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
};

struct Java_java_lang_StringBuffer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/StringBuffer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST value;
    /*  @8 */	jint count;
    /* @12 */	jboolean shared;
    /* @13 */	jbyte ___pad1;
    /* @14 */	jbyte ___pad2;
    /* @15 */	jbyte ___pad3;
};

struct Java_java_lang_Thread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
};

struct Java_java_lang_Throwable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
};

struct Java_java_lang_Error {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
};

struct Java_java_io_InputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
};

struct Java_java_lang_Runtime {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Runtime */
};

struct Java_java_io_OutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
};

struct Java_java_io_PrintStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/PrintStream */
    /*  @4 */	struct Java_java_io_OutputStreamWriter * JVM_FIELD_CONST charOut;
    /*  @8 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST byteOut;
    /* @12 */	jboolean trouble;
    /* @13 */	jboolean closing;
    /* @14 */	jbyte ___pad4;
    /* @15 */	jbyte ___pad5;
};

struct Java_java_lang_System {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/System */
};

struct Java_java_lang_Math {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Math */
};

struct Java_com_sun_cldchi_jvm_JVM {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldchi/jvm/JVM */
};

struct Java_com_sun_cldchi_jvm_FileDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldchi/jvm/FileDescriptor */
    /*  @4 */	jint handle;
    /*  @8 */	jint valid;
};

struct Java_java_lang_ref_Reference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/ref/Reference */
};

struct Java_java_lang_ref_WeakReference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/ref/Reference */
    /* java/lang/ref/WeakReference */
    /*  @4 */	jint referent_index;
};

struct Java_java_lang_VirtualMachineError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/VirtualMachineError */
};

struct Java_java_lang_OutOfMemoryError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/VirtualMachineError */
    /* java/lang/OutOfMemoryError */
};

struct Java_java_lang_Runnable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Runnable */
};

struct Java_java_lang_Exception {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
};

struct Java_java_lang_RuntimeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
};

struct Java_java_lang_NullPointerException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/NullPointerException */
};

struct Java_java_lang_IndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
};

struct Java_java_lang_ArrayIndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
    /* java/lang/ArrayIndexOutOfBoundsException */
};

struct Java_java_lang_IllegalMonitorStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalMonitorStateException */
};

struct Java_java_lang_ArithmeticException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ArithmeticException */
};

struct Java_com_sun_cldc_isolate_Isolate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Isolate */
    /*  @4 */	jint _priority;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST _next;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST _uniqueId;
    /* @16 */	jint _terminated;
    /* @20 */	jint _saved_exit_code;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST _mainClass;
    /* @28 */	jobject_array * JVM_FIELD_CONST _mainArgs;
    /* @32 */	jobject_array * JVM_FIELD_CONST _classpath;
    /* @36 */	jint _memoryReserve;
    /* @40 */	jint _memoryLimit;
    /* @44 */	jint _APIAccess;
    /* @48 */	jint _ConnectDebugger;
    /* @52 */	jint _UseVerifier;
    /* @56 */	jint _profileId;
};

struct Java_java_lang_IllegalArgumentException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
};

struct Java_java_io_IOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
};

struct Java_com_sun_cldc_io_ResourceInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/cldc/io/ResourceInputStream */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST fileDecoder;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST savedDecoder;
};

struct Java_java_lang_InterruptedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/InterruptedException */
};

struct Java_java_lang_NoClassDefFoundError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/NoClassDefFoundError */
};

struct Java_com_sun_cldc_isolate_IsolateResourceError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* com/sun/cldc/isolate/IsolateResourceError */
};

struct Java_com_sun_cldc_isolate_IsolateStartupException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/cldc/isolate/IsolateStartupException */
};

struct Java_java_lang_SecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/SecurityException */
};

struct Java_java_lang_StringIndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
    /* java/lang/StringIndexOutOfBoundsException */
};

struct Java_com_sun_cldc_util_SemaphoreLock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/util/SemaphoreLock */
    /*  @4 */	jint permits;
};

struct Java_com_sun_cldc_util_Semaphore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/util/Semaphore */
    /*  @4 */	struct Java_com_sun_cldc_util_SemaphoreLock * JVM_FIELD_CONST lock;
};

struct Java_java_io_Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
};

struct Java_com_sun_cldc_i18n_StreamReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_java_io_Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
};

struct Java_com_sun_cldc_i18n_StreamWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
};

struct Java_com_sun_cldc_i18n_Helper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/Helper */
};

struct Java_java_io_UnsupportedEncodingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/UnsupportedEncodingException */
};

struct Java_java_lang_ClassCastException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ClassCastException */
};

struct Java_java_lang_ClassNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/ClassNotFoundException */
};

struct Java_java_lang_InstantiationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/InstantiationException */
};

struct Java_java_lang_IllegalAccessException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/IllegalAccessException */
};

struct Java_java_io_ByteArrayInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* java/io/ByteArrayInputStream */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint pos;
    /* @12 */	jint mark;
    /* @16 */	jint count;
};

struct Java_java_io_ByteArrayOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/ByteArrayOutputStream */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint count;
    /* @12 */	jboolean isClosed;
    /* @13 */	jbyte ___pad6;
    /* @14 */	jbyte ___pad7;
    /* @15 */	jbyte ___pad8;
};

struct Java_com_sun_cldc_i18n_j2me_Conv {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/j2me/Conv */
};

struct Java_com_sun_cldc_i18n_j2me_Gen_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/Gen_Reader */
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST enc;
    /* @20 */	jint id;
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint maxByteLen;
    /* @32 */	jbyte_array * JVM_FIELD_CONST tmp;
    /* @36 */	jint pos;
};

struct Java_com_sun_cldc_i18n_j2me_Gen_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/Gen_Writer */
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST enc;
    /* @24 */	jint id;
    /* @28 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @32 */	jint maxByteLen;
};

struct Java_com_sun_cldc_i18n_j2me_ISO8859_11_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/ISO8859_1_Reader */
};

struct Java_com_sun_cldc_i18n_j2me_ISO8859_11_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/ISO8859_1_Writer */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_8_Reader */
    /* @16 */	jint_array * JVM_FIELD_CONST readAhead;
    /* @20 */	jboolean newRead;
    /* @21 */	jbyte ___pad9;
    /* @22 */	jbyte ___pad10;
    /* @23 */	jbyte ___pad11;
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_8_Writer */
};

struct Java_com_sun_cldc_i18n_uclc_DefaultCaseConverter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/uclc/DefaultCaseConverter */
};

struct Java_javax_microedition_io_Connection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Connection */
};

struct Java_com_sun_cldc_io_ConnectionBaseInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/io/ConnectionBaseInterface */
};

struct Java_com_sun_cldc_isolate_IllegalIsolateStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* com/sun/cldc/isolate/IllegalIsolateStateException */
};

struct Java_com_sun_cldc_isolate_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Util */
};

struct Java_com_sun_cldc_isolate_Verifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Verifier */
};

struct Java_java_util_TimeZone {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimeZone */
};

struct Java_java_util_Date {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Date */
    /*  @4 */	struct Java_java_util_Calendar * JVM_FIELD_CONST calendar;
    /*  @8 */	jlong fastTime;
};

struct Java_java_util_Calendar {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Calendar */
    /*  @4 */	jint_array * JVM_FIELD_CONST fields;
    /*  @8 */	jboolean_array * JVM_FIELD_CONST isSet;
    /* @12 */	jlong time;
    /* @20 */	struct Java_java_util_TimeZone * JVM_FIELD_CONST zone;
    /* @24 */	struct Java_java_util_Date * JVM_FIELD_CONST dateObj;
    /* @28 */	jboolean isTimeSet;
    /* @29 */	jbyte ___pad12;
    /* @30 */	jbyte ___pad13;
    /* @31 */	jbyte ___pad14;
};

struct Java_com_sun_cldc_util_j2me_CalendarImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Calendar */
    /*  @4 */	jint_array * JVM_FIELD_CONST fields;
    /*  @8 */	jboolean_array * JVM_FIELD_CONST isSet;
    /* @12 */	jlong time;
    /* @20 */	struct Java_java_util_TimeZone * JVM_FIELD_CONST zone;
    /* @24 */	struct Java_java_util_Date * JVM_FIELD_CONST dateObj;
    /* @28 */	jboolean isTimeSet;
    /* @29 */	jbyte ___pad15;
    /* @30 */	jbyte ___pad16;
    /* @31 */	jbyte ___pad17;
    /* com/sun/cldc/util/j2me/CalendarImpl */
};

struct Java_com_sun_cldc_util_j2me_TimeZoneImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimeZone */
    /* com/sun/cldc/util/j2me/TimeZoneImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST ID;
    /*  @8 */	jint startMonth;
    /* @12 */	jint startDay;
    /* @16 */	jint startDayOfWeek;
    /* @20 */	jint startTime;
    /* @24 */	jint endMonth;
    /* @28 */	jint endDay;
    /* @32 */	jint endDayOfWeek;
    /* @36 */	jint endTime;
    /* @40 */	jint startYear;
    /* @44 */	jint rawOffset;
    /* @48 */	jint startMode;
    /* @52 */	jint endMode;
    /* @56 */	jint dstSavings;
    /* @60 */	jboolean isCustom;
    /* @61 */	jboolean useDaylight;
    /* @62 */	jbyte ___pad18;
    /* @63 */	jbyte ___pad19;
};

struct Java_com_sun_cldchi_io_ConsoleOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/cldchi/io/ConsoleOutputStream */
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteStorage */
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteImpl */
    /*  @4 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /*  @8 */	struct Java_com_sun_midp_security_SecurityHandler * JVM_FIELD_CONST securityHandler;
    /* @12 */	struct Java_com_sun_midp_midletsuite_SuiteProperties * JVM_FIELD_CONST suiteProperties;
    /* @16 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST suiteSettings;
    /* @20 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet_1_name;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet_1_class;
    /* @36 */	jint numberOfMidlets;
    /* @40 */	jboolean locked;
    /* @41 */	jbyte ___pad20;
    /* @42 */	jbyte ___pad21;
    /* @43 */	jbyte ___pad22;
};

struct Java_javax_microedition_lcdui_Image {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Image */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	struct Java_javax_microedition_lcdui_ImageData * JVM_FIELD_CONST imageData;
};

struct Java_javax_microedition_lcdui_Item {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
};

struct Java_com_sun_midp_midletsuite_InstallInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/InstallInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST jadUrl;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST jarUrl;
    /* @12 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @20 */	jbyte_array * JVM_FIELD_CONST verifyHash;
    /* @24 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST midletSuite;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @32 */	jboolean trusted;
    /* @33 */	jbyte ___pad23;
    /* @34 */	jbyte ___pad24;
    /* @35 */	jbyte ___pad25;
};

struct Java_com_sun_midp_midlet_MIDletStateHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletStateHandler */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /*  @8 */	jobject_array * JVM_FIELD_CONST midlets;
    /* @12 */	jint nmidlets;
    /* @16 */	jint scanIndex;
    /* @20 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /* @24 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @28 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
};

struct Java_javax_microedition_lcdui_Screen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad26;
    /* @30 */	jbyte ___pad27;
    /* @31 */	jbyte ___pad28;
    /* javax/microedition/lcdui/Screen */
};

struct Java_javax_microedition_lcdui_LFFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFFactory */
};

struct Java_javax_microedition_lcdui_Form {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad29;
    /* @30 */	jbyte ___pad30;
    /* @31 */	jbyte ___pad31;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
};

struct Java_javax_microedition_lcdui_FormLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/FormLF */
};

struct Java_javax_microedition_lcdui_DisplayableLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLF */
};

struct Java_javax_microedition_lcdui_ItemStateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemStateListener */
};

struct Java_javax_microedition_lcdui_Ticker {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Ticker */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST message;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayedMessage;
    /* @12 */	struct Java_javax_microedition_lcdui_TickerLF * JVM_FIELD_CONST tickerLF;
};

struct Java_javax_microedition_lcdui_Command {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Command */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST shortLabel;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST longLabel;
    /* @12 */	jint commandType;
    /* @16 */	jint priority;
    /* @20 */	jint id;
};

struct Java_javax_microedition_lcdui_CommandListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CommandListener */
};

struct Java_javax_microedition_lcdui_Displayable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad32;
    /* @30 */	jbyte ___pad33;
    /* @31 */	jbyte ___pad34;
};

struct Java_com_sun_midp_appmanager_ApplicationManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/ApplicationManager */
};

struct Java_com_sun_midp_appmanager_AppInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad35;
    /* @30 */	jbyte ___pad36;
    /* @31 */	jbyte ___pad37;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppInfo */
    /* @48 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST suiteIcon;
    /* @52 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST singleSuiteIcon;
    /* @56 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @60 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @64 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @68 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @72 */	jint numberOfMidlets;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteCorruptedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/midletsuite/MIDletSuiteCorruptedException */
};

struct Java_javax_microedition_lcdui_ImageItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/ImageItem */
    /* @44 */	struct Java_javax_microedition_lcdui_ImageItemLF * JVM_FIELD_CONST imageItemLF;
    /* @48 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST immutableImg;
    /* @52 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImg;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST altText;
    /* @60 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_ImageItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageItemLF */
};

struct Java_javax_microedition_lcdui_ItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLF */
};

struct Java_javax_microedition_lcdui_ItemCommandListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemCommandListener */
};

struct Java_javax_microedition_lcdui_StringItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/StringItem */
    /* @44 */	struct Java_javax_microedition_lcdui_StringItemLF * JVM_FIELD_CONST stringItemLF;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST str;
    /* @52 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @56 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_StringItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/StringItemLF */
};

struct Java_javax_microedition_lcdui_Font {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Font */
    /*  @4 */	jint face;
    /*  @8 */	jint style;
    /* @12 */	jint size;
    /* @16 */	jint baseline;
    /* @20 */	jint height;
};

struct Java_com_sun_midp_appmanager_AppManagerUI {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad38;
    /* @30 */	jbyte ___pad39;
    /* @31 */	jbyte ___pad40;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppManagerUI */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchInstallCmd;
    /* @56 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCaManagerCmd;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST infoCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST updateCmd;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST appSettingsCmd;
    /* @80 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @84 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeOkCmd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @92 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST fgCmd;
    /* @96 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @100 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @104 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @108 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @112 */	jlong lastDisplayChange;
    /* @120 */	struct Java_com_sun_midp_appmanager_MIDletSuiteInfo * JVM_FIELD_CONST removeMsi;
    /* @124 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST appManagerMidlet;
    /* @128 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @132 */	jboolean caManagerIncluded;
    /* @133 */	jbyte ___pad41;
    /* @134 */	jbyte ___pad42;
    /* @135 */	jbyte ___pad43;
};

struct Java_com_sun_midp_main_MIDletProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxy */
    /*  @4 */	jint externalId;
    /*  @8 */	jint isolateId;
    /* @12 */	jint displayId;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @28 */	jint midletState;
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST preempting;
    /* @36 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST preempted;
    /* @40 */	struct Java_java_util_Timer * JVM_FIELD_CONST proxyTimer;
    /* @44 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST parent;
    /* @48 */	jboolean wantsForegroundState;
    /* @49 */	jboolean alertWaiting;
    /* @50 */	jbyte ___pad44;
    /* @51 */	jbyte ___pad45;
};

struct Java_com_sun_midp_appmanager_MIDletSuiteInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSuiteInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @24 */	jboolean singleMidlet;
    /* @25 */	jboolean enabled;
    /* @26 */	jbyte ___pad46;
    /* @27 */	jbyte ___pad47;
};

struct Java_com_sun_midp_appmanager_AppManagerUI_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSuiteInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @24 */	jboolean singleMidlet;
    /* @25 */	jboolean enabled;
    /* @26 */	jbyte ___pad48;
    /* @27 */	jbyte ___pad49;
    /* com/sun/midp/appmanager/AppManagerUI$1 */
    /* @28 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_CustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
};

struct Java_javax_microedition_lcdui_CustomItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CustomItemLF */
};

struct Java_javax_microedition_lcdui_Graphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Graphics */
    /*  @4 */	jint transX;
    /*  @8 */	jint transY;
    /* @12 */	jint ax;
    /* @16 */	jint ay;
    /* @20 */	jint rgbColor;
    /* @24 */	jint gray;
    /* @28 */	jint pixel;
    /* @32 */	jint style;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST currentFont;
    /* @40 */	jint displayId;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST img;
    /* @48 */	jshort clipX1;
    /* @50 */	jshort clipY1;
    /* @52 */	jshort clipX2;
    /* @54 */	jshort clipY2;
    /* @56 */	jshort systemClipX1;
    /* @58 */	jshort systemClipY1;
    /* @60 */	jshort systemClipX2;
    /* @62 */	jshort systemClipY2;
    /* @64 */	jshort maxWidth;
    /* @66 */	jshort maxHeight;
    /* @68 */	jboolean clipped;
    /* @69 */	jboolean runtimeClipEnforce;
    /* @70 */	jbyte ___pad50;
    /* @71 */	jbyte ___pad51;
};

struct Java_com_sun_midp_appmanager_AppManagerUI_0004MidletCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AppManagerUI$MidletCustomItem */
    /* @48 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @52 */	struct Java_com_sun_midp_appmanager_MIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @68 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST this_0440;
    /* @72 */	jboolean hasFocus;
    /* @73 */	jbyte ___pad52;
    /* @74 */	jbyte ___pad53;
    /* @75 */	jbyte ___pad54;
};

struct Java_javax_microedition_lcdui_Display {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display */
    /*  @4 */	jint displayId;
    /*  @8 */	struct Java_javax_microedition_lcdui_Display_0004DisplayAccessImpl * JVM_FIELD_CONST accessor;
    /* @12 */	struct Java_javax_microedition_lcdui_Display_0004DisplayEventConsumerImpl * JVM_FIELD_CONST consumer;
    /* @16 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST cham_tunnel;
    /* @20 */	jint_array * JVM_FIELD_CONST region;
    /* @24 */	struct Java_com_sun_midp_midlet_MIDletEventConsumer * JVM_FIELD_CONST midletEventConsumer;
    /* @28 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @32 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST screenGraphics;
    /* @36 */	jint wantsForeground;
    /* @40 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST current;
    /* @44 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST transitionCurrent;
    /* @48 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST pendingCurrent;
    /* @52 */	struct Java_com_sun_midp_chameleon_MIDPWindow * JVM_FIELD_CONST window;
    /* @56 */	struct Java_com_sun_midp_chameleon_CGraphicsQ * JVM_FIELD_CONST graphicsQ;
    /* @60 */	jboolean hasForeground;
    /* @61 */	jboolean paintSuspended;
    /* @62 */	jbyte ___pad55;
    /* @63 */	jbyte ___pad56;
};

struct Java_com_sun_midp_appmanager_DisplayError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/DisplayError */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
};

struct Java_javax_microedition_lcdui_AlertType {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AlertType */
    /*  @4 */	jint type;
};

struct Java_javax_microedition_lcdui_Alert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad57;
    /* @30 */	jbyte ___pad58;
    /* @31 */	jbyte ___pad59;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
};

struct Java_javax_microedition_rms_RecordStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordStore */
    /*  @4 */	struct Java_com_sun_midp_rms_RecordStoreImpl * JVM_FIELD_CONST peer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST recordStoreName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteID;
    /* @16 */	jint opencount;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST recordListener;
};

struct Java_java_util_TimerTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
};

struct Java_java_util_Timer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Timer */
    /*  @4 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /*  @8 */	struct Java_java_util_TimerThread * JVM_FIELD_CONST thread;
};

struct Java_com_sun_midp_appmanager_SplashScreen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad60;
    /* @30 */	jbyte ___pad61;
    /* @31 */	jbyte ___pad62;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad63;
    /* @38 */	jbyte ___pad64;
    /* @39 */	jbyte ___pad65;
    /* com/sun/midp/appmanager/SplashScreen */
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST splashScreen;
    /* @44 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @48 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @52 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST timerTask;
    /* @56 */	struct Java_java_util_Timer * JVM_FIELD_CONST timeoutTimer;
};

struct Java_javax_microedition_lcdui_Canvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad66;
    /* @30 */	jbyte ___pad67;
    /* @31 */	jbyte ___pad68;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad69;
    /* @38 */	jbyte ___pad70;
    /* @39 */	jbyte ___pad71;
};

struct Java_javax_microedition_lcdui_CanvasLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CanvasLF */
};

struct Java_com_sun_midp_appmanager_RadioButtonSet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @48 */	jint choiceType;
    /* @52 */	jint fitPolicy;
    /* @56 */	jint numOfEls;
    /* @60 */	jobject_array * JVM_FIELD_CONST cgElements;
    /* com/sun/midp/appmanager/RadioButtonSet */
    /* @64 */	jint_array * JVM_FIELD_CONST ids;
};

struct Java_com_sun_midp_security_PermissionGroup {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionGroup */
    /*  @4 */	jint name;
    /*  @8 */	jint settingsQuestion;
    /* @12 */	jint disableSettingChoice;
    /* @16 */	jint runtimeDialogTitle;
    /* @20 */	jint runtimeQuestion;
    /* @24 */	jint runtimeOneshotQuestion;
    /* @28 */	jbyte identifiedMaxiumLevel;
    /* @29 */	jbyte identifiedDefaultLevel;
    /* @30 */	jbyte unidentifiedMaxiumLevel;
    /* @31 */	jbyte unidentifiedDefaultLevel;
};

struct Java_com_sun_midp_appmanager_AppSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad72;
    /* @30 */	jbyte ___pad73;
    /* @31 */	jbyte ___pad74;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppSettings */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveAppSettingsCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @56 */	jint displayedSettingID;
    /* @60 */	jint lastPopupChoice;
    /* @64 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST initialSetting;
    /* @68 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST settingsPopup;
    /* @72 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST interruptChoice;
    /* @76 */	jobject_array * JVM_FIELD_CONST groupSettings;
    /* @80 */	jint numberOfSettings;
    /* @84 */	jbyte_array * JVM_FIELD_CONST maxLevels;
    /* @88 */	jbyte_array * JVM_FIELD_CONST curLevels;
    /* @92 */	jint pushOptions;
    /* @96 */	jobject_array * JVM_FIELD_CONST groups;
    /* @100 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @104 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @108 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @112 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteDisplayName;
    /* @120 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST midletSuite;
    /* @124 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @128 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @132 */	jbyte pushInterruptSetting;
    /* @133 */	jbyte ___pad75;
    /* @134 */	jbyte ___pad76;
    /* @135 */	jbyte ___pad77;
};

struct Java_javax_microedition_rms_RecordStoreException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
};

struct Java_javax_microedition_lcdui_ChoiceGroup_0004CGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChoiceGroup$CGElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST stringEl;
    /*  @8 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST imageEl;
    /* @12 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImageEl;
    /* @16 */	struct Java_javax_microedition_lcdui_ImageData * JVM_FIELD_CONST imageDataEl;
    /* @20 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST fontEl;
    /* @24 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST this_0440;
    /* @28 */	jboolean selected;
    /* @29 */	jbyte ___pad78;
    /* @30 */	jbyte ___pad79;
    /* @31 */	jbyte ___pad80;
};

struct Java_javax_microedition_lcdui_ChoiceGroup {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @48 */	jint choiceType;
    /* @52 */	jint fitPolicy;
    /* @56 */	jint numOfEls;
    /* @60 */	jobject_array * JVM_FIELD_CONST cgElements;
};

struct Java_javax_microedition_lcdui_ChoiceGroupLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChoiceGroupLF */
};

struct Java_javax_microedition_lcdui_Choice {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Choice */
};

struct Java_javax_microedition_lcdui_AlertLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AlertLF */
};

struct Java_javax_microedition_lcdui_Gauge {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/Gauge */
    /* @44 */	struct Java_javax_microedition_lcdui_GaugeLF * JVM_FIELD_CONST gaugeLF;
    /* @48 */	jint value;
    /* @52 */	jint maxValue;
    /* @56 */	jboolean interactive;
    /* @57 */	jbyte ___pad81;
    /* @58 */	jbyte ___pad82;
    /* @59 */	jbyte ___pad83;
};

struct Java_com_sun_midp_appmanager_Ca {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/Ca */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	jboolean enabled;
    /*  @9 */	jboolean willBeEnabled;
    /* @10 */	jbyte ___pad84;
    /* @11 */	jbyte ___pad85;
};

struct Java_com_sun_midp_appmanager_CaManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/CaManager */
};

struct Java_com_sun_midp_publickeystore_WebPublicKeyStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
    /* com/sun/midp/publickeystore/WebPublicKeyStore */
};

struct Java_java_util_Vector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
};

struct Java_com_sun_midp_publickeystore_PublicKeyInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST owner;
    /*  @8 */	jlong notBefore;
    /* @16 */	jlong notAfter;
    /* @24 */	jbyte_array * JVM_FIELD_CONST modulus;
    /* @28 */	jbyte_array * JVM_FIELD_CONST exponent;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @36 */	jboolean enabled;
    /* @37 */	jbyte ___pad86;
    /* @38 */	jbyte ___pad87;
    /* @39 */	jbyte ___pad88;
};

struct Java_com_sun_midp_appmanager_CaForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad89;
    /* @30 */	jbyte ___pad90;
    /* @31 */	jbyte ___pad91;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/CaForm */
    /* @48 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST suiteStorage;
    /* @52 */	struct Java_java_util_Vector * JVM_FIELD_CONST disableSuites;
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST enableSuites;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST confirmCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST caList;
    /* @80 */	struct Java_com_sun_midp_appmanager_CaManager * JVM_FIELD_CONST parent;
    /* @84 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @88 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST choices;
    /* @92 */	jint firstIndex;
};

struct Java_com_sun_midp_security_SecurityToken {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityToken */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
};

struct Java_com_sun_midp_midletsuite_SuiteProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/SuiteProperties */
    /*  @4 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST properties;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
};

struct Java_com_sun_midp_midletsuite_SuiteSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/SuiteSettings */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
    /*  @8 */	jint pushOptions;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @16 */	jbyte pushInterruptSetting;
    /* @17 */	jboolean enabled;
    /* @18 */	jbyte ___pad92;
    /* @19 */	jbyte ___pad93;
};

struct Java_com_sun_midp_midlet_MIDletSuite {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletSuite */
};

struct Java_com_sun_midp_security_SecurityHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityHandler */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST permissionAsked;
    /* @12 */	jbyte_array * JVM_FIELD_CONST maxPermissionLevels;
    /* @16 */	jboolean trusted;
    /* @17 */	jbyte ___pad94;
    /* @18 */	jbyte ___pad95;
    /* @19 */	jbyte ___pad96;
};

struct Java_javax_microedition_midlet_MIDlet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
};

struct Java_com_sun_midp_midlet_MIDletPeer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletPeer */
    /*  @4 */	jint state;
    /*  @8 */	struct Java_com_sun_midp_lcdui_DisplayAccess * JVM_FIELD_CONST accessor;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	jint displayId;
    /* @20 */	struct Java_javax_microedition_midlet_MIDlet * JVM_FIELD_CONST midlet;
};

struct Java_com_sun_midp_midlet_MIDletTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletTunnel */
};

struct Java_com_sun_midp_midletsuite_MIDletInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST icon;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST classname;
};

struct Java_javax_microedition_lcdui_List {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad97;
    /* @30 */	jbyte ___pad98;
    /* @31 */	jbyte ___pad99;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/List */
    /* @32 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST selectCommand;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST listLF;
};

struct Java_com_sun_midp_appmanager_MIDletSelector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSelector */
    /*  @4 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST mlist;
    /*  @8 */	struct Java_com_sun_midp_appmanager_MIDletSuiteInfo * JVM_FIELD_CONST suiteInfo;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST parentDisplayable;
    /* @20 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @24 */	jint mcount;
    /* @28 */	jobject_array * JVM_FIELD_CONST minfo;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @40 */	jint selectedMidlet;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteLockedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/midletsuite/MIDletSuiteLockedException */
};

struct Java_com_sun_midp_main_MIDletProxyList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyList */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST midletProxies;
    /* @12 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST foregroundMidlet;
    /* @16 */	struct Java_com_sun_midp_main_DisplayController * JVM_FIELD_CONST displayController;
    /* @20 */	jboolean allPaused;
    /* @21 */	jbyte ___pad100;
    /* @22 */	jbyte ___pad101;
    /* @23 */	jbyte ___pad102;
};

struct Java_com_sun_midp_main_MIDletProxyListListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyListListener */
};

struct Java_com_sun_midp_main_DisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
};

struct Java_com_sun_midp_appmanager_MVMManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/MVMManager */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST appManagerUI;
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @20 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
};

struct Java_java_util_Enumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Enumeration */
};

struct Java_com_sun_midp_main_MVMDisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* com/sun/midp/main/MVMDisplayController */
    /* @12 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST foregroundSelector;
};

struct Java_com_sun_midp_appmanager_SMMManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/SMMManager */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST appManagerUI;
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
    /* @44 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @48 */	jboolean allowMidletLaunch;
    /* @49 */	jbyte ___pad103;
    /* @50 */	jbyte ___pad104;
    /* @51 */	jbyte ___pad105;
};

struct Java_com_sun_midp_main_SMMDisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* com/sun/midp/main/SMMDisplayController */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletSuiteId;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletClassName;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletInForeground;
};

struct Java_com_sun_midp_appmanager_SplashScreen_0004TimeoutTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/appmanager/SplashScreen$TimeoutTask */
    /* @28 */	struct Java_com_sun_midp_appmanager_SplashScreen * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_events_EventQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventQueue */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST eventQueueThread;
    /*  @8 */	struct Java_java_lang_Thread * JVM_FIELD_CONST eventMonitorThread;
    /* @12 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST nextEvent;
    /* @16 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST lastEvent;
    /* @20 */	jobject_array * JVM_FIELD_CONST dispatchTable;
    /* @24 */	jint numEvents;
    /* @28 */	struct Java_com_sun_midp_events_NativeEventPool * JVM_FIELD_CONST pool;
    /* @32 */	jint nativeEventQueueHandle;
    /* @36 */	jboolean alive;
    /* @37 */	jbyte ___pad106;
    /* @38 */	jbyte ___pad107;
    /* @39 */	jbyte ___pad108;
};

struct Java_com_sun_midp_main_MIDletControllerEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint currentIsolateId;
    /* @16 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST startErrorEvent;
    /* @20 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletCreatedEvent;
    /* @24 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletActiveEvent;
    /* @28 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletPausedEvent;
    /* @32 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletDestroyedEvent;
};

struct Java_com_sun_midp_automation_AutomationInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/automation/AutomationInitializer */
};

struct Java_java_lang_IllegalStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalStateException */
};

struct Java_com_sun_midp_chameleon_CGraphicsQ {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CGraphicsQ */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST refreshQ;
};

struct Java_com_sun_midp_chameleon_CGraphicsUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CGraphicsUtil */
};

struct Java_com_sun_midp_chameleon_CWindow {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CWindow */
    /*  @4 */	jint_array * JVM_FIELD_CONST bounds;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST layers;
    /* @12 */	jint bgColor;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST bgImage;
    /* @20 */	jint cX;
    /* @24 */	jint cY;
    /* @28 */	jint cW;
    /* @32 */	jint cH;
    /* @36 */	jint tranX;
    /* @40 */	jint tranY;
    /* @44 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @48 */	jint color;
    /* @52 */	jboolean dirty;
    /* @53 */	jbyte ___pad109;
    /* @54 */	jbyte ___pad110;
    /* @55 */	jbyte ___pad111;
};

struct Java_com_sun_midp_chameleon_CLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad112;
    /* @43 */	jbyte ___pad113;
};

struct Java_com_sun_midp_chameleon_ChamDisplayTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/ChamDisplayTunnel */
};

struct Java_com_sun_midp_chameleon_layers_BodyLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad114;
    /* @43 */	jbyte ___pad115;
    /* com/sun/midp/chameleon/layers/BodyLayer */
    /* @44 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
};

struct Java_com_sun_midp_chameleon_layers_TitleLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad116;
    /* @43 */	jbyte ___pad117;
    /* com/sun/midp/chameleon/layers/TitleLayer */
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @48 */	jint titlex;
    /* @52 */	jint titley;
    /* @56 */	jint titlew;
    /* @60 */	jint titleh;
};

struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad118;
    /* @43 */	jbyte ___pad119;
    /* com/sun/midp/chameleon/layers/ScrollIndLayer */
    /* @44 */	jboolean upViz;
    /* @45 */	jboolean downViz;
    /* @46 */	jboolean alertMode;
    /* @47 */	jbyte ___pad120;
};

struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad121;
    /* @43 */	jbyte ___pad122;
    /* com/sun/midp/chameleon/layers/SoftButtonLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST labels;
    /* @48 */	jobject_array * JVM_FIELD_CONST scrCmds;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST scrListener;
    /* @56 */	jobject_array * JVM_FIELD_CONST itmCmds;
    /* @60 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST itemListener;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST soft1;
    /* @68 */	jobject_array * JVM_FIELD_CONST soft2;
    /* @72 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST subMenu;
    /* @76 */	struct Java_com_sun_midp_chameleon_layers_MenuLayer * JVM_FIELD_CONST menuLayer;
    /* @80 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* @84 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST swap;
    /* @92 */	jint typeX;
    /* @96 */	jint typeY;
    /* @100 */	jint buttonx;
    /* @104 */	jint buttony;
    /* @108 */	jint buttonw;
    /* @112 */	jint buttonh;
    /* @116 */	jboolean menuUP;
    /* @117 */	jboolean alertUP;
    /* @118 */	jbyte ___pad123;
    /* @119 */	jbyte ___pad124;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad125;
    /* @43 */	jbyte ___pad126;
    /* com/sun/midp/chameleon/layers/TickerLayer */
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @48 */	jint textLoc;
    /* @52 */	jint textLen;
    /* @56 */	struct Java_java_util_Timer * JVM_FIELD_CONST tickerTimer;
    /* @60 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer_0004TickerPainter * JVM_FIELD_CONST tickerPainter;
};

struct Java_com_sun_midp_chameleon_layers_WashLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad127;
    /* @43 */	jbyte ___pad128;
    /* com/sun/midp/chameleon/layers/WashLayer */
};

struct Java_com_sun_midp_chameleon_layers_AlertLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad129;
    /* @43 */	jbyte ___pad130;
    /* com/sun/midp/chameleon/layers/BodyLayer */
    /* @44 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* com/sun/midp/chameleon/layers/AlertLayer */
    /* @48 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
};

struct Java_com_sun_midp_chameleon_layers_PTILayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad131;
    /* @43 */	jbyte ___pad132;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/PTILayer */
    /* @52 */	jobject_array * JVM_FIELD_CONST list;
    /* @56 */	jint selId;
    /* @60 */	struct Java_com_sun_midp_chameleon_input_TextInputSession * JVM_FIELD_CONST iSession;
    /* @64 */	jint widthMax;
};

struct Java_com_sun_midp_chameleon_layers_PopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad133;
    /* @43 */	jbyte ___pad134;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_chameleon_MIDPWindow {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CWindow */
    /*  @4 */	jint_array * JVM_FIELD_CONST bounds;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST layers;
    /* @12 */	jint bgColor;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST bgImage;
    /* @20 */	jint cX;
    /* @24 */	jint cY;
    /* @28 */	jint cW;
    /* @32 */	jint cH;
    /* @36 */	jint tranX;
    /* @40 */	jint tranY;
    /* @44 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @48 */	jint color;
    /* @52 */	jboolean dirty;
    /* @53 */	jbyte ___pad135;
    /* @54 */	jbyte ___pad136;
    /* @55 */	jbyte ___pad137;
    /* com/sun/midp/chameleon/MIDPWindow */
    /* @56 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* @60 */	jobject_array * JVM_FIELD_CONST scrCmdCache;
    /* @64 */	jint scrCmdCount;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST scrCmdListener;
    /* @72 */	jobject_array * JVM_FIELD_CONST itemCmdCache;
    /* @76 */	jint itemCmdCount;
    /* @80 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST itemCmdListener;
    /* @84 */	struct Java_com_sun_midp_chameleon_layers_BodyLayer * JVM_FIELD_CONST bodyLayer;
    /* @88 */	struct Java_com_sun_midp_chameleon_layers_PTILayer * JVM_FIELD_CONST ptiLayer;
    /* @92 */	struct Java_com_sun_midp_chameleon_layers_TitleLayer * JVM_FIELD_CONST titleLayer;
    /* @96 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer * JVM_FIELD_CONST tickerLayer;
    /* @100 */	struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer * JVM_FIELD_CONST btnLayer;
    /* @104 */	struct Java_com_sun_midp_chameleon_layers_AlertLayer * JVM_FIELD_CONST alertLayer;
    /* @108 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollLayer;
    /* @112 */	struct Java_com_sun_midp_chameleon_layers_WashLayer * JVM_FIELD_CONST washLayer;
    /* @116 */	jboolean hasFullScreen;
    /* @117 */	jboolean sizeChangedOccured;
    /* @118 */	jbyte ___pad138;
    /* @119 */	jbyte ___pad139;
};

struct Java_com_sun_midp_lcdui_TextCursor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextCursor */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jint index;
    /* @24 */	jint option;
    /* @28 */	jint preferredX;
    /* @32 */	jint yOffset;
    /* @36 */	jboolean visible;
    /* @37 */	jbyte ___pad140;
    /* @38 */	jbyte ___pad141;
    /* @39 */	jbyte ___pad142;
};

struct Java_com_sun_midp_chameleon_layers_MenuLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad143;
    /* @43 */	jbyte ___pad144;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/MenuLayer */
    /* @52 */	jobject_array * JVM_FIELD_CONST menuCmds;
    /* @56 */	jint selI;
    /* @60 */	jint scrollIndex;
    /* @64 */	struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer * JVM_FIELD_CONST btnLayer;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_CascadeMenuLayer * JVM_FIELD_CONST cascadeMenu;
    /* @76 */	jboolean cascadeMenuUp;
    /* @77 */	jbyte ___pad145;
    /* @78 */	jbyte ___pad146;
    /* @79 */	jbyte ___pad147;
};

struct Java_com_sun_midp_chameleon_SubMenuCommand {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Command */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST shortLabel;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST longLabel;
    /* @12 */	jint commandType;
    /* @16 */	jint priority;
    /* @20 */	jint id;
    /* com/sun/midp/chameleon/SubMenuCommand */
    /* @24 */	jobject_array * JVM_FIELD_CONST subCommands;
    /* @28 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer_0004TickerPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/chameleon/layers/TickerLayer$TickerPainter */
    /* @28 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/layers/TickerLayer$1 */
};

struct Java_com_sun_midp_chameleon_input_InputModeMediator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputModeMediator */
};

struct Java_com_sun_midp_chameleon_input_InputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputMode */
};

struct Java_com_sun_midp_chameleon_input_BasicInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad148;
};

struct Java_com_sun_midp_chameleon_input_AlphaNumericInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad149;
    /* com/sun/midp/chameleon/input/AlphaNumericInputMode */
    /* @32 */	jint capsModePointer;
};

struct Java_com_sun_midp_chameleon_input_TextInputComponent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/TextInputComponent */
};

struct Java_com_sun_midp_chameleon_input_TextInputSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/TextInputSession */
};

struct Java_com_sun_midp_chameleon_input_BasicTextInputSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicTextInputSession */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST currentMode;
    /*  @8 */	jobject_array * JVM_FIELD_CONST inputModeSet;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST previousScreen;
    /* @20 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST stickyMode;
    /* @24 */	struct Java_com_sun_midp_chameleon_input_TextInputComponent * JVM_FIELD_CONST textComponent;
};

struct Java_com_sun_midp_chameleon_input_KeyboardInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/KeyboardInputMode */
    /*  @4 */	jint lastKey;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
};

struct Java_com_sun_midp_chameleon_input_NumericInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad150;
    /* com/sun/midp/chameleon/input/NumericInputMode */
    /* @32 */	jobject_array * JVM_FIELD_CONST numericKeyMap;
    /* @36 */	jobject_array * JVM_FIELD_CONST decimalKeyMap;
    /* @40 */	jobject_array * JVM_FIELD_CONST phoneNumericKeyMap;
    /* @44 */	jobject_array * JVM_FIELD_CONST anyKeyMap;
};

struct Java_com_sun_midp_chameleon_input_PTIterator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTIterator */
};

struct Java_com_sun_midp_chameleon_input_PTDictionary {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionary */
};

struct Java_java_util_Hashtable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Hashtable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST table;
    /*  @8 */	jint count;
    /* @12 */	jint threshold;
};

struct Java_com_sun_midp_chameleon_input_PTDictionaryFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionaryFactory */
};

struct Java_com_sun_midp_chameleon_input_PTDictionaryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionaryImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST language;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_PTIterator * JVM_FIELD_CONST iterator;
};

struct Java_com_sun_midp_chameleon_input_PTIteratorImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTIteratorImpl */
    /*  @4 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST buffer;
    /*  @8 */	jint selected;
    /* @12 */	jobject_array * JVM_FIELD_CONST keyMap;
    /* @16 */	jobject_array * JVM_FIELD_CONST list;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST states;
};

struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PredictiveTextInputMode */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST part;
    /* @12 */	struct Java_com_sun_midp_chameleon_input_PTIterator * JVM_FIELD_CONST iterator;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode_0004StringDiff * JVM_FIELD_CONST diff;
    /* @20 */	jint capsMode;
};

struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode_0004StringDiff {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PredictiveTextInputMode$StringDiff */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST state;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$1 */
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad151;
    /* @30 */	jbyte ___pad152;
    /* @31 */	jbyte ___pad153;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad154;
    /* @38 */	jbyte ___pad155;
    /* @39 */	jbyte ___pad156;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable */
    /* @40 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @44 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @48 */	jint cc;
    /* @52 */	jint hmargin;
    /* @56 */	jint wmargin;
    /* @60 */	jint margin;
    /* @64 */	jint wx;
    /* @68 */	jint wy;
    /* @72 */	jint ww;
    /* @76 */	jint wh;
    /* @80 */	jint cols;
    /* @84 */	jint rows;
    /* @88 */	jint pos;
    /* @92 */	jint newpos;
    /* @96 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @100 */	jint defaultSymbolCursorPos;
    /* @104 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST accept;
    /* @108 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST reject;
    /* @112 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode * JVM_FIELD_CONST this_0440;
    /* @116 */	jboolean firstTime;
    /* @117 */	jbyte ___pad157;
    /* @118 */	jbyte ___pad158;
    /* @119 */	jbyte ___pad159;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode */
    /*  @4 */	jint lastKey;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @12 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable * JVM_FIELD_CONST st;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable_0004Accept {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable$Accept */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable_0004Reject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable$Reject */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_chameleon_layers_CascadeMenuLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad160;
    /* @43 */	jbyte ___pad161;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/CascadeMenuLayer */
    /* @52 */	jobject_array * JVM_FIELD_CONST menuCmds;
    /* @56 */	jint selI;
    /* @60 */	jint scrollIndex;
    /* @64 */	struct Java_com_sun_midp_chameleon_layers_MenuLayer * JVM_FIELD_CONST menuLayer;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
};

struct Java_com_sun_midp_chameleon_layers_InputModeLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad162;
    /* @43 */	jbyte ___pad163;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/InputModeLayer */
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST mode;
    /* @56 */	jint stringWidth;
    /* @60 */	jint stringHeight;
    /* @64 */	jint_array * JVM_FIELD_CONST anchor;
};

struct Java_com_sun_midp_chameleon_skins_AlertSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/AlertSkin */
};

struct Java_com_sun_midp_chameleon_skins_BusyCursorSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/BusyCursorSkin */
};

struct Java_com_sun_midp_chameleon_skins_ChoiceGroupSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ChoiceGroupSkin */
};

struct Java_com_sun_midp_chameleon_skins_DateEditorSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/DateEditorSkin */
};

struct Java_com_sun_midp_chameleon_skins_DateFieldSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/DateFieldSkin */
};

struct Java_com_sun_midp_chameleon_skins_GaugeSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/GaugeSkin */
};

struct Java_com_sun_midp_chameleon_skins_ImageItemSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ImageItemSkin */
};

struct Java_com_sun_midp_chameleon_skins_MenuSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/MenuSkin */
};

struct Java_com_sun_midp_chameleon_skins_PTISkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/PTISkin */
};

struct Java_com_sun_midp_chameleon_skins_ProgressBarSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ProgressBarSkin */
};

struct Java_com_sun_midp_chameleon_skins_ScreenSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ScreenSkin */
};

struct Java_com_sun_midp_chameleon_skins_ScrollIndSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ScrollIndSkin */
};

struct Java_com_sun_midp_chameleon_skins_SkinPropertiesIDs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/SkinPropertiesIDs */
};

struct Java_com_sun_midp_chameleon_skins_SoftButtonSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/SoftButtonSkin */
};

struct Java_com_sun_midp_chameleon_skins_StringItemSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/StringItemSkin */
};

struct Java_com_sun_midp_chameleon_skins_TextFieldSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TextFieldSkin */
};

struct Java_com_sun_midp_chameleon_skins_TickerSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TickerSkin */
};

struct Java_com_sun_midp_chameleon_skins_TitleSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TitleSkin */
};

struct Java_com_sun_midp_chameleon_skins_UpdateBarSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/UpdateBarSkin */
};

struct Java_com_sun_midp_chameleon_skins_resources_AlertResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/AlertResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_BusyCursorResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/BusyCursorResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ChoiceGroupResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ChoiceGroupResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_DateEditorResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/DateEditorResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_DateFieldResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/DateFieldResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_FontResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/FontResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_GaugeResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/GaugeResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ImageItemResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ImageItemResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ImageTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ImageTunnel */
};

struct Java_com_sun_midp_chameleon_skins_resources_LoadedSkinProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/LoadedSkinProperties */
    /*  @4 */	jint_array * JVM_FIELD_CONST properties;
    /*  @8 */	jobject_array * JVM_FIELD_CONST stringValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST imageValues;
    /* @16 */	jint_array * JVM_FIELD_CONST fontValues;
    /* @20 */	jint_array * JVM_FIELD_CONST intSeqValues;
};

struct Java_com_sun_midp_chameleon_skins_resources_LoadedSkinResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/LoadedSkinResources */
    /*  @4 */	jobject_array * JVM_FIELD_CONST fonts;
    /*  @8 */	jobject_array * JVM_FIELD_CONST images;
};

struct Java_com_sun_midp_chameleon_skins_resources_MenuResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/MenuResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_PTIResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/PTIResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ProgressBarResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ProgressBarResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_RomizedSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/RomizedSkin */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScreenResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScreenResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScrollIndResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScrollIndResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_SkinResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SkinResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_SoftButtonResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SoftButtonResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_StringItemResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/StringItemResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TextFieldResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TextFieldResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TickerResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TickerResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TitleResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TitleResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_UpdateBarResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/UpdateBarResources */
};

struct Java_com_sun_midp_configurator_Constants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/configurator/Constants */
};

struct Java_com_sun_midp_content_CHManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/content/CHManager */
};

struct Java_com_sun_midp_installer_Installer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpConnection;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST httpInputStream;
    /* @12 */	struct Java_com_sun_midp_installer_Installer_0004InstallStateImpl * JVM_FIELD_CONST state;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
};

struct Java_com_sun_midp_installer_InstallState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallState */
};

struct Java_com_sun_midp_crypto_Cipher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
};

struct Java_com_sun_midp_crypto_Key {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Key */
};

struct Java_com_sun_midp_crypto_CryptoParameter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/CryptoParameter */
};

struct Java_com_sun_midp_crypto_AES {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/AES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_crypto_Padder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Padder */
};

struct Java_com_sun_midp_crypto_BlockCipherBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad164;
};

struct Java_com_sun_midp_crypto_AES_1ECB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad165;
    /* com/sun/midp/crypto/AES_ECB */
    /* @40 */	jint_array * JVM_FIELD_CONST SB0;
    /* @44 */	jint_array * JVM_FIELD_CONST SB1;
    /* @48 */	jint_array * JVM_FIELD_CONST SB2;
    /* @52 */	jint_array * JVM_FIELD_CONST SB3;
    /* @56 */	jint Nk;
    /* @60 */	jint Nr;
    /* @64 */	jint_array * JVM_FIELD_CONST W;
    /* @68 */	jbyte_array * JVM_FIELD_CONST state;
};

struct Java_com_sun_midp_crypto_AES_1CBC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad166;
    /* com/sun/midp/crypto/AES_ECB */
    /* @40 */	jint_array * JVM_FIELD_CONST SB0;
    /* @44 */	jint_array * JVM_FIELD_CONST SB1;
    /* @48 */	jint_array * JVM_FIELD_CONST SB2;
    /* @52 */	jint_array * JVM_FIELD_CONST SB3;
    /* @56 */	jint Nk;
    /* @60 */	jint Nr;
    /* @64 */	jint_array * JVM_FIELD_CONST W;
    /* @68 */	jbyte_array * JVM_FIELD_CONST state;
    /* com/sun/midp/crypto/AES_CBC */
    /* @72 */	jbyte_array * JVM_FIELD_CONST scratchPad;
    /* @76 */	jbyte_array * JVM_FIELD_CONST savedState;
};

struct Java_com_sun_midp_crypto_GeneralSecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
};

struct Java_com_sun_midp_crypto_InvalidKeyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidKeyException */
};

struct Java_com_sun_midp_crypto_SecretKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecretKey */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST alg;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST secret;
};

struct Java_com_sun_midp_crypto_ARC4 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/ARC4 */
    /*  @4 */	jint mode;
    /*  @8 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST ckey;
    /* @12 */	jbyte_array * JVM_FIELD_CONST S;
    /* @16 */	jint_array * JVM_FIELD_CONST ii;
    /* @20 */	jint_array * JVM_FIELD_CONST jj;
};

struct Java_com_sun_midp_crypto_NoSuchPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/NoSuchPaddingException */
};

struct Java_com_sun_midp_crypto_ShortBufferException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/ShortBufferException */
};

struct Java_com_sun_midp_crypto_BadPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/BadPaddingException */
};

struct Java_com_sun_midp_crypto_PKCS5Padding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PKCS5Padding */
    /*  @4 */	jint blockSize;
};

struct Java_com_sun_midp_crypto_InvalidAlgorithmParameterException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidAlgorithmParameterException */
};

struct Java_com_sun_midp_crypto_IllegalBlockSizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/IllegalBlockSizeException */
};

struct Java_com_sun_midp_crypto_NoSuchAlgorithmException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/NoSuchAlgorithmException */
};

struct Java_com_sun_midp_crypto_DES {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/DES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_crypto_DES_1ECB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad167;
    /* com/sun/midp/crypto/DES_ECB */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST keyAlgorithm;
    /* @44 */	jobject_array * JVM_FIELD_CONST dkey;
    /* @48 */	jboolean tripleDes;
    /* @49 */	jbyte ___pad168;
    /* @50 */	jbyte ___pad169;
    /* @51 */	jbyte ___pad170;
};

struct Java_com_sun_midp_crypto_DES_1CBC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad171;
    /* com/sun/midp/crypto/DES_ECB */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST keyAlgorithm;
    /* @44 */	jobject_array * JVM_FIELD_CONST dkey;
    /* @48 */	jboolean tripleDes;
    /* @49 */	jbyte ___pad172;
    /* @50 */	jbyte ___pad173;
    /* @51 */	jbyte ___pad174;
    /* com/sun/midp/crypto/DES_CBC */
    /* @52 */	jbyte_array * JVM_FIELD_CONST chainingBlock;
    /* @56 */	jbyte_array * JVM_FIELD_CONST storeBuffer;
    /* @60 */	jbyte_array * JVM_FIELD_CONST savedChainingBlock;
};

struct Java_com_sun_midp_crypto_DESEDE {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/DES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
    /* com/sun/midp/crypto/DESEDE */
};

struct Java_com_sun_midp_crypto_DigestException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/DigestException */
};

struct Java_com_sun_midp_crypto_InvalidKeySpecException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidKeySpecException */
};

struct Java_com_sun_midp_crypto_IvParameter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/IvParameter */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST IV;
};

struct Java_com_sun_midp_crypto_MessageDigest {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
};

struct Java_com_sun_midp_crypto_MD2 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/MD2 */
    /*  @4 */	jint_array * JVM_FIELD_CONST num;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint_array * JVM_FIELD_CONST cksm;
    /* @16 */	jint_array * JVM_FIELD_CONST state;
};

struct Java_com_sun_midp_crypto_MD5 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/MD5 */
    /*  @4 */	jint_array * JVM_FIELD_CONST state;
    /*  @8 */	jint_array * JVM_FIELD_CONST num;
    /* @12 */	jint_array * JVM_FIELD_CONST count;
    /* @16 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_midp_crypto_SHA {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/SHA */
    /*  @4 */	jint_array * JVM_FIELD_CONST state;
    /*  @8 */	jint_array * JVM_FIELD_CONST num;
    /* @12 */	jint_array * JVM_FIELD_CONST count;
    /* @16 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_midp_crypto_SecureRandom {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecureRandom */
};

struct Java_com_sun_midp_crypto_PRand {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecureRandom */
    /* com/sun/midp/crypto/PRand */
};

struct Java_com_sun_midp_crypto_PrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PrivateKey */
};

struct Java_com_sun_midp_crypto_PublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PublicKey */
};

struct Java_com_sun_midp_crypto_RSAKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
};

struct Java_com_sun_midp_crypto_RSA {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/RSA */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSAKey * JVM_FIELD_CONST ckey;
    /*  @8 */	jint mode;
    /* @12 */	jbyte_array * JVM_FIELD_CONST messageToSign;
    /* @16 */	jint bytesInMessage;
};

struct Java_com_sun_midp_crypto_RSAPrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
    /* com/sun/midp/crypto/RSAPrivateKey */
};

struct Java_com_sun_midp_crypto_RSAPublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
    /* com/sun/midp/crypto/RSAPublicKey */
};

struct Java_com_sun_midp_crypto_RSASig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSASig */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST alg;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md;
    /* @12 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST c;
    /* @16 */	struct Java_com_sun_midp_crypto_RSAKey * JVM_FIELD_CONST k;
    /* @20 */	jbyte_array * JVM_FIELD_CONST prefix;
};

struct Java_com_sun_midp_crypto_SignatureException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/SignatureException */
};

struct Java_com_sun_midp_crypto_Signature {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
};

struct Java_com_sun_midp_crypto_RsaMd5Sig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
    /* com/sun/midp/crypto/RsaMd5Sig */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSASig * JVM_FIELD_CONST rsaSig;
};

struct Java_com_sun_midp_crypto_RsaShaSig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
    /* com/sun/midp/crypto/RsaShaSig */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSASig * JVM_FIELD_CONST rsaSig;
};

struct Java_com_sun_midp_crypto_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Util */
};

struct Java_com_sun_midp_events_EventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventListener */
};

struct Java_com_sun_midp_events_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
};

struct Java_com_sun_midp_events_DispatchData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/DispatchData */
    /*  @4 */	struct Java_com_sun_midp_events_EventListener * JVM_FIELD_CONST listener;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST waitingEvent;
};

struct Java_com_sun_midp_events_NativeEventPool {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/NativeEventPool */
    /*  @4 */	jobject_array * JVM_FIELD_CONST eventStack;
    /*  @8 */	jint eventsInPool;
};

struct Java_com_sun_midp_events_NativeEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/events/NativeEvent */
    /* @12 */	jint intParam1;
    /* @16 */	jint intParam2;
    /* @20 */	jint intParam3;
    /* @24 */	jint intParam4;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam1;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam2;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam3;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam4;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam5;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam6;
};

struct Java_com_sun_midp_events_NativeEventMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/NativeEventMonitor */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST eventQueueLock;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @12 */	struct Java_com_sun_midp_events_NativeEventPool * JVM_FIELD_CONST pool;
};

struct Java_com_sun_midp_events_EventTypes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventTypes */
};

struct Java_com_sun_midp_i18n_ResourceBundle {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/ResourceBundle */
};

struct Java_com_sun_midp_i18n_Resource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/Resource */
};

struct Java_com_sun_midp_l10n_LocalizedStringsBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBase */
};

struct Java_com_sun_midp_l10n_LocalizedStrings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBase */
    /* com/sun/midp/l10n/LocalizedStrings */
};

struct Java_com_sun_midp_i18n_ResourceConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/ResourceConstants */
};

struct Java_com_sun_midp_installer_InstallListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallListener */
};

struct Java_com_sun_midp_installer_AutoTesterInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterInterface */
};

struct Java_javax_microedition_lcdui_TextField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/TextField */
    /* @44 */	struct Java_javax_microedition_lcdui_TextFieldLF * JVM_FIELD_CONST textFieldLF;
    /* @48 */	struct Java_com_sun_midp_lcdui_DynamicCharacterArray * JVM_FIELD_CONST buffer;
    /* @52 */	jint constraints;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
};

struct Java_com_sun_midp_installer_InvalidJadException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/midp/installer/InvalidJadException */
    /* @12 */	jint reason;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST extraData;
};

struct Java_com_sun_midp_installer_AutoTesterBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
};

struct Java_com_sun_midp_installer_AutoTester {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
    /* com/sun/midp/installer/AutoTester */
};

struct Java_java_lang_NumberFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
    /* java/lang/NumberFormatException */
};

struct Java_com_sun_midp_lcdui_DynamicCharacterArray {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DynamicCharacterArray */
    /*  @4 */	jchar_array * JVM_FIELD_CONST buffer;
    /*  @8 */	jint length;
};

struct Java_javax_microedition_lcdui_TextFieldLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldLF */
};

struct Java_com_sun_midp_installer_AutoTesterMulti_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterMulti$1 */
};

struct Java_com_sun_midp_installer_AutoTesterMulti {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
    /* com/sun/midp/installer/AutoTesterMulti */
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST installList;
};

struct Java_com_sun_midp_installer_AutoTesterMulti_0004AutoTesterRunner {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterMulti$AutoTesterRunner */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST storage;
    /* @12 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @16 */	struct Java_com_sun_midp_installer_AutoTesterMulti * JVM_FIELD_CONST this_0440;
};

struct Java_java_io_InputStreamReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* java/io/InputStreamReader */
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST in;
};

struct Java_com_sun_midp_installer_DiscoveryApp_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DiscoveryApp$1 */
};

struct Java_com_sun_midp_installer_DiscoveryApp {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/DiscoveryApp */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultInstallListUrl;
    /* @16 */	struct Java_javax_microedition_lcdui_TextBox * JVM_FIELD_CONST urlTextBox;
    /* @20 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @24 */	jint progressGaugeIndex;
    /* @28 */	jint progressUrlIndex;
    /* @32 */	jlong lastDisplayChange;
    /* @40 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST installListBox;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST installList;
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST discoverCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST installCmd;
    /* @56 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
};

struct Java_javax_microedition_lcdui_TextBox {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad175;
    /* @30 */	jbyte ___pad176;
    /* @31 */	jbyte ___pad177;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/TextBox */
    /* @32 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST textField;
    /* @36 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST textBoxLF;
};

struct Java_com_sun_midp_installer_DiscoveryApp_0004BackgroundInstallListGetter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DiscoveryApp$BackgroundInstallListGetter */
    /*  @4 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_GaugeLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/GaugeLF */
};

struct Java_com_sun_midp_installer_GraphicalInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/GraphicalInstaller */
    /*  @8 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST passwordForm;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST usernameField;
    /* @24 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST passwordField;
    /* @28 */	struct Java_com_sun_midp_installer_GraphicalInstaller_0004BackgroundInstaller * JVM_FIELD_CONST backgroundInstaller;
    /* @32 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @36 */	jint progressGaugeIndex;
    /* @40 */	jint progressUrlIndex;
    /* @44 */	jlong lastDisplayChange;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST cancelledMessage;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST finishingMessage;
    /* @60 */	struct Java_com_sun_midp_content_CHManager * JVM_FIELD_CONST chmanager;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST stopCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST continueCmd;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST nextCmd;
    /* @80 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @84 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exceptionCmd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keepRMSCmd;
    /* @92 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeRMSCmd;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_0004BackgroundInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$BackgroundInstaller */
    /*  @4 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST successMessage;
    /* @20 */	struct Java_com_sun_midp_installer_InstallState * JVM_FIELD_CONST installState;
    /* @24 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
    /* @28 */	jboolean update;
    /* @29 */	jboolean continueInstall;
    /* @30 */	jboolean jarOnly;
    /* @31 */	jboolean proxyAuth;
};

struct Java_com_sun_midp_installer_InstallRetryHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallRetryHandler */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST token;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST suite;
};

struct Java_com_sun_midp_installer_Installer_0004InstallStateImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer$InstallStateImpl */
    /*  @4 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST listener;
    /*  @8 */	jlong startTime;
    /* @16 */	jint nextStep;
    /* @20 */	struct Java_com_sun_midp_installer_InvalidJadException * JVM_FIELD_CONST exception;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST jadUrl;
    /* @28 */	jbyte_array * JVM_FIELD_CONST jad;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST jadEncoding;
    /* @36 */	struct Java_com_sun_midp_installer_JadProperties * JVM_FIELD_CONST jadProps;
    /* @40 */	struct Java_com_sun_midp_installer_ManifestProperties * JVM_FIELD_CONST jarProps;
    /* @44 */	struct Java_com_sun_midp_io_j2me_storage_File * JVM_FIELD_CONST file;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST username;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST password;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST proxyUsername;
    /* @60 */	struct Java_java_lang_String * JVM_FIELD_CONST proxyPassword;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteName;
    /* @68 */	struct Java_java_lang_String * JVM_FIELD_CONST vendor;
    /* @72 */	struct Java_java_lang_String * JVM_FIELD_CONST version;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST description;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @84 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @88 */	jint expectedJarSize;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST jarUrl;
    /* @96 */	jint beginTransferDataStatus;
    /* @100 */	jint transferStatus;
    /* @104 */	jint pushOptions;
    /* @108 */	jbyte_array * JVM_FIELD_CONST permissions;
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @116 */	struct Java_com_sun_midp_security_SecurityHandler * JVM_FIELD_CONST securityHandler;
    /* @120 */	jbyte_array * JVM_FIELD_CONST manifest;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST tempFilename;
    /* @128 */	struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream * JVM_FIELD_CONST storage;
    /* @132 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @136 */	struct Java_java_lang_String * JVM_FIELD_CONST storageRoot;
    /* @140 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST previousSuite;
    /* @144 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST previousInstallInfo;
    /* @148 */	struct Java_com_sun_midp_content_CHManager * JVM_FIELD_CONST chmanager;
    /* @152 */	jbyte_array * JVM_FIELD_CONST verifyHash;
    /* @156 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST this_0440;
    /* @160 */	jboolean stopInstallation;
    /* @161 */	jboolean ignoreCancel;
    /* @162 */	jboolean force;
    /* @163 */	jboolean removeRMS;
    /* @164 */	jbyte pushInterruptSetting;
    /* @165 */	jboolean trusted;
    /* @166 */	jboolean isPreviousVersion;
    /* @167 */	jbyte ___pad178;
};

struct Java_com_sun_midp_installer_JadProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
    /* com/sun/midp/installer/JadProperties */
    /* @16 */	jchar_array * JVM_FIELD_CONST lineBuffer;
};

struct Java_com_sun_midp_installer_ManifestProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
    /* com/sun/midp/installer/JadProperties */
    /* @16 */	jchar_array * JVM_FIELD_CONST lineBuffer;
    /* com/sun/midp/installer/ManifestProperties */
    /* @20 */	jint remainder;
};

struct Java_com_sun_midp_io_j2me_storage_File {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/storage/File */
};

struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad179;
    /* @22 */	jbyte ___pad180;
    /* @23 */	jbyte ___pad181;
    /* com/sun/midp/io/j2me/storage/RandomAccessStream */
    /* @24 */	jint handle;
};

struct Java_com_sun_midp_util_Properties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
};

struct Java_javax_microedition_io_HttpConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/HttpConnection */
};

struct Java_javax_microedition_io_ConnectionNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/microedition/io/ConnectionNotFoundException */
};

struct Java_com_sun_midp_installer_InternalMIDletSuiteImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InternalMIDletSuiteImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @12 */	jbyte_array * JVM_FIELD_CONST permissions;
    /* @16 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST properties;
    /* @20 */	jint numberOfMidlets;
    /* @24 */	jboolean trusted;
    /* @25 */	jbyte ___pad182;
    /* @26 */	jbyte ___pad183;
    /* @27 */	jbyte ___pad184;
};

struct Java_com_sun_midp_installer_JarReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/JarReader */
};

struct Java_com_sun_midp_installer_PendingNotification {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/PendingNotification */
    /*  @4 */	jint retries;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
};

struct Java_com_sun_midp_installer_OtaNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/OtaNotifier */
};

struct Java_com_sun_midp_io_HttpUrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/HttpUrl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST scheme;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST authority;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST fragment;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @28 */	jint port;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST machine;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
};

struct Java_java_io_DataInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* java/io/DataInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_javax_microedition_io_StreamConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/StreamConnection */
};

struct Java_com_sun_midp_io_j2me_http_StreamConnectionPool {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/StreamConnectionPool */
    /*  @4 */	jlong m_connectionLingerTime;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST m_connections;
    /* @16 */	jint m_max_connections;
};

struct Java_com_sun_midp_io_j2me_http_StreamConnectionElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/StreamConnectionElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST m_protocol;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST m_host;
    /* @12 */	jint m_port;
    /* @16 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST m_stream;
    /* @20 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST m_data_input_stream;
    /* @24 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST m_data_output_stream;
    /* @28 */	jlong m_time;
    /* @36 */	jboolean m_in_use;
    /* @37 */	jboolean m_removed;
    /* @38 */	jbyte ___pad185;
    /* @39 */	jbyte ___pad186;
};

struct Java_java_io_DataOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/DataOutputStream */
    /*  @4 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
};

struct Java_javax_microedition_io_OutputConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/OutputConnection */
};

struct Java_javax_microedition_io_InputConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/InputConnection */
};

struct Java_javax_microedition_io_ContentConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/ContentConnection */
};

struct Java_com_sun_midp_io_ConnectionBaseAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad187;
    /* @22 */	jbyte ___pad188;
    /* @23 */	jbyte ___pad189;
};

struct Java_com_sun_midp_io_j2me_http_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad190;
    /* @22 */	jbyte ___pad191;
    /* @23 */	jbyte ___pad192;
    /* com/sun/midp/io/j2me/http/Protocol */
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /* @28 */	jint default_port;
    /* @32 */	struct Java_com_sun_midp_io_HttpUrl * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST hostAndPort;
    /* @40 */	jint responseCode;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST responseMsg;
    /* @48 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST reqProperties;
    /* @52 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST headerFields;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST method;
    /* @60 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST streamConnection;
    /* @64 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST streamOutput;
    /* @68 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST streamInput;
    /* @72 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST stringbuffer;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST httpVer;
    /* @80 */	jint contentLength;
    /* @84 */	jint chunksize;
    /* @88 */	jint totalbytesread;
    /* @92 */	jbyte_array * JVM_FIELD_CONST readbuf;
    /* @96 */	jint bytesleft;
    /* @100 */	jint bytesread;
    /* @104 */	jbyte_array * JVM_FIELD_CONST writebuf;
    /* @108 */	jint bytesToWrite;
    /* @112 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST proxyHeaders;
    /* @116 */	jboolean permissionChecked;
    /* @117 */	jboolean ownerTrusted;
    /* @118 */	jboolean ConnectionCloseFlag;
    /* @119 */	jboolean chunkedIn;
    /* @120 */	jboolean chunkedOut;
    /* @121 */	jboolean firstChunkSent;
    /* @122 */	jboolean sendingRequest;
    /* @123 */	jboolean requestFinished;
    /* @124 */	jboolean eof;
    /* @125 */	jbyte handshakeError;
    /* @126 */	jboolean readInProgress;
    /* @127 */	jbyte ___pad193;
};

struct Java_com_sun_midp_pki_X509Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/X509Certificate */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST fp;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST serialNumber;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST subject;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST issuer;
    /* @20 */	jlong from;
    /* @28 */	jlong until;
    /* @36 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST pubKey;
    /* @40 */	jint idx;
    /* @44 */	jbyte_array * JVM_FIELD_CONST enc;
    /* @48 */	jint TBSStart;
    /* @52 */	jint TBSLen;
    /* @56 */	jbyte_array * JVM_FIELD_CONST signature;
    /* @60 */	jbyte_array * JVM_FIELD_CONST TBSCertHash;
    /* @64 */	struct Java_java_lang_Object * JVM_FIELD_CONST subAltName;
    /* @68 */	jint pLenConstr;
    /* @72 */	jint keyUsage;
    /* @76 */	jint extKeyUsage;
    /* @80 */	jboolean selfSigned;
    /* @81 */	jbyte version;
    /* @82 */	jbyte sigAlg;
    /* @83 */	jboolean badExt;
    /* @84 */	jbyte subAltNameType;
    /* @85 */	jboolean hasBC;
    /* @86 */	jboolean isCA;
    /* @87 */	jbyte ___pad194;
};

struct Java_com_sun_midp_pki_CertStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/CertStore */
};

struct Java_javax_microedition_pki_Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pki/Certificate */
};

struct Java_com_sun_midp_installer_SecureInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpConnection;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST httpInputStream;
    /* @12 */	struct Java_com_sun_midp_installer_Installer_0004InstallStateImpl * JVM_FIELD_CONST state;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
    /* com/sun/midp/installer/SecureInstaller */
    /* @28 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @32 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST cpCert;
};

struct Java_javax_microedition_pki_CertificateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/microedition/pki/CertificateException */
    /* @12 */	struct Java_javax_microedition_pki_Certificate * JVM_FIELD_CONST cert;
    /* @16 */	jbyte reason;
    /* @17 */	jbyte ___pad195;
    /* @18 */	jbyte ___pad196;
    /* @19 */	jbyte ___pad197;
};

struct Java_com_sun_midp_security_ImplicitlyTrustedClass {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/ImplicitlyTrustedClass */
};

struct Java_com_sun_midp_publickeystore_InputStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
    /* com/sun/midp/publickeystore/InputStorage */
    /*  @4 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST in;
};

struct Java_com_sun_midp_publickeystore_PublicKeyStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
};

struct Java_com_sun_midp_installer_SuiteDownloadInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/SuiteDownloadInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
};

struct Java_com_sun_midp_io_Base64 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/Base64 */
};

struct Java_com_sun_midp_io_BaseInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/io/BaseInputStream */
    /*  @4 */	struct Java_com_sun_midp_io_ConnectionBaseAdapter * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @12 */	jbyte_array * JVM_FIELD_CONST markBuf;
    /* @16 */	jint markSize;
    /* @20 */	jint markPos;
    /* @24 */	jboolean isReadFromBuffer;
    /* @25 */	jbyte ___pad198;
    /* @26 */	jbyte ___pad199;
    /* @27 */	jbyte ___pad200;
};

struct Java_java_io_InterruptedIOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/InterruptedIOException */
    /* @12 */	jint bytesTransferred;
};

struct Java_com_sun_midp_io_BaseOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/io/BaseOutputStream */
    /*  @4 */	struct Java_com_sun_midp_io_ConnectionBaseAdapter * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
};

struct Java_com_sun_midp_io_BufferedConnectionAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad201;
    /* @22 */	jbyte ___pad202;
    /* @23 */	jbyte ___pad203;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad204;
    /* @38 */	jbyte ___pad205;
    /* @39 */	jbyte ___pad206;
};

struct Java_com_sun_midp_io_NetworkConnectionBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad207;
    /* @22 */	jbyte ___pad208;
    /* @23 */	jbyte ___pad209;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad210;
    /* @38 */	jbyte ___pad211;
    /* @39 */	jbyte ___pad212;
    /* com/sun/midp/io/NetworkConnectionBase */
};

struct Java_com_sun_midp_io_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/Util */
};

struct Java_javax_wireless_messaging_Message {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/Message */
};

struct Java_javax_wireless_messaging_BinaryMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/BinaryMessage */
};

struct Java_com_sun_midp_io_j2me_sms_MessageObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
};

struct Java_com_sun_midp_io_j2me_sms_BinaryObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/BinaryObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_io_j2me_cbs_BinaryObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/BinaryObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* com/sun/midp/io/j2me/cbs/BinaryObject */
};

struct Java_com_sun_midp_io_j2me_cbs_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/cbs/Protocol */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST CBS_URL_PREFIX;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @12 */	jint m_mode;
    /* @16 */	jint m_imsgid;
    /* @20 */	jint cbsHandle;
    /* @24 */	struct Java_javax_wireless_messaging_MessageListener * JVM_FIELD_CONST m_listener;
    /* @28 */	struct Java_java_lang_Thread * JVM_FIELD_CONST m_listenerThread;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	jboolean open;
    /* @37 */	jboolean openPermission;
    /* @38 */	jboolean readPermission;
    /* @39 */	jboolean doneRetrieving;
};

struct Java_javax_wireless_messaging_MessageConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessageConnection */
};

struct Java_javax_wireless_messaging_MessageListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessageListener */
};

struct Java_com_sun_midp_io_j2me_cbs_Protocol_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/io/j2me/cbs/Protocol$1 */
    /* @28 */	struct Java_javax_wireless_messaging_MessageConnection * JVM_FIELD_CONST val_044messageConnection;
    /* @32 */	struct Java_com_sun_midp_io_j2me_cbs_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_cbs_Protocol_0004CBSPacket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/cbs/Protocol$CBSPacket */
    /*  @4 */	jint encodingType;
    /*  @8 */	jint msgID;
    /* @12 */	jbyte_array * JVM_FIELD_CONST message;
    /* @16 */	struct Java_com_sun_midp_io_j2me_cbs_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_midlet_Scheduler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/Scheduler */
};

struct Java_javax_wireless_messaging_TextMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/TextMessage */
};

struct Java_com_sun_midp_io_j2me_sms_TextObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/TextObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_io_j2me_cbs_TextObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/TextObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* com/sun/midp/io/j2me/cbs/TextObject */
};

struct Java_java_io_DataInput {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/DataInput */
};

struct Java_java_io_DataOutput {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/DataOutput */
};

struct Java_javax_microedition_io_Datagram {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Datagram */
};

struct Java_com_sun_midp_io_j2me_datagram_DatagramObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/DatagramObject */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buffer;
    /*  @8 */	jint offset;
    /* @12 */	jint length;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /* @20 */	jint ipNumber;
    /* @24 */	jint port;
    /* @28 */	jint readWritePosition;
};

struct Java_java_io_UTFDataFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/UTFDataFormatException */
};

struct Java_java_io_EOFException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/EOFException */
};

struct Java_javax_microedition_io_DatagramConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/DatagramConnection */
};

struct Java_javax_microedition_io_UDPDatagramConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/UDPDatagramConnection */
};

struct Java_com_sun_midp_io_j2me_datagram_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/Protocol */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @12 */	jint nativeHandle;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @20 */	jint port;
    /* @24 */	jboolean open;
    /* @25 */	jboolean ownerTrusted;
    /* @26 */	jbyte ___pad213;
    /* @27 */	jbyte ___pad214;
};

struct Java_javax_microedition_io_SocketConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SocketConnection */
};

struct Java_com_sun_midp_io_j2me_socket_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad215;
    /* @22 */	jbyte ___pad216;
    /* @23 */	jbyte ___pad217;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad218;
    /* @38 */	jbyte ___pad219;
    /* @39 */	jbyte ___pad220;
    /* com/sun/midp/io/NetworkConnectionBase */
    /* com/sun/midp/io/j2me/socket/Protocol */
    /* @40 */	jint handle;
    /* @44 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /* @48 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @56 */	jint port;
    /* @60 */	jbyte_array * JVM_FIELD_CONST ipBytes;
    /* @64 */	jboolean outputShutdown;
    /* @65 */	jboolean ownerTrusted;
    /* @66 */	jbyte ___pad221;
    /* @67 */	jbyte ___pad222;
};

struct Java_com_sun_midp_ssl_SSLStreamConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/SSLStreamConnection */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	struct Java_com_sun_midp_ssl_In * JVM_FIELD_CONST uin;
    /* @12 */	struct Java_com_sun_midp_ssl_Out * JVM_FIELD_CONST uout;
    /* @16 */	struct Java_java_io_InputStream * JVM_FIELD_CONST sin;
    /* @20 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST sout;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @28 */	jint port;
    /* @32 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST serverCert;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST cipherSuite;
    /* @40 */	jint inputStreamState;
    /* @44 */	jint outputStreamState;
    /* @48 */	jboolean copen;
    /* @49 */	jbyte ___pad223;
    /* @50 */	jbyte ___pad224;
    /* @51 */	jbyte ___pad225;
};

struct Java_javax_microedition_io_SecurityInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SecurityInfo */
};

struct Java_javax_microedition_io_HttpsConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/HttpsConnection */
};

struct Java_com_sun_midp_io_j2me_https_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad226;
    /* @22 */	jbyte ___pad227;
    /* @23 */	jbyte ___pad228;
    /* com/sun/midp/io/j2me/http/Protocol */
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /* @28 */	jint default_port;
    /* @32 */	struct Java_com_sun_midp_io_HttpUrl * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST hostAndPort;
    /* @40 */	jint responseCode;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST responseMsg;
    /* @48 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST reqProperties;
    /* @52 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST headerFields;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST method;
    /* @60 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST streamConnection;
    /* @64 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST streamOutput;
    /* @68 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST streamInput;
    /* @72 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST stringbuffer;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST httpVer;
    /* @80 */	jint contentLength;
    /* @84 */	jint chunksize;
    /* @88 */	jint totalbytesread;
    /* @92 */	jbyte_array * JVM_FIELD_CONST readbuf;
    /* @96 */	jint bytesleft;
    /* @100 */	jint bytesread;
    /* @104 */	jbyte_array * JVM_FIELD_CONST writebuf;
    /* @108 */	jint bytesToWrite;
    /* @112 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST __dup1__proxyHeaders;
    /* @116 */	jboolean __dup1__permissionChecked;
    /* @117 */	jboolean __dup1__ownerTrusted;
    /* @118 */	jboolean ConnectionCloseFlag;
    /* @119 */	jboolean chunkedIn;
    /* @120 */	jboolean chunkedOut;
    /* @121 */	jboolean firstChunkSent;
    /* @122 */	jboolean sendingRequest;
    /* @123 */	jboolean requestFinished;
    /* @124 */	jboolean eof;
    /* @125 */	jbyte handshakeError;
    /* @126 */	jboolean readInProgress;
    /* @127 */	jbyte ___pad229;
    /* com/sun/midp/io/j2me/https/Protocol */
    /* @128 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST proxyHeaders;
    /* @132 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST sslConnection;
    /* @136 */	jboolean permissionChecked;
    /* @137 */	jboolean ownerTrusted;
    /* @138 */	jbyte ___pad230;
    /* @139 */	jbyte ___pad231;
};

struct Java_com_sun_midp_ssl_Record {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Record */
    /*  @4 */	jint HEADER_SIZE;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* @12 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* @16 */	jbyte_array * JVM_FIELD_CONST inputHeader;
    /* @20 */	jint headerBytesRead;
    /* @24 */	jint dataLength;
    /* @28 */	jint dataBytesRead;
    /* @32 */	jbyte_array * JVM_FIELD_CONST inputData;
    /* @36 */	jint plainTextLength;
    /* @40 */	struct Java_com_sun_midp_ssl_RecordEncoder * JVM_FIELD_CONST encoder;
    /* @44 */	struct Java_com_sun_midp_ssl_RecordDecoder * JVM_FIELD_CONST decoder;
    /* @48 */	jbyte rActive;
    /* @49 */	jbyte wActive;
    /* @50 */	jbyte ver;
    /* @51 */	jboolean shutdown;
};

struct Java_com_sun_midp_ssl_In {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/ssl/In */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	jint start;
    /* @12 */	jint cnt;
    /* @16 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST ssc;
    /* @20 */	jboolean endOfStream;
    /* @21 */	jbyte ___pad232;
    /* @22 */	jbyte ___pad233;
    /* @23 */	jbyte ___pad234;
};

struct Java_com_sun_midp_ssl_Out {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/ssl/Out */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST ssc;
    /* @12 */	jbyte_array * JVM_FIELD_CONST buf;
};

struct Java_com_sun_midp_io_j2me_push_PushRegistryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/PushRegistryImpl */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
};

struct Java_com_sun_midp_io_j2me_socket_ServerSocket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/socket/ServerSocket */
};

struct Java_javax_microedition_io_StreamConnectionNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/StreamConnectionNotifier */
};

struct Java_javax_microedition_io_ServerSocketConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/ServerSocketConnection */
};

struct Java_com_sun_midp_io_j2me_serversocket_Socket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/serversocket/Socket */
    /*  @4 */	jint nativeHandle;
    /*  @8 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST privilegedSecurityToken;
    /* @12 */	jboolean connectionOpen;
    /* @13 */	jbyte ___pad235;
    /* @14 */	jbyte ___pad236;
    /* @15 */	jbyte ___pad237;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/Protocol */
    /*  @4 */	jint connectionMode;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @16 */	jint m_iport;
    /* @20 */	jint smsHandle;
    /* @24 */	jint m_mode;
    /* @28 */	struct Java_javax_wireless_messaging_MessageListener * JVM_FIELD_CONST m_listener;
    /* @32 */	struct Java_java_lang_Thread * JVM_FIELD_CONST m_listenerThread;
    /* @36 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @40 */	jint_array * JVM_FIELD_CONST restrictedPorts;
    /* @44 */	jboolean open;
    /* @45 */	jboolean openPermission;
    /* @46 */	jboolean readPermission;
    /* @47 */	jboolean writePermission;
    /* @48 */	jboolean doneRetrieving;
    /* @49 */	jbyte ___pad238;
    /* @50 */	jbyte ___pad239;
    /* @51 */	jbyte ___pad240;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/io/j2me/sms/Protocol$1 */
    /* @28 */	struct Java_javax_wireless_messaging_MessageConnection * JVM_FIELD_CONST val_044messageConnection;
    /* @32 */	struct Java_com_sun_midp_io_j2me_sms_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol_0004SMSPacket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/Protocol$SMSPacket */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST message;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST address;
    /* @12 */	jint port;
    /* @16 */	jlong sentAt;
    /* @24 */	jint messageType;
    /* @28 */	struct Java_com_sun_midp_io_j2me_sms_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_sms_TextEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/TextEncoder */
};

struct Java_javax_microedition_io_SecureConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SecureConnection */
};

struct Java_com_sun_midp_io_j2me_ssl_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ssl/Protocol */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_socket_Protocol * JVM_FIELD_CONST tcpConnection;
    /*  @8 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST sslConnection;
};

struct Java_com_sun_midp_lcdui_CommandAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/CommandAccess */
};

struct Java_com_sun_midp_midlet_MIDletEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventConsumer */
};

struct Java_com_sun_midp_lcdui_DisplayEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventConsumer */
};

struct Java_com_sun_midp_lcdui_DisplayAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayAccess */
};

struct Java_com_sun_midp_lcdui_DisplayContainer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayContainer */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint lastLocalDisplayId;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST displays;
};

struct Java_com_sun_midp_lcdui_DisplayDeviceAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayDeviceAccess */
    /*  @4 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST task;
    /*  @8 */	jint flashCount;
    /* @12 */	jboolean isLit;
    /* @13 */	jbyte ___pad241;
    /* @14 */	jbyte ___pad242;
    /* @15 */	jbyte ___pad243;
};

struct Java_com_sun_midp_lcdui_DisplayDeviceAccess_0004TimerClient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/lcdui/DisplayDeviceAccess$TimerClient */
    /* @28 */	jint displayId;
    /* @32 */	struct Java_com_sun_midp_lcdui_DisplayDeviceAccess * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_lcdui_DisplayEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_RepaintEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/RepaintEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent1;
    /* @12 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent2;
    /* @16 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent3;
    /* @20 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST queuedEvent;
    /* @24 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST eventInProcess;
};

struct Java_com_sun_midp_lcdui_DisplayEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventHandler */
};

struct Java_com_sun_midp_lcdui_DisplayEventHandlerFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventHandlerFactory */
};

struct Java_com_sun_midp_lcdui_LCDUIEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/lcdui/LCDUIEvent */
    /* @12 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST changedItem;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @20 */	struct Java_com_sun_midp_lcdui_DisplayEventConsumer * JVM_FIELD_CONST display;
    /* @24 */	jint minorCode;
    /* @28 */	jboolean hasForeground;
    /* @29 */	jbyte ___pad244;
    /* @30 */	jbyte ___pad245;
    /* @31 */	jbyte ___pad246;
};

struct Java_com_sun_midp_lcdui_EventConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/EventConstants */
};

struct Java_com_sun_midp_lcdui_GameMap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/GameMap */
};

struct Java_com_sun_midp_lcdui_ItemEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ItemEventConsumer */
};

struct Java_com_sun_midp_lcdui_LCDUIEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/LCDUIEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_ItemEventConsumer * JVM_FIELD_CONST itemEventConsumer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_PhoneDial {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/PhoneDial */
};

struct Java_com_sun_midp_lcdui_RepaintEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/lcdui/RepaintEvent */
    /* @12 */	jint paintX1;
    /* @16 */	jint paintY1;
    /* @20 */	jint paintX2;
    /* @24 */	jint paintY2;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST paintTarget;
    /* @32 */	jint perUseID;
    /* @36 */	struct Java_com_sun_midp_lcdui_DisplayEventConsumer * JVM_FIELD_CONST display;
};

struct Java_com_sun_midp_lcdui_SystemAlert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad247;
    /* @30 */	jbyte ___pad248;
    /* @31 */	jbyte ___pad249;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
    /* com/sun/midp/lcdui/SystemAlert */
    /* @72 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @76 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
};

struct Java_com_sun_midp_lcdui_TextInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextInfo */
    /*  @4 */	jint numLines;
    /*  @8 */	jint visLines;
    /* @12 */	jint topVis;
    /* @16 */	jint cursorLine;
    /* @20 */	jint_array * JVM_FIELD_CONST lineStart;
    /* @24 */	jint_array * JVM_FIELD_CONST lineEnd;
    /* @28 */	jint height;
    /* @32 */	jboolean isModified;
    /* @33 */	jboolean scrollY;
    /* @34 */	jboolean scrollX;
    /* @35 */	jbyte ___pad250;
};

struct Java_com_sun_midp_lcdui_Text {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/Text */
};

struct Java_com_sun_midp_lcdui_TextPolicy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextPolicy */
};

struct Java_com_sun_midp_log_LogChannels {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/LogChannels */
};

struct Java_com_sun_midp_log_Logging {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/Logging */
};

struct Java_com_sun_midp_main_MIDletExecuteEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletExecuteEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	jint amsIsolateId;
};

struct Java_com_sun_midp_main_StartMIDletMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/StartMIDletMonitor */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet;
    /* @12 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST isolate;
};

struct Java_com_sun_midp_main_AmsUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AmsUtil */
};

struct Java_com_sun_midp_main_AppImageWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AppImageWriter */
};

struct Java_com_sun_midp_main_AppIsolateMIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AppIsolateMIDletSuiteLoader */
};

struct Java_com_sun_midp_main_CommandState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CommandState */
    /*  @4 */	jint status;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteID;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST lastSuiteID;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
    /* @36 */	jboolean logoDisplayed;
    /* @37 */	jbyte ___pad251;
    /* @38 */	jbyte ___pad252;
    /* @39 */	jbyte ___pad253;
};

struct Java_com_sun_midp_main_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/Configuration */
};

struct Java_com_sun_midp_main_ExecuteMIDletEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/ExecuteMIDletEventListener */
    /*  @4 */	jint externalAppId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
};

struct Java_com_sun_midp_main_IndicatorManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IndicatorManager */
};

struct Java_com_sun_midp_main_IsolateMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateMonitor */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST isolates;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
};

struct Java_com_sun_midp_main_IsolateMonitorListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateMonitorListener */
};

struct Java_com_sun_midp_main_TerminationNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/TerminationNotifier */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST midlet;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST isolate;
    /* @12 */	struct Java_com_sun_midp_main_IsolateMonitor * JVM_FIELD_CONST parent;
};

struct Java_com_sun_midp_main_MIDletAppImageGenerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletAppImageGenerator */
};

struct Java_com_sun_midp_main_MIDletAppImageGeneratorBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletAppImageGeneratorBase */
};

struct Java_com_sun_midp_main_MIDletControllerEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventConsumer */
};

struct Java_com_sun_midp_main_MIDletControllerEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventListener */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletControllerEventConsumer * JVM_FIELD_CONST midletControllerEventConsumer;
};

struct Java_com_sun_midp_main_MIDletDestroyTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletDestroyTimer */
};

struct Java_com_sun_midp_main_TerminateMIDlet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/main/TerminateMIDlet */
    /* @28 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST mp;
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST mpl;
};

struct Java_com_sun_midp_midlet_MIDletEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_main_MIDletProxyUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyUtils */
};

struct Java_com_sun_midp_main_MIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletSuiteLoader */
};

struct Java_com_sun_midp_main_MIDletSuiteVerifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletSuiteVerifier */
};

struct Java_com_sun_midp_midlet_MIDletEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_javax_microedition_midlet_MIDletStateChangeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/midlet/MIDletStateChangeException */
};

struct Java_com_sun_midp_payment_PAPICleanUp {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/payment/PAPICleanUp */
};

struct Java_com_sun_midp_pki_Utils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/Utils */
};

struct Java_com_sun_midp_publickeystore_Storage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
};

struct Java_com_sun_midp_publickeystore_OutputStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
    /* com/sun/midp/publickeystore/OutputStorage */
    /*  @4 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST out;
};

struct Java_com_sun_midp_publickeystore_PublicKeyStoreBuilderBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST __dup1__keyList;
    /* com/sun/midp/publickeystore/PublicKeyStoreBuilderBase */
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
};

struct Java_com_sun_midp_rms_AbstractRecordStoreFile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/AbstractRecordStoreFile */
};

struct Java_com_sun_midp_rms_AbstractRecordStoreImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/AbstractRecordStoreImpl */
};

struct Java_com_sun_midp_rms_IntToIntMapper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/IntToIntMapper */
    /*  @4 */	jint_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint_array * JVM_FIELD_CONST elementKey;
    /* @12 */	jint elementCount;
    /* @16 */	jint capacityIncrement;
    /* @20 */	jint defaultValue;
};

struct Java_com_sun_midp_rms_OffsetCache {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/IntToIntMapper */
    /*  @4 */	jint_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint_array * JVM_FIELD_CONST elementKey;
    /* @12 */	jint elementCount;
    /* @16 */	jint capacityIncrement;
    /* @20 */	jint defaultValue;
    /* com/sun/midp/rms/OffsetCache */
    /* @24 */	jint LastSeenOffset;
};

struct Java_com_sun_midp_rms_RMSConfig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RMSConfig */
};

struct Java_com_sun_midp_rms_RecordStoreFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreFactory */
};

struct Java_com_sun_midp_rms_RecordStoreFile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreFile */
    /*  @4 */	jint handle;
};

struct Java_com_sun_midp_rms_RecordStoreIndex {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreIndex */
    /*  @4 */	struct Java_com_sun_midp_rms_AbstractRecordStoreImpl * JVM_FIELD_CONST recordStore;
    /*  @8 */	struct Java_com_sun_midp_rms_AbstractRecordStoreFile * JVM_FIELD_CONST dbFile;
    /* @12 */	struct Java_com_sun_midp_rms_OffsetCache * JVM_FIELD_CONST recordIdOffsets;
};

struct Java_com_sun_midp_rms_RecordStoreImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreImpl */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST compactBuffer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteID;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST rsLock;
    /* @16 */	jbyte_array * JVM_FIELD_CONST dbHeader;
    /* @20 */	struct Java_com_sun_midp_rms_RecordStoreIndex * JVM_FIELD_CONST dbIndex;
    /* @24 */	struct Java_com_sun_midp_rms_RecordStoreFile * JVM_FIELD_CONST dbFile;
};

struct Java_javax_microedition_rms_RecordStoreNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreNotFoundException */
};

struct Java_javax_microedition_rms_RecordStoreFullException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreFullException */
};

struct Java_javax_microedition_rms_InvalidRecordIDException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/InvalidRecordIDException */
};

struct Java_com_sun_midp_rms_RecordStoreUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreUtil */
};

struct Java_com_sun_midp_security_PermissionDialog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionDialog */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /*  @8 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST yesCmd;
    /* @12 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST noCmd;
    /* @16 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @20 */	jboolean answer;
    /* @21 */	jbyte ___pad254;
    /* @22 */	jbyte ___pad255;
    /* @23 */	jbyte ___pad256;
};

struct Java_com_sun_midp_security_PermissionSpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionSpec */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_com_sun_midp_security_PermissionGroup * JVM_FIELD_CONST group;
};

struct Java_com_sun_midp_security_Permissions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/Permissions */
};

struct Java_com_sun_midp_security_SecurityInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityInitializer */
};

struct Java_com_sun_midp_ssl_CipherSuiteData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/CipherSuiteData */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST clientMACSecret;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST serverMACSecret;
    /* @12 */	jbyte_array * JVM_FIELD_CONST clientKey;
    /* @16 */	jbyte_array * JVM_FIELD_CONST serverKey;
    /* @20 */	jbyte_array * JVM_FIELD_CONST clientIV;
    /* @24 */	jbyte_array * JVM_FIELD_CONST serverIV;
    /* @28 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST clientBulkKey;
    /* @32 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST serverBulkKey;
    /* @36 */	jint digestLength;
    /* @40 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST encodeDigest;
    /* @44 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST decodeDigest;
    /* @48 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST encodeCipher;
    /* @52 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST decodeCipher;
    /* @56 */	jint padLength;
    /* @60 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md;
    /* @64 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST sd;
    /* @68 */	jbyte_array * JVM_FIELD_CONST keyBlock;
    /* @72 */	jbyte suiteType;
    /* @73 */	jbyte ___pad257;
    /* @74 */	jbyte ___pad258;
    /* @75 */	jbyte ___pad259;
};

struct Java_com_sun_midp_ssl_Session {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Session */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /*  @8 */	jint port;
    /* @12 */	jbyte_array * JVM_FIELD_CONST id;
    /* @16 */	jbyte_array * JVM_FIELD_CONST master;
    /* @20 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST cert;
};

struct Java_com_sun_midp_ssl_Handshake {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Handshake */
    /*  @4 */	struct Java_com_sun_midp_pki_CertStore * JVM_FIELD_CONST certStore;
    /*  @8 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST peerHost;
    /* @16 */	jint peerPort;
    /* @20 */	struct Java_com_sun_midp_crypto_SecureRandom * JVM_FIELD_CONST rnd;
    /* @24 */	struct Java_com_sun_midp_ssl_Session * JVM_FIELD_CONST cSession;
    /* @28 */	jbyte_array * JVM_FIELD_CONST sSessionId;
    /* @32 */	jbyte_array * JVM_FIELD_CONST crand;
    /* @36 */	jbyte_array * JVM_FIELD_CONST srand;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST negSuiteName;
    /* @44 */	jbyte_array * JVM_FIELD_CONST preMaster;
    /* @48 */	jbyte_array * JVM_FIELD_CONST master;
    /* @52 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST eKey;
    /* @56 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST sCert;
    /* @60 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST ourMD5;
    /* @64 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST ourSHA;
    /* @68 */	jint start;
    /* @72 */	jint nextMsgStart;
    /* @76 */	jint cnt;
    /* @80 */	jbyte ver;
    /* @81 */	jbyte role;
    /* @82 */	jbyte negSuite;
    /* @83 */	jbyte gotCertReq;
};

struct Java_com_sun_midp_ssl_MAC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
};

struct Java_com_sun_midp_ssl_RecordEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
    /* com/sun/midp/ssl/RecordEncoder */
    /* @28 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_ssl_RecordDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
    /* com/sun/midp/ssl/RecordDecoder */
    /* @28 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_ssl_SSLSecurityInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/SSLSecurityInfo */
    /*  @4 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST parent;
};

struct Java_com_sun_midp_util_DateParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/DateParser */
    /*  @4 */	jint year;
    /*  @8 */	jint month;
    /* @12 */	jint day;
    /* @16 */	jint hour;
    /* @20 */	jint minute;
    /* @24 */	jint second;
    /* @28 */	jint milli;
    /* @32 */	jint tzoffset;
    /* @36 */	jint_array * JVM_FIELD_CONST days_in_month;
    /* @40 */	jobject_array * JVM_FIELD_CONST month_shorts;
    /* @44 */	jobject_array * JVM_FIELD_CONST weekday_shorts;
};

struct Java_com_sun_midp_util_ResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/ResourceHandler */
};

struct Java_com_sun_midp_wma_WMACleanupMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/wma/WMACleanupMonitor */
};

struct Java_com_sun_mmedia_Buffer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Buffer */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST data;
    /*  @8 */	jint offset;
    /* @12 */	jint length;
};

struct Java_com_sun_mmedia_AudioDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/AudioDecoder */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST fourcc_encoding;
    /*  @8 */	jint sampleRate;
    /* @12 */	jint channels;
};

struct Java_com_sun_mmedia_AMRDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/AudioDecoder */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST fourcc_encoding;
    /*  @8 */	jint sampleRate;
    /* @12 */	jint channels;
    /* com/sun/mmedia/AMRDecoder */
    /* @16 */	jint frameSizeInSamples;
    /* @20 */	jint decoderType;
    /* @24 */	jint nativePeer;
};

struct Java_javax_microedition_media_MediaException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/media/MediaException */
};

struct Java_javax_microedition_media_protocol_SourceStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/SourceStream */
};

struct Java_javax_microedition_media_protocol_DataSource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
};

struct Java_com_sun_mmedia_BasicPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @44 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @48 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @52 */	jlong stopTime;
    /* @60 */	jint eventQueueSize;
    /* @64 */	jlong origin;
    /* @72 */	jlong offset;
    /* @80 */	jlong time;
    /* @88 */	jlong sysOffset;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @100 */	jint NOT_SEEKABLE;
    /* @104 */	jint SEEKABLE_TO_START;
    /* @108 */	jint RANDOM_ACCESSIBLE;
    /* @112 */	jboolean EOM;
    /* @113 */	jboolean loopAfterEOM;
    /* @114 */	jboolean listenersModified;
    /* @115 */	jboolean isTrusted;
    /* @116 */	jboolean closedDelivered;
    /* @117 */	jboolean hasDataSource;
    /* @118 */	jboolean useSystemTime;
    /* @119 */	jbyte ___pad260;
};

struct Java_com_sun_mmedia_VolCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/VolCtrl */
    /*  @4 */	jint level;
    /*  @8 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
    /* @12 */	jboolean muted;
    /* @13 */	jbyte ___pad261;
    /* @14 */	jbyte ___pad262;
    /* @15 */	jbyte ___pad263;
};

struct Java_com_sun_mmedia_PCMAudioOut {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/PCMAudioOut */
};

struct Java_com_sun_mmedia_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
};

struct Java_com_sun_mmedia_RecordCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/RecordCtrl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST fileName;
    /* @12 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpCon;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST localFileName;
    /* @20 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST httpOutputStream;
    /* @24 */	jint localFilePointer;
    /* @28 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST stream;
    /* @32 */	jbyte_array * JVM_FIELD_CONST localBuffer;
    /* @36 */	jint CHUNK_SIZE;
    /* @40 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
    /* @44 */	jint sizeLimit;
    /* @48 */	jint headerSize;
    /* @52 */	jint dataSize;
    /* @56 */	struct Java_com_sun_mmedia_protocol_FileConnectionSubstitute * JVM_FIELD_CONST fileConnSubst;
    /* @60 */	struct Java_com_sun_mmedia_protocol_FileConnectionSubstitute * JVM_FIELD_CONST fileTemp;
    /* @64 */	jboolean RECORD;
    /* @65 */	jboolean RECORD_TO_FILE;
    /* @66 */	jboolean RECORD_TO_HTTP;
    /* @67 */	jboolean recordRequested;
    /* @68 */	jboolean recording;
    /* @69 */	jbyte ___pad264;
    /* @70 */	jbyte ___pad265;
    /* @71 */	jbyte ___pad266;
};

struct Java_com_sun_mmedia_MetaCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MetaCtrl */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST data;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST map;
};

struct Java_com_sun_mmedia_MIDletPauseListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDletPauseListener */
};

struct Java_com_sun_mmedia_PlayerEventQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/mmedia/PlayerEventQueue */
    /* @28 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST p;
    /* @32 */	struct Java_com_sun_mmedia_EventQueueEntry * JVM_FIELD_CONST evt;
};

struct Java_javax_microedition_media_TimeBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/TimeBase */
};

struct Java_javax_microedition_media_Player {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Player */
};

struct Java_javax_microedition_media_Control {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Control */
};

struct Java_javax_microedition_media_control_StopTimeControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/StopTimeControl */
};

struct Java_javax_microedition_media_Controllable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Controllable */
};

struct Java_javax_microedition_media_PlayerListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/PlayerListener */
};

struct Java_com_sun_mmedia_AMRPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @44 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @48 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @52 */	jlong stopTime;
    /* @60 */	jint eventQueueSize;
    /* @64 */	jlong __dup1__origin;
    /* @72 */	jlong offset;
    /* @80 */	jlong time;
    /* @88 */	jlong sysOffset;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @100 */	jint NOT_SEEKABLE;
    /* @104 */	jint SEEKABLE_TO_START;
    /* @108 */	jint RANDOM_ACCESSIBLE;
    /* @112 */	jboolean EOM;
    /* @113 */	jboolean loopAfterEOM;
    /* @114 */	jboolean listenersModified;
    /* @115 */	jboolean isTrusted;
    /* @116 */	jboolean closedDelivered;
    /* @117 */	jboolean hasDataSource;
    /* @118 */	jboolean useSystemTime;
    /* @119 */	jbyte ___pad267;
    /* com/sun/mmedia/AMRPlayer */
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST fourcc_encoding;
    /* @124 */	struct Java_com_sun_mmedia_Buffer * JVM_FIELD_CONST inBuffer;
    /* @128 */	struct Java_com_sun_mmedia_Buffer * JVM_FIELD_CONST bufferObject;
    /* @132 */	struct Java_com_sun_mmedia_PCMAudioOut * JVM_FIELD_CONST renderer;
    /* @136 */	struct Java_com_sun_mmedia_PCMAudioOut * JVM_FIELD_CONST altRenderer;
    /* @140 */	struct Java_com_sun_mmedia_AMRDecoder * JVM_FIELD_CONST decoder;
    /* @144 */	struct Java_java_lang_String * JVM_FIELD_CONST contentType;
    /* @148 */	jint_array * JVM_FIELD_CONST framesizes;
    /* @152 */	jint maxFrameSize;
    /* @156 */	jint numFrames;
    /* @160 */	jint maxFrameNumber;
    /* @164 */	jint currentFrameNumber;
    /* @168 */	jint currentMaxFrameNumber;
    /* @172 */	jlong contentLength;
    /* @180 */	jint seekType;
    /* @184 */	struct Java_com_sun_mmedia_VolCtrl * JVM_FIELD_CONST vc;
    /* @188 */	struct Java_com_sun_mmedia_RecordCtrl * JVM_FIELD_CONST recordControl;
    /* @192 */	struct Java_com_sun_mmedia_MetaCtrl * JVM_FIELD_CONST meta;
    /* @196 */	jint sampleRate;
    /* @200 */	jint channels;
    /* @204 */	jint sampleSizeInBits;
    /* @208 */	jlong lastPos;
    /* @216 */	jlong origin;
    /* @224 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @228 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @232 */	jlong startpt;
    /* @240 */	jlong endpt;
    /* @248 */	jint bufLen;
    /* @252 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @256 */	jlong duration;
    /* @264 */	struct Java_java_lang_Object * JVM_FIELD_CONST pauseLock;
    /* @268 */	struct Java_java_lang_Object * JVM_FIELD_CONST waveLock;
    /* @272 */	struct Java_java_lang_String * JVM_FIELD_CONST AMR;
    /* @276 */	struct Java_java_lang_String * JVM_FIELD_CONST AMR_WB;
    /* @280 */	struct Java_java_lang_Object * JVM_FIELD_CONST readLock;
    /* @284 */	jlong mediaTimeCache;
    /* @292 */	struct Java_java_lang_String * JVM_FIELD_CONST errMsg;
    /* @296 */	struct Java_java_lang_String * JVM_FIELD_CONST runErr;
    /* @300 */	jbyte_array * JVM_FIELD_CONST intArray;
    /* @304 */	jboolean started;
    /* @305 */	jboolean interrupted;
    /* @306 */	jboolean isBigEndian;
    /* @307 */	jboolean isSigned;
    /* @308 */	jboolean canPause;
    /* @309 */	jboolean isCapturePlayer;
    /* @310 */	jbyte ___pad268;
    /* @311 */	jbyte ___pad269;
};

struct Java_javax_microedition_media_control_VolumeControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/VolumeControl */
};

struct Java_javax_microedition_media_control_MetaDataControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/MetaDataControl */
};

struct Java_com_sun_mmedia_VideoRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/VideoRenderer */
};

struct Java_com_sun_mmedia_TonePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/TonePlayer */
};

struct Java_com_sun_mmedia_ImageAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/ImageAccess */
};

struct Java_com_sun_mmedia_DefaultConfiguration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
    /* com/sun/mmedia/DefaultConfiguration */
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedProtocols;
    /* @24 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedContentTypes;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST nullContentTypes;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST captureContentTypes;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST deviceContentTypes;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST fileContentTypes;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST httpContentTypes;
    /* @48 */	jboolean needAMMS;
    /* @49 */	jboolean needQSound;
    /* @50 */	jbyte ___pad270;
    /* @51 */	jbyte ___pad271;
};

struct Java_com_sun_mmedia_CougarQSoundMmapiConfig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
    /* com/sun/mmedia/DefaultConfiguration */
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedProtocols;
    /* @24 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedContentTypes;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST nullContentTypes;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST captureContentTypes;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST deviceContentTypes;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST fileContentTypes;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST httpContentTypes;
    /* @48 */	jboolean needAMMS;
    /* @49 */	jboolean needQSound;
    /* @50 */	jbyte ___pad272;
    /* @51 */	jbyte ___pad273;
    /* com/sun/mmedia/CougarQSoundMmapiConfig */
};

struct Java_com_sun_mmedia_MIDPImageAccessor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDPImageAccessor */
};

struct Java_com_sun_mmedia_QSoundSynthPerformance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundSynthPerformance */
    /*  @4 */	jint qsmPeer;
    /*  @8 */	jint spPeer;
    /* @12 */	jint gmPeer;
    /* @16 */	jint tchnl;
};

struct Java_com_sun_mmedia_QSoundTonePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundTonePlayer */
    /*  @4 */	struct Java_com_sun_mmedia_QSoundSynthPerformance * JVM_FIELD_CONST qsSP;
};

struct Java_com_sun_mmedia_QSoundVolumeCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundVolumeCtrl */
    /*  @4 */	jint peer;
    /*  @8 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
};

struct Java_com_sun_mmedia_QSoundRateCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundRateCtrl */
    /*  @4 */	jint peer;
};

struct Java_com_sun_mmedia_QSoundConnectable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundConnectable */
};

struct Java_com_sun_mmedia_QSoundPCMOut {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundPCMOut */
    /*  @4 */	jint peer;
    /*  @8 */	jint em_peer;
    /* @12 */	struct Java_com_sun_mmedia_QSoundConnectable * JVM_FIELD_CONST qc;
    /* @16 */	jlong bytesPerMilliSecond;
    /* @24 */	jlong byteCount;
    /* @32 */	struct Java_com_sun_mmedia_QSoundVolumeCtrl * JVM_FIELD_CONST vc;
    /* @36 */	struct Java_com_sun_mmedia_QSoundRateCtrl * JVM_FIELD_CONST rc;
};

struct Java_com_sun_mmedia_MMHelper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMHelper */
};

struct Java_com_sun_mmedia_MIDPVideoPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDPVideoPainter */
};

struct Java_com_sun_mmedia_MIDPVideoRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/VideoRenderer */
    /* com/sun/mmedia/MIDPVideoRenderer */
    /*  @4 */	struct Java_com_sun_mmedia_MIDPVideoRenderer_0004MMItem * JVM_FIELD_CONST mmItem;
    /*  @8 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST canvas;
    /* @12 */	jint mode;
    /* @16 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
    /* @20 */	jint dx;
    /* @24 */	jint tmpdx;
    /* @28 */	jint dy;
    /* @32 */	jint tmpdy;
    /* @36 */	jint dw;
    /* @40 */	jint tmpdw;
    /* @44 */	jint dh;
    /* @48 */	jint tmpdh;
    /* @52 */	jint videoWidth;
    /* @56 */	jint videoHeight;
    /* @60 */	jbyte_array * JVM_FIELD_CONST tempSnapData;
    /* @64 */	jint frameCount;
    /* @68 */	jlong frameStartTime;
    /* @76 */	struct Java_java_lang_Object * JVM_FIELD_CONST dispBoundsLock;
    /* @80 */	jint rgbMode;
    /* @84 */	jint pWidth;
    /* @88 */	jint pHeight;
    /* @92 */	jint_array * JVM_FIELD_CONST rgbData;
    /* @96 */	jint_array * JVM_FIELD_CONST scaledRGB;
    /* @100 */	jbyte_array * JVM_FIELD_CONST pngData;
    /* @104 */	jint pngDataLength;
    /* @108 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @112 */	struct Java_com_sun_mmedia_MMHelper * JVM_FIELD_CONST mmh;
    /* @116 */	jboolean fsmode;
    /* @117 */	jboolean closed;
    /* @118 */	jboolean cvis;
    /* @119 */	jboolean pvis;
    /* @120 */	jboolean nativeRender;
    /* @121 */	jboolean useAlpha;
    /* @122 */	jbyte ___pad274;
    /* @123 */	jbyte ___pad275;
};

struct Java_com_sun_mmedia_MIDPVideoRenderer_0004MMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/MMCustomItem */
    /* @48 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST fullScreen;
    /* @52 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST oldDisplayable;
    /* @60 */	struct Java_javax_microedition_media_control_VideoControl * JVM_FIELD_CONST callerVideoControl;
    /* @64 */	struct Java_com_sun_mmedia_MIDPVideoPainter * JVM_FIELD_CONST videoPainter;
    /* com/sun/mmedia/MIDPVideoRenderer$MMItem */
    /* @68 */	jint ody;
    /* @72 */	jint odh;
    /* @76 */	jint odw;
    /* @80 */	jint_array * JVM_FIELD_CONST frame;
    /* @84 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @88 */	struct Java_java_lang_Object * JVM_FIELD_CONST imageLock;
    /* @92 */	struct Java_com_sun_mmedia_MIDPVideoRenderer * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_media_control_VideoControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/VideoControl */
};

struct Java_javax_microedition_media_control_GUIControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/GUIControl */
};

struct Java_com_sun_mmedia_EventQueueEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/EventQueueEntry */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST data;
    /* @12 */	struct Java_com_sun_mmedia_EventQueueEntry * JVM_FIELD_CONST link;
};

struct Java_com_sun_mmedia_FileIO {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/FileIO */
};

struct Java_com_sun_mmedia_FormatConversionUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/FormatConversionUtils */
};

struct Java_com_sun_mmedia_GIFImageDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFImageDecoder */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	jint colorDepth;
    /* @16 */	jint globalColorDepth;
    /* @20 */	jint curColorDepth;
    /* @24 */	jbyte_array * JVM_FIELD_CONST globalPalette;
    /* @28 */	jbyte_array * JVM_FIELD_CONST curPalette;
    /* @32 */	jint_array * JVM_FIELD_CONST argb;
    /* @36 */	jint_array * JVM_FIELD_CONST curArgb;
    /* @40 */	jint backgroundIndex;
    /* @44 */	jint transparentColorIndex;
    /* @48 */	jint undrawFlag;
    /* @52 */	jint framePosX;
    /* @56 */	jint framePosY;
    /* @60 */	jint frameWidth;
    /* @64 */	jint frameHeight;
    /* @68 */	jshort_array * JVM_FIELD_CONST prefix;
    /* @72 */	jbyte_array * JVM_FIELD_CONST suffix;
    /* @76 */	jbyte_array * JVM_FIELD_CONST outCode;
    /* @80 */	jboolean interlace;
    /* @81 */	jbyte ___pad276;
    /* @82 */	jbyte ___pad277;
    /* @83 */	jbyte ___pad278;
};

struct Java_com_sun_mmedia_GIFPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @44 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @48 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @52 */	jlong stopTime;
    /* @60 */	jint eventQueueSize;
    /* @64 */	jlong origin;
    /* @72 */	jlong offset;
    /* @80 */	jlong time;
    /* @88 */	jlong sysOffset;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @100 */	jint NOT_SEEKABLE;
    /* @104 */	jint SEEKABLE_TO_START;
    /* @108 */	jint RANDOM_ACCESSIBLE;
    /* @112 */	jboolean EOM;
    /* @113 */	jboolean loopAfterEOM;
    /* @114 */	jboolean listenersModified;
    /* @115 */	jboolean isTrusted;
    /* @116 */	jboolean closedDelivered;
    /* @117 */	jboolean hasDataSource;
    /* @118 */	jboolean useSystemTime;
    /* @119 */	jbyte ___pad279;
    /* com/sun/mmedia/GIFPlayer */
    /* @120 */	struct Java_com_sun_mmedia_GIFImageDecoder * JVM_FIELD_CONST imageDecoder;
    /* @124 */	jint videoWidth;
    /* @128 */	jint videoHeight;
    /* @132 */	jint_array * JVM_FIELD_CONST referenceFrame;
    /* @136 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @140 */	jlong startTime;
    /* @148 */	jlong EARLY_THRESHOLD;
    /* @156 */	jlong MIN_WAIT;
    /* @164 */	jlong ZERO_DURATION_WAIT;
    /* @172 */	struct Java_java_util_Vector * JVM_FIELD_CONST frameTimes;
    /* @176 */	jint frameCount;
    /* @180 */	jint scanFrameTime;
    /* @184 */	jlong mediaTimeOffset;
    /* @192 */	jlong displayTime;
    /* @200 */	struct Java_com_sun_mmedia_VideoRenderer * JVM_FIELD_CONST videoRenderer;
    /* @204 */	struct Java_javax_microedition_media_control_VideoControl * JVM_FIELD_CONST videoControl;
    /* @208 */	struct Java_com_sun_mmedia_GIFPlayer_0004FramePosCtrl * JVM_FIELD_CONST framePosControl;
    /* @212 */	struct Java_com_sun_mmedia_GIFPlayer_0004RateCtrl * JVM_FIELD_CONST rateControl;
    /* @216 */	jlong duration;
    /* @224 */	jint seekType;
    /* @228 */	jlong firstFramePos;
    /* @236 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @240 */	jbyte_array * JVM_FIELD_CONST imageData;
    /* @244 */	jint imageDataLength;
    /* @248 */	jint lzwCodeSize;
    /* @252 */	jbyte_array * JVM_FIELD_CONST oneByte;
    /* @256 */	jboolean done;
    /* @257 */	jboolean stopped;
    /* @258 */	jbyte ___pad280;
    /* @259 */	jbyte ___pad281;
};

struct Java_com_sun_mmedia_GIFPlayer_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFPlayer$1 */
    /*  @4 */	struct Java_com_sun_mmedia_GIFPlayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_GIFPlayer_0004RateCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFPlayer$RateCtrl */
    /*  @4 */	jint rate;
    /*  @8 */	jint MIN_PLAYBACK_RATE;
    /* @12 */	jint MAX_PLAYBACK_RATE;
    /* @16 */	struct Java_com_sun_mmedia_GIFPlayer * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_media_control_FramePositioningControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/FramePositioningControl */
};

struct Java_com_sun_mmedia_GIFPlayer_0004FramePosCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/GIFPlayer$FramePosCtrl */
    /*  @4 */	struct Java_com_sun_mmedia_GIFPlayer * JVM_FIELD_CONST this_0440;
    /*  @8 */	jboolean active;
    /* @9 */	jbyte ___pad282;
    /* @10 */	jbyte ___pad283;
    /* @11 */	jbyte ___pad284;
};

struct Java_javax_microedition_media_control_RateControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/RateControl */
};

struct Java_com_sun_mmedia_ImageEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/ImageEncoder */
};

struct Java_com_sun_mmedia_MIDPRendererCanvasBuddy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDPRendererCanvasBuddy */
};

struct Java_com_sun_mmedia_MMCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/mmedia/MMCustomItem */
    /* @48 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST fullScreen;
    /* @52 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST oldDisplayable;
    /* @60 */	struct Java_javax_microedition_media_control_VideoControl * JVM_FIELD_CONST callerVideoControl;
    /* @64 */	struct Java_com_sun_mmedia_MIDPVideoPainter * JVM_FIELD_CONST videoPainter;
};

struct Java_com_sun_mmedia_MMCustomItem_0004FullScreenCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad285;
    /* @30 */	jbyte ___pad286;
    /* @31 */	jbyte ___pad287;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad288;
    /* @38 */	jbyte ___pad289;
    /* @39 */	jbyte ___pad290;
    /* com/sun/mmedia/MMCustomItem$FullScreenCanvas */
    /* @40 */	struct Java_com_sun_mmedia_MMCustomItem * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_MMEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMEventHandler */
};

struct Java_com_sun_mmedia_PermissionAccessor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/PermissionAccessor */
};

struct Java_com_sun_mmedia_QSoundGlobalEffectModule {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundGlobalEffectModule */
    /*  @4 */	jint peer;
    /*  @8 */	jint gmPeer;
    /* @12 */	jint gmMIDIPeer;
};

struct Java_com_sun_mmedia_QSoundRenderThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/mmedia/QSoundRenderThread */
    /* @28 */	jint gm;
    /* @32 */	jboolean keepRendering;
    /* @33 */	jbyte ___pad291;
    /* @34 */	jbyte ___pad292;
    /* @35 */	jbyte ___pad293;
};

struct Java_com_sun_mmedia_QSoundHiddenManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundHiddenManager */
};

struct Java_com_sun_mmedia_QSoundMIDIConnectable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIConnectable */
};

struct Java_javax_microedition_media_control_MIDIControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/MIDIControl */
};

struct Java_com_sun_mmedia_QSoundMIDICtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDICtrl */
    /*  @4 */	jint peer;
    /*  @8 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
};

struct Java_com_sun_mmedia_QSoundPitchCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundPitchCtrl */
    /*  @4 */	jint peer;
};

struct Java_com_sun_mmedia_QSoundTempoCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundTempoCtrl */
    /*  @4 */	jint peer;
};

struct Java_com_sun_mmedia_QSoundMetaDataCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMetaDataCtrl */
    /*  @4 */	jint peer;
};

struct Java_com_sun_mmedia_QSoundMIDIPlayBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIPlayBase */
    /*  @4 */	jint qsMIDI;
    /*  @8 */	jint globMan;
    /* @12 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
    /* @16 */	jint loopCount;
    /* @20 */	jint currentLoopCount;
    /* @24 */	jint lastLoopCount;
    /* @28 */	jboolean opened;
    /* @29 */	jbyte ___pad294;
    /* @30 */	jbyte ___pad295;
    /* @31 */	jbyte ___pad296;
};

struct Java_com_sun_mmedia_QSoundMIDIPlayControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIPlayBase */
    /*  @4 */	jint qsMIDI;
    /*  @8 */	jint globMan;
    /* @12 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
    /* @16 */	jint loopCount;
    /* @20 */	jint currentLoopCount;
    /* @24 */	jint lastLoopCount;
    /* @28 */	jboolean opened;
    /* @29 */	jbyte ___pad297;
    /* @30 */	jbyte ___pad298;
    /* @31 */	jbyte ___pad299;
    /* com/sun/mmedia/QSoundMIDIPlayControl */
    /* @32 */	struct Java_com_sun_mmedia_QSoundVolumeCtrl * JVM_FIELD_CONST vc;
    /* @36 */	struct Java_com_sun_mmedia_QSoundMIDICtrl * JVM_FIELD_CONST mc;
    /* @40 */	struct Java_com_sun_mmedia_QSoundPitchCtrl * JVM_FIELD_CONST pc;
    /* @44 */	struct Java_com_sun_mmedia_QSoundRateCtrl * JVM_FIELD_CONST rc;
    /* @48 */	struct Java_com_sun_mmedia_QSoundTempoCtrl * JVM_FIELD_CONST tc;
    /* @52 */	struct Java_com_sun_mmedia_QSoundMetaDataCtrl * JVM_FIELD_CONST dc;
};

struct Java_com_sun_mmedia_QSoundMIDINullPlayControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIPlayBase */
    /*  @4 */	jint qsMIDI;
    /*  @8 */	jint globMan;
    /* @12 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
    /* @16 */	jint loopCount;
    /* @20 */	jint currentLoopCount;
    /* @24 */	jint lastLoopCount;
    /* @28 */	jboolean opened;
    /* @29 */	jbyte ___pad300;
    /* @30 */	jbyte ___pad301;
    /* @31 */	jbyte ___pad302;
    /* com/sun/mmedia/QSoundMIDIPlayControl */
    /* @32 */	struct Java_com_sun_mmedia_QSoundVolumeCtrl * JVM_FIELD_CONST __dup1__vc;
    /* @36 */	struct Java_com_sun_mmedia_QSoundMIDICtrl * JVM_FIELD_CONST __dup1__mc;
    /* @40 */	struct Java_com_sun_mmedia_QSoundPitchCtrl * JVM_FIELD_CONST pc;
    /* @44 */	struct Java_com_sun_mmedia_QSoundRateCtrl * JVM_FIELD_CONST rc;
    /* @48 */	struct Java_com_sun_mmedia_QSoundTempoCtrl * JVM_FIELD_CONST tc;
    /* @52 */	struct Java_com_sun_mmedia_QSoundMetaDataCtrl * JVM_FIELD_CONST dc;
    /* com/sun/mmedia/QSoundMIDINullPlayControl */
    /* @56 */	struct Java_com_sun_mmedia_QSoundVolumeCtrl * JVM_FIELD_CONST vc;
    /* @60 */	struct Java_com_sun_mmedia_QSoundMIDICtrl * JVM_FIELD_CONST mc;
};

struct Java_com_sun_mmedia_QSoundMIDIOut {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIOut */
};

struct Java_com_sun_mmedia_QSoundMIDIPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @44 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @48 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @52 */	jlong stopTime;
    /* @60 */	jint eventQueueSize;
    /* @64 */	jlong origin;
    /* @72 */	jlong offset;
    /* @80 */	jlong time;
    /* @88 */	jlong sysOffset;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @100 */	jint NOT_SEEKABLE;
    /* @104 */	jint SEEKABLE_TO_START;
    /* @108 */	jint RANDOM_ACCESSIBLE;
    /* @112 */	jboolean EOM;
    /* @113 */	jboolean loopAfterEOM;
    /* @114 */	jboolean listenersModified;
    /* @115 */	jboolean isTrusted;
    /* @116 */	jboolean closedDelivered;
    /* @117 */	jboolean hasDataSource;
    /* @118 */	jboolean useSystemTime;
    /* @119 */	jbyte ___pad303;
    /* com/sun/mmedia/QSoundMIDIPlayer */
    /* @120 */	struct Java_com_sun_mmedia_QSoundMIDIPlayBase * JVM_FIELD_CONST qsmc;
    /* @124 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @128 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @132 */	jbyte_array * JVM_FIELD_CONST bufferData;
    /* @136 */	struct Java_java_util_Vector * JVM_FIELD_CONST channels;
    /* @140 */	jint bufferSize;
    /* @144 */	jboolean stopped;
    /* @145 */	jbyte ___pad304;
    /* @146 */	jbyte ___pad305;
    /* @147 */	jbyte ___pad306;
};

struct Java_com_sun_mmedia_QSoundMIDIToneSequencePlayControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIPlayBase */
    /*  @4 */	jint qsMIDI;
    /*  @8 */	jint globMan;
    /* @12 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
    /* @16 */	jint loopCount;
    /* @20 */	jint currentLoopCount;
    /* @24 */	jint lastLoopCount;
    /* @28 */	jboolean opened;
    /* @29 */	jbyte ___pad307;
    /* @30 */	jbyte ___pad308;
    /* @31 */	jbyte ___pad309;
    /* com/sun/mmedia/QSoundMIDIToneSequencePlayControl */
    /* @32 */	struct Java_com_sun_mmedia_QSoundVolumeCtrl * JVM_FIELD_CONST vc;
    /* @36 */	struct Java_com_sun_mmedia_QSoundPitchCtrl * JVM_FIELD_CONST pc;
    /* @40 */	struct Java_com_sun_mmedia_QSoundRateCtrl * JVM_FIELD_CONST rc;
    /* @44 */	struct Java_com_sun_mmedia_QSoundTempoCtrl * JVM_FIELD_CONST tc;
};

struct Java_com_sun_mmedia_QSoundMIDITuple {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDITuple */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST p;
    /*  @8 */	jint channel;
};

struct Java_javax_microedition_media_control_PitchControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/PitchControl */
};

struct Java_javax_microedition_media_control_TempoControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/TempoControl */
};

struct Java_com_sun_mmedia_QSoundToneSequencePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @44 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @48 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @52 */	jlong stopTime;
    /* @60 */	jint eventQueueSize;
    /* @64 */	jlong origin;
    /* @72 */	jlong offset;
    /* @80 */	jlong time;
    /* @88 */	jlong sysOffset;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @100 */	jint NOT_SEEKABLE;
    /* @104 */	jint SEEKABLE_TO_START;
    /* @108 */	jint RANDOM_ACCESSIBLE;
    /* @112 */	jboolean EOM;
    /* @113 */	jboolean loopAfterEOM;
    /* @114 */	jboolean listenersModified;
    /* @115 */	jboolean isTrusted;
    /* @116 */	jboolean closedDelivered;
    /* @117 */	jboolean hasDataSource;
    /* @118 */	jboolean useSystemTime;
    /* @119 */	jbyte ___pad310;
    /* com/sun/mmedia/QSoundToneSequencePlayer */
    /* @120 */	struct Java_com_sun_mmedia_QSoundMIDIPlayBase * JVM_FIELD_CONST qsmc;
    /* @124 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @128 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @132 */	struct Java_com_sun_mmedia_QSoundMIDIConnectable * JVM_FIELD_CONST qmc;
    /* @136 */	struct Java_java_util_Vector * JVM_FIELD_CONST channels;
    /* @140 */	struct Java_com_sun_mmedia_QSoundToneCtrl * JVM_FIELD_CONST tctrl;
    /* @144 */	jint bufferSize;
    /* @148 */	jboolean stopped;
    /* @149 */	jbyte ___pad311;
    /* @150 */	jbyte ___pad312;
    /* @151 */	jbyte ___pad313;
};

struct Java_javax_microedition_media_control_ToneControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/ToneControl */
};

struct Java_com_sun_mmedia_QSoundToneCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundToneCtrl */
    /*  @4 */	struct Java_com_sun_mmedia_QSoundToneSequencePlayer * JVM_FIELD_CONST qstsp;
};

struct Java_com_sun_mmedia_protocol_FileConnectionSubstitute {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/protocol/FileConnectionSubstitute */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream * JVM_FIELD_CONST ras;
    /*  @8 */	struct Java_com_sun_midp_io_j2me_storage_File * JVM_FIELD_CONST file;
};

struct Java_java_lang_Integer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Integer */
    /*  @4 */	jint value;
};

struct Java_javax_microedition_media_control_RecordControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/RecordControl */
};

struct Java_com_sun_mmedia_WavPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/BasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	struct Java_javax_microedition_media_protocol_DataSource * JVM_FIELD_CONST source;
    /* @44 */	struct Java_javax_microedition_media_protocol_SourceStream * JVM_FIELD_CONST stream;
    /* @48 */	struct Java_javax_microedition_media_TimeBase * JVM_FIELD_CONST timeBase;
    /* @52 */	jlong stopTime;
    /* @60 */	jint eventQueueSize;
    /* @64 */	jlong origin;
    /* @72 */	jlong offset;
    /* @80 */	jlong time;
    /* @88 */	jlong sysOffset;
    /* @96 */	struct Java_java_lang_Object * JVM_FIELD_CONST timeLock;
    /* @100 */	jint NOT_SEEKABLE;
    /* @104 */	jint SEEKABLE_TO_START;
    /* @108 */	jint RANDOM_ACCESSIBLE;
    /* @112 */	jboolean EOM;
    /* @113 */	jboolean loopAfterEOM;
    /* @114 */	jboolean listenersModified;
    /* @115 */	jboolean isTrusted;
    /* @116 */	jboolean closedDelivered;
    /* @117 */	jboolean hasDataSource;
    /* @118 */	jboolean useSystemTime;
    /* @119 */	jbyte ___pad314;
    /* com/sun/mmedia/WavPlayer */
    /* @120 */	jlong duration;
    /* @128 */	jint sampleRate;
    /* @132 */	jint channels;
    /* @136 */	jint sampleSizeInBits;
    /* @140 */	jint encoding;
    /* @144 */	jint samplesPerBlock;
    /* @148 */	jint bytesPerSecond;
    /* @152 */	jint blockAlign;
    /* @156 */	struct Java_com_sun_mmedia_PCMAudioOut * JVM_FIELD_CONST renderer;
    /* @160 */	struct Java_com_sun_mmedia_PCMAudioOut * JVM_FIELD_CONST altRenderer;
    /* @164 */	struct Java_java_lang_Object * JVM_FIELD_CONST waveLock;
    /* @168 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @172 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @176 */	jlong startpt;
    /* @184 */	jlong endpt;
    /* @192 */	jlong mediaTimeCache;
    /* @200 */	jint bufLen;
    /* @204 */	struct Java_com_sun_mmedia_Buffer * JVM_FIELD_CONST bufferObject;
    /* @208 */	jint sleepTime;
    /* @212 */	struct Java_java_lang_Object * JVM_FIELD_CONST pauseLock;
    /* @216 */	struct Java_java_lang_Object * JVM_FIELD_CONST readLock;
    /* @220 */	struct Java_com_sun_mmedia_VolCtrl * JVM_FIELD_CONST vc;
    /* @224 */	jlong contentLength;
    /* @232 */	struct Java_com_sun_mmedia_MetaCtrl * JVM_FIELD_CONST meta;
    /* @236 */	struct Java_com_sun_mmedia_RecordCtrl * JVM_FIELD_CONST recordControl;
    /* @240 */	struct Java_com_sun_mmedia_WavPlayer_0004WavRateCtrl * JVM_FIELD_CONST rateControl;
    /* @244 */	struct Java_java_lang_String * JVM_FIELD_CONST runErr;
    /* @248 */	jbyte_array * JVM_FIELD_CONST intArray;
    /* @252 */	jboolean isBigEndian;
    /* @253 */	jboolean isSigned;
    /* @254 */	jboolean started;
    /* @255 */	jboolean interrupted;
    /* @256 */	jboolean canPause;
    /* @257 */	jboolean fmtSeen;
    /* @258 */	jboolean dataSeen;
    /* @259 */	jboolean isCapturePlayer;
};

struct Java_com_sun_mmedia_WavPlayer_0004WavRateCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/WavPlayer$WavRateCtrl */
    /*  @4 */	jint playRateMP;
    /*  @8 */	jint minRate;
    /* @12 */	jint maxRate;
    /* @16 */	struct Java_com_sun_mmedia_WavPlayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_mmedia_WavRecordCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/RecordCtrl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST fileName;
    /* @12 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpCon;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST localFileName;
    /* @20 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST httpOutputStream;
    /* @24 */	jint localFilePointer;
    /* @28 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST stream;
    /* @32 */	jbyte_array * JVM_FIELD_CONST localBuffer;
    /* @36 */	jint CHUNK_SIZE;
    /* @40 */	struct Java_com_sun_mmedia_BasicPlayer * JVM_FIELD_CONST player;
    /* @44 */	jint sizeLimit;
    /* @48 */	jint headerSize;
    /* @52 */	jint dataSize;
    /* @56 */	struct Java_com_sun_mmedia_protocol_FileConnectionSubstitute * JVM_FIELD_CONST fileConnSubst;
    /* @60 */	struct Java_com_sun_mmedia_protocol_FileConnectionSubstitute * JVM_FIELD_CONST fileTemp;
    /* @64 */	jboolean RECORD;
    /* @65 */	jboolean RECORD_TO_FILE;
    /* @66 */	jboolean RECORD_TO_HTTP;
    /* @67 */	jboolean recordRequested;
    /* @68 */	jboolean recording;
    /* @69 */	jbyte ___pad315;
    /* @70 */	jbyte ___pad316;
    /* @71 */	jbyte ___pad317;
    /* com/sun/mmedia/WavRecordCtrl */
    /* @72 */	jbyte_array * JVM_FIELD_CONST header;
};

struct Java_com_sun_mmedia_protocol_BasicDS {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
    /* com/sun/mmedia/protocol/BasicDS */
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST contentType;
    /* @16 */	jboolean connected;
    /* @17 */	jbyte ___pad318;
    /* @18 */	jbyte ___pad319;
    /* @19 */	jbyte ___pad320;
};

struct Java_javax_microedition_media_protocol_ContentDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/ContentDescriptor */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST encoding;
};

struct Java_com_sun_mmedia_protocol_CommonDS {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
    /* com/sun/mmedia/protocol/BasicDS */
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST contentType;
    /* @16 */	jboolean connected;
    /* @17 */	jbyte ___pad321;
    /* @18 */	jbyte ___pad322;
    /* @19 */	jbyte ___pad323;
    /* com/sun/mmedia/protocol/CommonDS */
    /* @20 */	jlong contentLength;
    /* @28 */	struct Java_java_io_InputStream * JVM_FIELD_CONST inputStream;
    /* @32 */	struct Java_com_sun_mmedia_protocol_FileConnectionSubstitute * JVM_FIELD_CONST fileConn;
    /* @36 */	jlong location;
};

struct Java_com_sun_mmedia_protocol_LocatorParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/protocol/LocatorParser */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /*  @8 */	jint index;
    /* @12 */	jint length;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
};

struct Java_com_sun_mmedia_protocol_WavCapture {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/protocol/DataSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST sourceLocator;
    /* com/sun/mmedia/protocol/BasicDS */
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST locator;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST contentType;
    /* @16 */	jboolean connected;
    /* @17 */	jbyte ___pad324;
    /* @18 */	jbyte ___pad325;
    /* @19 */	jbyte ___pad326;
    /* com/sun/mmedia/protocol/WavCapture */
    /* @20 */	jint sampleRate;
    /* @24 */	jint sampleSize;
    /* @28 */	jint channels;
    /* @32 */	jint endian;
    /* @36 */	jint signedvalue;
    /* @40 */	jint peer;
    /* @44 */	jlong bytesRead;
    /* @52 */	jbyte_array * JVM_FIELD_CONST hdr;
    /* @56 */	jint hdrSize;
    /* @60 */	jint hdrOfs;
};

struct Java_java_io_OutputStreamWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* java/io/OutputStreamWriter */
    /* @16 */	struct Java_java_io_Writer * JVM_FIELD_CONST out;
};

struct Java_java_lang_ArrayStoreException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ArrayStoreException */
};

struct Java_java_lang_Boolean {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Boolean */
    /*  @4 */	jboolean value;
    /* @5 */	jbyte ___pad327;
    /* @6 */	jbyte ___pad328;
    /* @7 */	jbyte ___pad329;
};

struct Java_java_lang_Byte {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Byte */
    /*  @4 */	jbyte value;
    /* @5 */	jbyte ___pad330;
    /* @6 */	jbyte ___pad331;
    /* @7 */	jbyte ___pad332;
};

struct Java_java_lang_Character {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Character */
    /*  @4 */	jchar value;
    /* @5 */	jbyte ___pad333;
    /* @6 */	jbyte ___pad334;
};

struct Java_java_lang_FloatingDecimal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/FloatingDecimal */
    /*  @4 */	jint decExponent;
    /*  @8 */	jchar_array * JVM_FIELD_CONST digits;
    /* @12 */	jint nDigits;
    /* @16 */	jint bigIntExp;
    /* @20 */	jint bigIntNBits;
    /* @24 */	jint roundDir;
    /* @28 */	jboolean isExceptional;
    /* @29 */	jboolean isNegative;
    /* @30 */	jboolean mustSetRoundDir;
    /* @31 */	jbyte ___pad335;
};

struct Java_java_lang_Double {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Double */
    /*  @4 */	jdouble value;
};

struct Java_java_lang_FDBigInt {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/FDBigInt */
    /*  @4 */	jint nWords;
    /*  @8 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_java_lang_Float {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Float */
    /*  @4 */	jfloat value;
};

struct Java_java_lang_IllegalThreadStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
    /* java/lang/IllegalThreadStateException */
};

struct Java_java_lang_Long {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Long */
    /*  @4 */	jlong value;
};

struct Java_java_lang_NegativeArraySizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/NegativeArraySizeException */
};

struct Java_java_lang_Short {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Short */
    /*  @4 */	jshort value;
    /* @5 */	jbyte ___pad336;
    /* @6 */	jbyte ___pad337;
};

struct Java_java_util_EmptyStackException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/util/EmptyStackException */
};

struct Java_java_util_HashtableEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/HashtableEntry */
    /*  @4 */	jint hash;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST value;
    /* @16 */	struct Java_java_util_HashtableEntry * JVM_FIELD_CONST next;
};

struct Java_java_util_Hashtable_0004HashtableEnumerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Hashtable$HashtableEnumerator */
    /*  @4 */	jint index;
    /*  @8 */	jobject_array * JVM_FIELD_CONST table;
    /* @12 */	struct Java_java_util_HashtableEntry * JVM_FIELD_CONST entry;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST this_0440;
    /* @20 */	jboolean keys;
    /* @21 */	jbyte ___pad338;
    /* @22 */	jbyte ___pad339;
    /* @23 */	jbyte ___pad340;
};

struct Java_java_util_NoSuchElementException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/util/NoSuchElementException */
};

struct Java_java_util_Random {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Random */
    /*  @4 */	jlong seed;
};

struct Java_java_util_Stack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
    /* java/util/Stack */
};

struct Java_java_util_TaskQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TaskQueue */
    /*  @4 */	jobject_array * JVM_FIELD_CONST queue;
    /*  @8 */	jint size;
};

struct Java_java_util_TimerThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* java/util/TimerThread */
    /* @28 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /* @32 */	jboolean newTasksMayBeScheduled;
    /* @33 */	jbyte ___pad341;
    /* @34 */	jbyte ___pad342;
    /* @35 */	jbyte ___pad343;
};

struct Java_java_util_VectorEnumerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/VectorEnumerator */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST vector;
    /*  @8 */	jint count;
};

struct Java_javax_microedition_io_CommConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/CommConnection */
};

struct Java_javax_microedition_io_Connector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Connector */
};

struct Java_javax_microedition_io_PushRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/PushRegistry */
};

struct Java_javax_microedition_lcdui_AbstractImageData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractImageData */
};

struct Java_javax_microedition_lcdui_ImageData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageData */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	jbyte_array * JVM_FIELD_CONST pixelData;
    /* @16 */	jbyte_array * JVM_FIELD_CONST alphaData;
    /* @20 */	jint nativePixelData;
    /* @24 */	jint nativeAlphaData;
    /* @28 */	jboolean isMutable;
    /* @29 */	jbyte ___pad344;
    /* @30 */	jbyte ___pad345;
    /* @31 */	jbyte ___pad346;
};

struct Java_javax_microedition_lcdui_AbstractImageDataFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractImageDataFactory */
};

struct Java_javax_microedition_lcdui_Alert_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Alert$1 */
    /*  @4 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_AlertLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @32 */	jint_array * JVM_FIELD_CONST viewable;
    /* @36 */	jint vScrollPosition;
    /* @40 */	jint vScrollProportion;
    /* @44 */	jboolean resetToTop;
    /* @45 */	jbyte ___pad347;
    /* @46 */	jbyte ___pad348;
    /* @47 */	jbyte ___pad349;
    /* javax/microedition/lcdui/AlertLFImpl */
    /* @48 */	jint clipx;
    /* @52 */	jint clipy;
    /* @56 */	jint clipw;
    /* @60 */	jint cliph;
    /* @64 */	jint maxScroll;
    /* @68 */	jint totalHeight;
    /* @72 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
    /* @76 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @80 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST timerTask;
    /* @84 */	jint titlex;
    /* @88 */	jint titley;
    /* @92 */	jint titlew;
    /* @96 */	jint titleh;
    /* @100 */	jint icony;
    /* @104 */	jint iconw;
    /* @108 */	jint iconh;
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @116 */	jboolean isLayoutValid;
    /* @117 */	jbyte ___pad350;
    /* @118 */	jbyte ___pad351;
    /* @119 */	jbyte ___pad352;
};

struct Java_javax_microedition_lcdui_AlertLFImpl_0004TimeoutTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/AlertLFImpl$TimeoutTask */
    /* @28 */	struct Java_javax_microedition_lcdui_AlertLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_TickerLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TickerLF */
};

struct Java_javax_microedition_lcdui_Display_0004DisplayAccessImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$DisplayAccessImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_DisplayableLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
};

struct Java_javax_microedition_lcdui_ScreenLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @32 */	jint_array * JVM_FIELD_CONST viewable;
    /* @36 */	jint vScrollPosition;
    /* @40 */	jint vScrollProportion;
    /* @44 */	jboolean resetToTop;
    /* @45 */	jbyte ___pad353;
    /* @46 */	jbyte ___pad354;
    /* @47 */	jbyte ___pad355;
};

struct Java_javax_microedition_lcdui_MMHelperImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/MMHelperImpl */
};

struct Java_javax_microedition_lcdui_CanvasLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/CanvasLFImpl */
    /* @32 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST canvas;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST embeddedVideos;
};

struct Java_javax_microedition_lcdui_ChamImageTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChamImageTunnel */
};

struct Java_javax_microedition_lcdui_ItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad356;
    /* @43 */	jbyte ___pad357;
};

struct Java_javax_microedition_lcdui_ChoiceGroupLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad358;
    /* @43 */	jbyte ___pad359;
    /* javax/microedition/lcdui/ChoiceGroupLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @48 */	jint selectedIndex;
    /* @52 */	jint hilightedIndex;
    /* @56 */	jint contentX;
    /* @60 */	jint_array * JVM_FIELD_CONST elHeights;
    /* @64 */	jboolean traversedIn;
    /* @65 */	jbyte ___pad360;
    /* @66 */	jbyte ___pad361;
    /* @67 */	jbyte ___pad362;
};

struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad363;
    /* @43 */	jbyte ___pad364;
    /* javax/microedition/lcdui/ChoiceGroupLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @48 */	jint selectedIndex;
    /* @52 */	jint hilightedIndex;
    /* @56 */	jint contentX;
    /* @60 */	jint_array * JVM_FIELD_CONST elHeights;
    /* @64 */	jboolean traversedIn;
    /* @65 */	jbyte ___pad365;
    /* @66 */	jbyte ___pad366;
    /* @67 */	jbyte ___pad367;
    /* javax/microedition/lcdui/ChoiceGroupPopupLFImpl */
    /* @68 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl_0004CGPopupLayer * JVM_FIELD_CONST popupLayer;
    /* @72 */	jint_array * JVM_FIELD_CONST viewable;
    /* @76 */	jboolean popUpOpen;
    /* @77 */	jbyte ___pad368;
    /* @78 */	jbyte ___pad369;
    /* @79 */	jbyte ___pad370;
};

struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl_0004CGPopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad371;
    /* @43 */	jbyte ___pad372;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/ChoiceGroupPopupLFImpl$CGPopupLayer */
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl * JVM_FIELD_CONST lf;
    /* @56 */	jint_array * JVM_FIELD_CONST viewport;
    /* @60 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl * JVM_FIELD_CONST this_0440;
    /* @64 */	jboolean popupDrawnDown;
    /* @65 */	jboolean sbVisible;
    /* @66 */	jbyte ___pad373;
    /* @67 */	jbyte ___pad374;
};

struct Java_javax_microedition_lcdui_CustomItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad375;
    /* @43 */	jbyte ___pad376;
    /* javax/microedition/lcdui/CustomItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItem * JVM_FIELD_CONST customItem;
    /* @48 */	jint preferredHeight;
    /* @52 */	jint preferredWidth;
    /* @56 */	jint minimumHeight;
    /* @60 */	jint minimumWidth;
    /* @64 */	jboolean validRequestedSizes;
    /* @65 */	jbyte ___pad377;
    /* @66 */	jbyte ___pad378;
    /* @67 */	jbyte ___pad379;
};

struct Java_javax_microedition_lcdui_DateEditor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad380;
    /* @43 */	jbyte ___pad381;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST __dup1__commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DateEditor */
    /* @52 */	struct Java_javax_microedition_lcdui_DateFieldLFImpl * JVM_FIELD_CONST lf;
    /* @56 */	struct Java_java_util_Calendar * JVM_FIELD_CONST editDate;
    /* @60 */	jint mode;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancel;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST set;
    /* @72 */	jobject_array * JVM_FIELD_CONST commands;
    /* @76 */	jint nextX;
    /* @80 */	jint nextY;
    /* @84 */	jint lastDay;
    /* @88 */	jint dayOffset;
    /* @92 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST monthPopup;
    /* @96 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST yearPopup;
    /* @100 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST hoursPopup;
    /* @104 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST minutesPopup;
    /* @108 */	jint focusOn;
    /* @112 */	jint hilightedDate;
    /* @116 */	jint selectedDate;
    /* @120 */	jint popupWidth;
    /* @124 */	jint popupHeight;
    /* @128 */	jint elementWidth;
    /* @132 */	jint elementHeight;
    /* @136 */	jint timeComponentsOffset;
    /* @140 */	jint calendarTopLimit;
    /* @144 */	jint calendarBottomLimit;
    /* @148 */	jint calendarRightLimit;
    /* @152 */	jint dateHilightX;
    /* @156 */	jint dateHilightY;
    /* @160 */	jboolean initialized;
    /* @161 */	jboolean popUpOpen;
    /* @162 */	jboolean amSelected;
    /* @163 */	jboolean amHilighted;
};

struct Java_javax_microedition_lcdui_DEPopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad382;
    /* @43 */	jbyte ___pad383;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DEPopupLayer */
    /* @52 */	struct Java_javax_microedition_lcdui_DateEditor * JVM_FIELD_CONST editor;
    /* @56 */	jint_array * JVM_FIELD_CONST viewport;
    /* @60 */	jint numElements;
    /* @64 */	jobject_array * JVM_FIELD_CONST elements;
    /* @68 */	jint elementWidth;
    /* @72 */	jint elementHeight;
    /* @76 */	jint elementsToFit;
    /* @80 */	jint startIndex;
    /* @84 */	jint endIndex;
    /* @88 */	jint hilightedIndex;
    /* @92 */	jboolean open;
    /* @93 */	jboolean sbVisible;
    /* @94 */	jboolean circularTraversal;
    /* @95 */	jbyte ___pad384;
};

struct Java_javax_microedition_lcdui_DateFieldLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad385;
    /* @43 */	jbyte ___pad386;
    /* javax/microedition/lcdui/DateFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_DateField * JVM_FIELD_CONST df;
    /* @48 */	struct Java_java_util_Calendar * JVM_FIELD_CONST currentDate;
    /* @52 */	jint mode;
    /* @56 */	struct Java_javax_microedition_lcdui_DateEditor * JVM_FIELD_CONST editor;
    /* @60 */	jboolean traversedIn;
    /* @61 */	jboolean popUpOpen;
    /* @62 */	jbyte ___pad387;
    /* @63 */	jbyte ___pad388;
};

struct Java_javax_microedition_lcdui_DateField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/DateField */
    /* @44 */	struct Java_javax_microedition_lcdui_DateFieldLF * JVM_FIELD_CONST dateFieldLF;
    /* @48 */	jint mode;
    /* @52 */	struct Java_java_util_Calendar * JVM_FIELD_CONST currentDate;
    /* @56 */	jboolean initialized;
    /* @57 */	jbyte ___pad389;
    /* @58 */	jbyte ___pad390;
    /* @59 */	jbyte ___pad391;
};

struct Java_javax_microedition_lcdui_DateFieldLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DateFieldLF */
};

struct Java_javax_microedition_lcdui_Display_0004HeadlessAlert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad392;
    /* @30 */	jbyte ___pad393;
    /* @31 */	jbyte ___pad394;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
    /* javax/microedition/lcdui/Display$HeadlessAlert */
    /* @72 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$1 */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST val_044this_0440;
    /*  @8 */	struct Java_javax_microedition_lcdui_Display_0004HeadlessAlert * JVM_FIELD_CONST this_0441;
};

struct Java_javax_microedition_lcdui_Display_0004ChameleonTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$ChameleonTunnel */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_0004DisplayEventConsumerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$DisplayEventConsumerImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_DisplayEventHandlerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayEventHandlerImpl */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @12 */	struct Java_com_sun_midp_lcdui_DisplayAccess * JVM_FIELD_CONST preemptingDisplay;
    /* @16 */	jboolean destroyPreemptingDisplay;
    /* @17 */	jbyte ___pad395;
    /* @18 */	jbyte ___pad396;
    /* @19 */	jbyte ___pad397;
};

struct Java_javax_microedition_lcdui_DisplayEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_javax_microedition_lcdui_LayoutManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LayoutManager */
    /*  @4 */	jint_array * JVM_FIELD_CONST sizingBox;
    /*  @8 */	jint viewportWidth;
    /* @12 */	jint viewportHeight;
};

struct Java_javax_microedition_lcdui_FormLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @32 */	jint_array * JVM_FIELD_CONST viewable;
    /* @36 */	jint vScrollPosition;
    /* @40 */	jint vScrollProportion;
    /* @44 */	jboolean resetToTop;
    /* @45 */	jbyte ___pad398;
    /* @46 */	jbyte ___pad399;
    /* @47 */	jbyte ___pad400;
    /* javax/microedition/lcdui/FormLFImpl */
    /* @48 */	jint traverseIndex;
    /* @52 */	struct Java_javax_microedition_lcdui_ItemLFImpl * JVM_FIELD_CONST lastTraverseItem;
    /* @56 */	jint_array * JVM_FIELD_CONST visRect;
    /* @60 */	jobject_array * JVM_FIELD_CONST itemLFs;
    /* @64 */	jint numOfLFs;
    /* @68 */	jint lastScrollPosition;
    /* @72 */	jint lastScrollSize;
    /* @76 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST pendingCurrentItem;
    /* @80 */	jboolean itemTraverse;
    /* @81 */	jboolean itemsModified;
    /* @82 */	jboolean pointerPressed;
    /* @83 */	jboolean scrollInitialized;
    /* @84 */	jboolean firstShown;
    /* @85 */	jbyte ___pad401;
    /* @86 */	jbyte ___pad402;
    /* @87 */	jbyte ___pad403;
};

struct Java_javax_microedition_lcdui_GaugeLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad404;
    /* @43 */	jbyte ___pad405;
    /* javax/microedition/lcdui/GaugeLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST gauge;
    /* @48 */	struct Java_javax_microedition_lcdui_GaugeLFImpl_0004GaugeUpdateTask * JVM_FIELD_CONST updateHelper;
    /* @52 */	jint percentWidth;
    /* @56 */	jint percentHeight;
    /* @60 */	jint focusBtn;
    /* @64 */	jint_array * JVM_FIELD_CONST percentLoc;
    /* @68 */	jint nextFrame;
    /* @72 */	jboolean initialTraverse;
    /* @73 */	jboolean intTraverse;
    /* @74 */	jbyte ___pad406;
    /* @75 */	jbyte ___pad407;
};

struct Java_javax_microedition_lcdui_GaugeLFImpl_0004GaugeUpdateTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/GaugeLFImpl$GaugeUpdateTask */
    /* @28 */	struct Java_javax_microedition_lcdui_GaugeLFImpl * JVM_FIELD_CONST myGaugeLF;
    /* @32 */	struct Java_javax_microedition_lcdui_GaugeLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_ImageDataFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageDataFactory */
};

struct Java_javax_microedition_lcdui_ImageItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad408;
    /* @43 */	jbyte ___pad409;
    /* javax/microedition/lcdui/ImageItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ImageItem * JVM_FIELD_CONST imgItem;
    /* @48 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_KeyConverter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/KeyConverter */
};

struct Java_javax_microedition_lcdui_Spacer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/Spacer */
    /* @44 */	struct Java_javax_microedition_lcdui_SpacerLF * JVM_FIELD_CONST spacerLF;
    /* @48 */	jint width;
    /* @52 */	jint height;
};

struct Java_javax_microedition_lcdui_SpacerLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SpacerLF */
};

struct Java_javax_microedition_lcdui_LFFactoryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFFactory */
    /* javax/microedition/lcdui/LFFactoryImpl */
};

struct Java_javax_microedition_lcdui_StringItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad410;
    /* @43 */	jbyte ___pad411;
    /* javax/microedition/lcdui/StringItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_StringItem * JVM_FIELD_CONST strItem;
    /* @48 */	jint appearanceMode;
    /* @52 */	jboolean skipTraverse;
    /* @53 */	jbyte ___pad412;
    /* @54 */	jbyte ___pad413;
    /* @55 */	jbyte ___pad414;
};

struct Java_javax_microedition_lcdui_SpacerLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad415;
    /* @43 */	jbyte ___pad416;
    /* javax/microedition/lcdui/SpacerLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_Spacer * JVM_FIELD_CONST spacer;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad417;
    /* @43 */	jbyte ___pad418;
    /* javax/microedition/lcdui/TextFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf;
    /* @48 */	struct Java_com_sun_midp_lcdui_TextCursor * JVM_FIELD_CONST cursor;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
    /* @56 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST interruptedIM;
    /* @60 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST inputMenu;
    /* @64 */	jobject_array * JVM_FIELD_CONST inputModes;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_InputModeLayer * JVM_FIELD_CONST inputModeIndicator;
    /* @72 */	jobject_array * JVM_FIELD_CONST pt_matches;
    /* @76 */	jint_array * JVM_FIELD_CONST inputModeAnchor;
    /* @80 */	jint_array * JVM_FIELD_CONST cachedSize;
    /* @84 */	jint xScrollOffset;
    /* @88 */	jint textWidth;
    /* @92 */	jint scrollWidth;
    /* @96 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @100 */	struct Java_java_util_Vector * JVM_FIELD_CONST timers;
    /* @104 */	struct Java_java_util_Timer * JVM_FIELD_CONST timerService;
    /* @108 */	jboolean editable;
    /* @109 */	jboolean firstTimeInTraverse;
    /* @110 */	jboolean pt_popupOpen;
    /* @111 */	jboolean showIMPopup;
    /* @112 */	jboolean usePreferredX;
    /* @113 */	jbyte ___pad419;
    /* @114 */	jbyte ___pad420;
    /* @115 */	jbyte ___pad421;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TextScrollPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/TextFieldLFImpl$TextScrollPainter */
    /* @28 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldLFImpl$1 */
};

struct Java_javax_microedition_lcdui_TextBoxLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad422;
    /* @43 */	jbyte ___pad423;
    /* javax/microedition/lcdui/TextFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf;
    /* @48 */	struct Java_com_sun_midp_lcdui_TextCursor * JVM_FIELD_CONST cursor;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
    /* @56 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST interruptedIM;
    /* @60 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST inputMenu;
    /* @64 */	jobject_array * JVM_FIELD_CONST inputModes;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_InputModeLayer * JVM_FIELD_CONST inputModeIndicator;
    /* @72 */	jobject_array * JVM_FIELD_CONST pt_matches;
    /* @76 */	jint_array * JVM_FIELD_CONST inputModeAnchor;
    /* @80 */	jint_array * JVM_FIELD_CONST cachedSize;
    /* @84 */	jint xScrollOffset;
    /* @88 */	jint textWidth;
    /* @92 */	jint scrollWidth;
    /* @96 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @100 */	struct Java_java_util_Vector * JVM_FIELD_CONST timers;
    /* @104 */	struct Java_java_util_Timer * JVM_FIELD_CONST timerService;
    /* @108 */	jboolean editable;
    /* @109 */	jboolean firstTimeInTraverse;
    /* @110 */	jboolean pt_popupOpen;
    /* @111 */	jboolean showIMPopup;
    /* @112 */	jboolean usePreferredX;
    /* @113 */	jbyte ___pad424;
    /* @114 */	jbyte ___pad425;
    /* @115 */	jbyte ___pad426;
    /* javax/microedition/lcdui/TextBoxLFImpl */
    /* @116 */	struct Java_com_sun_midp_lcdui_TextInfo * JVM_FIELD_CONST myInfo;
    /* @120 */	jboolean scrollInitialized;
    /* @121 */	jbyte ___pad427;
    /* @122 */	jbyte ___pad428;
    /* @123 */	jbyte ___pad429;
};

struct Java_javax_microedition_lcdui_TickerLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TickerLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST owner;
    /*  @8 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
};

struct Java_javax_microedition_lcdui_MiniDateEditor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad430;
    /* @43 */	jbyte ___pad431;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST __dup1__commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DateEditor */
    /* @52 */	struct Java_javax_microedition_lcdui_DateFieldLFImpl * JVM_FIELD_CONST lf;
    /* @56 */	struct Java_java_util_Calendar * JVM_FIELD_CONST editDate;
    /* @60 */	jint mode;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancel;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST set;
    /* @72 */	jobject_array * JVM_FIELD_CONST commands;
    /* @76 */	jint nextX;
    /* @80 */	jint nextY;
    /* @84 */	jint lastDay;
    /* @88 */	jint dayOffset;
    /* @92 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST monthPopup;
    /* @96 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST yearPopup;
    /* @100 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST hoursPopup;
    /* @104 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST minutesPopup;
    /* @108 */	jint focusOn;
    /* @112 */	jint hilightedDate;
    /* @116 */	jint selectedDate;
    /* @120 */	jint popupWidth;
    /* @124 */	jint popupHeight;
    /* @128 */	jint elementWidth;
    /* @132 */	jint elementHeight;
    /* @136 */	jint timeComponentsOffset;
    /* @140 */	jint calendarTopLimit;
    /* @144 */	jint calendarBottomLimit;
    /* @148 */	jint calendarRightLimit;
    /* @152 */	jint dateHilightX;
    /* @156 */	jint dateHilightY;
    /* @160 */	jboolean initialized;
    /* @161 */	jboolean popUpOpen;
    /* @162 */	jboolean amSelected;
    /* @163 */	jboolean amHilighted;
    /* javax/microedition/lcdui/MiniDateEditor */
    /* @164 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST dayPopup;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TimerKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/TextFieldLFImpl$TimerKey */
    /* @28 */	jint key;
    /* @32 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_game_GameCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad432;
    /* @30 */	jbyte ___pad433;
    /* @31 */	jbyte ___pad434;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad435;
    /* @38 */	jbyte ___pad436;
    /* @39 */	jbyte ___pad437;
    /* javax/microedition/lcdui/game/GameCanvas */
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST offscreen_buffer;
};

struct Java_javax_microedition_lcdui_game_Layer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad438;
    /* @22 */	jbyte ___pad439;
    /* @23 */	jbyte ___pad440;
};

struct Java_javax_microedition_lcdui_game_LayerManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/LayerManager */
    /*  @4 */	jint nlayers;
    /*  @8 */	jobject_array * JVM_FIELD_CONST component;
    /* @12 */	jint viewX;
    /* @16 */	jint viewY;
    /* @20 */	jint viewWidth;
    /* @24 */	jint viewHeight;
};

struct Java_javax_microedition_lcdui_game_Sprite {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad441;
    /* @22 */	jbyte ___pad442;
    /* @23 */	jbyte ___pad443;
    /* javax/microedition/lcdui/game/Sprite */
    /* @24 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sourceImage;
    /* @28 */	jint numberFrames;
    /* @32 */	jint_array * JVM_FIELD_CONST frameCoordsX;
    /* @36 */	jint_array * JVM_FIELD_CONST frameCoordsY;
    /* @40 */	jint srcFrameWidth;
    /* @44 */	jint srcFrameHeight;
    /* @48 */	jint_array * JVM_FIELD_CONST frameSequence;
    /* @52 */	jint sequenceIndex;
    /* @56 */	jint dRefX;
    /* @60 */	jint dRefY;
    /* @64 */	jint collisionRectX;
    /* @68 */	jint collisionRectY;
    /* @72 */	jint collisionRectWidth;
    /* @76 */	jint collisionRectHeight;
    /* @80 */	jint t_currentTransformation;
    /* @84 */	jint t_collisionRectX;
    /* @88 */	jint t_collisionRectY;
    /* @92 */	jint t_collisionRectWidth;
    /* @96 */	jint t_collisionRectHeight;
    /* @100 */	jboolean customSequenceDefined;
    /* @101 */	jbyte ___pad444;
    /* @102 */	jbyte ___pad445;
    /* @103 */	jbyte ___pad446;
};

struct Java_javax_microedition_lcdui_game_TiledLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad447;
    /* @22 */	jbyte ___pad448;
    /* @23 */	jbyte ___pad449;
    /* javax/microedition/lcdui/game/TiledLayer */
    /* @24 */	jint cellHeight;
    /* @28 */	jint cellWidth;
    /* @32 */	jint rows;
    /* @36 */	jint columns;
    /* @40 */	jobject_array * JVM_FIELD_CONST cellMatrix;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sourceImage;
    /* @48 */	jint numberOfTiles;
    /* @52 */	jint_array * JVM_FIELD_CONST tileSetX;
    /* @56 */	jint_array * JVM_FIELD_CONST tileSetY;
    /* @60 */	jint_array * JVM_FIELD_CONST anim_to_static;
    /* @64 */	jint numOfAnimTiles;
};

struct Java_javax_microedition_media_Manager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Manager */
};

struct Java_javax_microedition_media_SystemTimeBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/SystemTimeBase */
    /*  @4 */	jlong offset;
};

struct Java_javax_microedition_midlet_MIDletTunnelImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDletTunnelImpl */
};

struct Java_javax_microedition_rms_RecordComparator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordComparator */
};

struct Java_javax_microedition_rms_RecordEnumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordEnumeration */
};

struct Java_javax_microedition_rms_RecordFilter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordFilter */
};

struct Java_javax_microedition_rms_RecordListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordListener */
};

struct Java_javax_microedition_rms_RecordEnumerationImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordEnumerationImpl */
    /*  @4 */	struct Java_javax_microedition_rms_RecordStore * JVM_FIELD_CONST recordStore;
    /*  @8 */	struct Java_javax_microedition_rms_RecordFilter * JVM_FIELD_CONST filter;
    /* @12 */	struct Java_javax_microedition_rms_RecordComparator * JVM_FIELD_CONST comparator;
    /* @16 */	jint index;
    /* @20 */	jint_array * JVM_FIELD_CONST records;
    /* @24 */	jboolean keepEnumUpdated;
    /* @25 */	jbyte ___pad450;
    /* @26 */	jbyte ___pad451;
    /* @27 */	jbyte ___pad452;
};

struct Java_javax_microedition_rms_RecordStoreNotOpenException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreNotOpenException */
};

#ifdef __cplusplus
}
#endif

#endif /*_ROM_STRUCTS_H_*/
