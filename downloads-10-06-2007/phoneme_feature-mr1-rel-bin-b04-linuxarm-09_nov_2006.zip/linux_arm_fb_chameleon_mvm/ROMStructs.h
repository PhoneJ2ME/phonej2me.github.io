/*
 * Copyright  1990-2006 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation. 
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt). 
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA 
 * 
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa
 * Clara, CA 95054 or visit www.sun.com if you need additional
 * information or have any questions. 
 */

/* This file is auto-generated. Do not edit*/



#ifndef _ROM_STRUCTS_H_
#define _ROM_STRUCTS_H_

#ifdef __cplusplus
extern "C" {
#endif
#define _ROM_STRUCTS_VERSION_ "internal"

/* Define JVM_LIMIT_OBJECT_FIELD_WRITES=0 if your C
   compiler does not allow the 'const' modifier
   in the ROM structs */
#ifndef JVM_LIMIT_OBJECT_FIELD_WRITES
#define JVM_LIMIT_OBJECT_FIELD_WRITES 0 /* IMPL_NOTE: TMP */
#endif
#if !JVM_LIMIT_OBJECT_FIELD_WRITES
#define JVM_FIELD_CONST
#else
#define JVM_FIELD_CONST const
#endif

typedef struct {
    void * dummy;
    int length;
    jboolean elements[1];
} jboolean_array;
typedef struct {
    void * dummy;
    int length;
    jchar elements[1];
} jchar_array;
typedef struct {
    void * dummy;
    int length;
    jbyte elements[1];
} jbyte_array;
typedef struct {
    void * dummy;
    int length;
    jshort elements[1];
} jshort_array;
typedef struct {
    void * dummy;
    int length;
    jint elements[1];
} jint_array;
typedef struct {
    void * dummy;
    int length;
    jlong elements[1];
} jlong_array;
typedef struct {
    void * dummy;
    int length;
    struct Java_java_lang_Object * JVM_FIELD_CONST elements[1];
} jobject_array;
typedef struct {
    void * dummy;
    int length;
    jfloat elements[1];
} jfloat_array;
typedef struct {
    void * dummy;
    int length;
    jdouble elements[1];
} jdouble_array;

struct Java_java_lang_Object {
    /* java/lang/Object */
	void * __do_not_use__;
};

struct Java_java_lang_String {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/String */
    /*  @4 */	jchar_array * JVM_FIELD_CONST value;
    /*  @8 */	jint offset;
    /* @12 */	jint count;
};

struct Java_java_lang_Class {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Class */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST vmClass;
    /*  @8 */	jint status;
    /* @12 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
};

struct Java_java_lang_StringBuffer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/StringBuffer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST value;
    /*  @8 */	jint count;
    /* @12 */	jboolean shared;
    /* @13 */	jbyte ___pad1;
    /* @14 */	jbyte ___pad2;
    /* @15 */	jbyte ___pad3;
};

struct Java_java_lang_Thread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
};

struct Java_java_lang_Throwable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
};

struct Java_java_lang_Error {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
};

struct Java_java_io_InputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
};

struct Java_java_lang_Runtime {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Runtime */
};

struct Java_java_io_OutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
};

struct Java_java_io_PrintStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/PrintStream */
    /*  @4 */	struct Java_java_io_OutputStreamWriter * JVM_FIELD_CONST charOut;
    /*  @8 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST byteOut;
    /* @12 */	jboolean trouble;
    /* @13 */	jboolean closing;
    /* @14 */	jbyte ___pad4;
    /* @15 */	jbyte ___pad5;
};

struct Java_java_lang_System {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/System */
};

struct Java_java_lang_Math {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Math */
};

struct Java_com_sun_cldchi_jvm_JVM {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldchi/jvm/JVM */
};

struct Java_com_sun_cldchi_jvm_FileDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldchi/jvm/FileDescriptor */
    /*  @4 */	jint handle;
    /*  @8 */	jint valid;
};

struct Java_java_lang_ref_Reference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/ref/Reference */
};

struct Java_java_lang_ref_WeakReference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/ref/Reference */
    /* java/lang/ref/WeakReference */
    /*  @4 */	jint referent_index;
};

struct Java_java_lang_VirtualMachineError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/VirtualMachineError */
};

struct Java_java_lang_OutOfMemoryError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/VirtualMachineError */
    /* java/lang/OutOfMemoryError */
};

struct Java_java_lang_Runnable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Runnable */
};

struct Java_java_lang_Exception {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
};

struct Java_java_lang_RuntimeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
};

struct Java_java_lang_NullPointerException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/NullPointerException */
};

struct Java_java_lang_IndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
};

struct Java_java_lang_ArrayIndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
    /* java/lang/ArrayIndexOutOfBoundsException */
};

struct Java_java_lang_IllegalMonitorStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalMonitorStateException */
};

struct Java_java_lang_ArithmeticException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ArithmeticException */
};

struct Java_com_sun_cldc_isolate_Isolate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Isolate */
    /*  @4 */	jint _priority;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST _next;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST _uniqueId;
    /* @16 */	jint _terminated;
    /* @20 */	jint _saved_exit_code;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST _mainClass;
    /* @28 */	jobject_array * JVM_FIELD_CONST _mainArgs;
    /* @32 */	jobject_array * JVM_FIELD_CONST _classpath;
    /* @36 */	jint _memoryReserve;
    /* @40 */	jint _memoryLimit;
    /* @44 */	jint _APIAccess;
    /* @48 */	jint _ConnectDebugger;
    /* @52 */	jint _UseVerifier;
    /* @56 */	jint _profileId;
};

struct Java_java_lang_IllegalArgumentException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
};

struct Java_java_io_IOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
};

struct Java_com_sun_cldc_io_ResourceInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/cldc/io/ResourceInputStream */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST fileDecoder;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST savedDecoder;
};

struct Java_java_lang_InterruptedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/InterruptedException */
};

struct Java_java_lang_NoClassDefFoundError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* java/lang/NoClassDefFoundError */
};

struct Java_com_sun_cldc_isolate_IsolateResourceError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* com/sun/cldc/isolate/IsolateResourceError */
};

struct Java_com_sun_cldc_isolate_IsolateStartupException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/cldc/isolate/IsolateStartupException */
};

struct Java_java_lang_SecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/SecurityException */
};

struct Java_java_lang_StringIndexOutOfBoundsException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IndexOutOfBoundsException */
    /* java/lang/StringIndexOutOfBoundsException */
};

struct Java_com_sun_cldc_util_SemaphoreLock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/util/SemaphoreLock */
    /*  @4 */	jint permits;
};

struct Java_com_sun_cldc_util_Semaphore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/util/Semaphore */
    /*  @4 */	struct Java_com_sun_cldc_util_SemaphoreLock * JVM_FIELD_CONST lock;
};

struct Java_com_sun_cardreader_CardDeviceException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/cardreader/CardDeviceException */
};

struct Java_java_io_Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
};

struct Java_com_sun_cldc_i18n_StreamReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_java_io_Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
};

struct Java_com_sun_cldc_i18n_StreamWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
};

struct Java_com_sun_cldc_i18n_Helper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/Helper */
};

struct Java_java_io_UnsupportedEncodingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/UnsupportedEncodingException */
};

struct Java_java_lang_ClassCastException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ClassCastException */
};

struct Java_java_lang_ClassNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/ClassNotFoundException */
};

struct Java_java_lang_InstantiationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/InstantiationException */
};

struct Java_java_lang_IllegalAccessException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/IllegalAccessException */
};

struct Java_java_io_ByteArrayInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* java/io/ByteArrayInputStream */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint pos;
    /* @12 */	jint mark;
    /* @16 */	jint count;
};

struct Java_java_io_ByteArrayOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/ByteArrayOutputStream */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buf;
    /*  @8 */	jint count;
    /* @12 */	jboolean isClosed;
    /* @13 */	jbyte ___pad6;
    /* @14 */	jbyte ___pad7;
    /* @15 */	jbyte ___pad8;
};

struct Java_com_sun_cldc_i18n_j2me_Conv {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/j2me/Conv */
};

struct Java_com_sun_cldc_i18n_j2me_Gen_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/Gen_Reader */
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST enc;
    /* @20 */	jint id;
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint maxByteLen;
    /* @32 */	jbyte_array * JVM_FIELD_CONST tmp;
    /* @36 */	jint pos;
};

struct Java_com_sun_cldc_i18n_j2me_Gen_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/Gen_Writer */
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST enc;
    /* @24 */	jint id;
    /* @28 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @32 */	jint maxByteLen;
};

struct Java_com_sun_cldc_i18n_j2me_ISO8859_11_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/ISO8859_1_Reader */
};

struct Java_com_sun_cldc_i18n_j2me_ISO8859_11_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/ISO8859_1_Writer */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116BE_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_16BE_Reader */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_116BE_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_16BE_Writer */
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Reader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/cldc/i18n/StreamReader */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/cldc/i18n/j2me/UTF_8_Reader */
    /* @16 */	jint_array * JVM_FIELD_CONST readAhead;
    /* @20 */	jboolean newRead;
    /* @21 */	jbyte ___pad9;
    /* @22 */	jbyte ___pad10;
    /* @23 */	jbyte ___pad11;
};

struct Java_com_sun_cldc_i18n_j2me_UTF_18_1Writer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* com/sun/cldc/i18n/StreamWriter */
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* com/sun/cldc/i18n/j2me/UTF_8_Writer */
};

struct Java_com_sun_cldc_i18n_uclc_DefaultCaseConverter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/i18n/uclc/DefaultCaseConverter */
};

struct Java_javax_microedition_io_Connection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Connection */
};

struct Java_com_sun_cldc_io_ConnectionBaseInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/io/ConnectionBaseInterface */
};

struct Java_com_sun_cldc_isolate_IllegalIsolateStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* com/sun/cldc/isolate/IllegalIsolateStateException */
};

struct Java_com_sun_cldc_isolate_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Util */
};

struct Java_com_sun_cldc_isolate_Verifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/cldc/isolate/Verifier */
};

struct Java_java_util_TimeZone {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimeZone */
};

struct Java_java_util_Date {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Date */
    /*  @4 */	struct Java_java_util_Calendar * JVM_FIELD_CONST calendar;
    /*  @8 */	jlong fastTime;
};

struct Java_java_util_Calendar {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Calendar */
    /*  @4 */	jint_array * JVM_FIELD_CONST fields;
    /*  @8 */	jboolean_array * JVM_FIELD_CONST isSet;
    /* @12 */	jlong time;
    /* @20 */	struct Java_java_util_TimeZone * JVM_FIELD_CONST zone;
    /* @24 */	struct Java_java_util_Date * JVM_FIELD_CONST dateObj;
    /* @28 */	jboolean isTimeSet;
    /* @29 */	jbyte ___pad12;
    /* @30 */	jbyte ___pad13;
    /* @31 */	jbyte ___pad14;
};

struct Java_com_sun_cldc_util_j2me_CalendarImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Calendar */
    /*  @4 */	jint_array * JVM_FIELD_CONST fields;
    /*  @8 */	jboolean_array * JVM_FIELD_CONST isSet;
    /* @12 */	jlong time;
    /* @20 */	struct Java_java_util_TimeZone * JVM_FIELD_CONST zone;
    /* @24 */	struct Java_java_util_Date * JVM_FIELD_CONST dateObj;
    /* @28 */	jboolean isTimeSet;
    /* @29 */	jbyte ___pad15;
    /* @30 */	jbyte ___pad16;
    /* @31 */	jbyte ___pad17;
    /* com/sun/cldc/util/j2me/CalendarImpl */
};

struct Java_com_sun_cldc_util_j2me_TimeZoneImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimeZone */
    /* com/sun/cldc/util/j2me/TimeZoneImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST ID;
    /*  @8 */	jint startMonth;
    /* @12 */	jint startDay;
    /* @16 */	jint startDayOfWeek;
    /* @20 */	jint startTime;
    /* @24 */	jint endMonth;
    /* @28 */	jint endDay;
    /* @32 */	jint endDayOfWeek;
    /* @36 */	jint endTime;
    /* @40 */	jint startYear;
    /* @44 */	jint rawOffset;
    /* @48 */	jint startMode;
    /* @52 */	jint endMode;
    /* @56 */	jint dstSavings;
    /* @60 */	jboolean isCustom;
    /* @61 */	jboolean useDaylight;
    /* @62 */	jbyte ___pad18;
    /* @63 */	jbyte ___pad19;
};

struct Java_com_sun_cldchi_io_ConsoleOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/cldchi/io/ConsoleOutputStream */
};

struct Java_com_sun_j2mews_xml_rpc_Constants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2mews/xml/rpc/Constants */
};

struct Java_javax_xml_namespace_QName {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/namespace/QName */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST namespaceURI;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST localPart;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST prefix;
};

struct Java_javax_microedition_xml_rpc_Element {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Type */
    /*  @4 */	jint value;
    /* javax/microedition/xml/rpc/Element */
    /*  @8 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST name;
    /* @12 */	struct Java_javax_microedition_xml_rpc_Type * JVM_FIELD_CONST contentType;
    /* @16 */	jint minOccurs;
    /* @20 */	jint maxOccurs;
    /* @24 */	jboolean isNillable;
    /* @25 */	jboolean isArray;
    /* @26 */	jboolean isOptional;
    /* @27 */	jbyte ___pad20;
};

struct Java_com_sun_j2mews_xml_rpc_SOAPEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/j2mews/xml/rpc/SOAPEncoder */
    /*  @4 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST buffer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultNS;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST errString;
};

struct Java_com_sun_j2mews_xml_rpc_SOAPDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/j2mews/xml/rpc/SOAPDecoder */
    /*  @4 */	struct Java_javax_xml_parsers_SAXParser * JVM_FIELD_CONST parser;
    /*  @8 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST token;
    /* @12 */	jint state;
    /* @16 */	jint bodyNEnvelope;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST eName;
    /* @24 */	struct Java_javax_microedition_xml_rpc_ComplexType * JVM_FIELD_CONST faultCT;
    /* @28 */	struct Java_javax_microedition_xml_rpc_FaultDetailHandler * JVM_FIELD_CONST handler;
    /* @32 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST detailName;
    /* @36 */	struct Java_javax_microedition_xml_rpc_Element * JVM_FIELD_CONST handlerDetail;
    /* @40 */	struct Java_java_util_Stack * JVM_FIELD_CONST valueStack;
    /* @44 */	struct Java_java_util_Stack * JVM_FIELD_CONST typeStack;
    /* @48 */	struct Java_java_util_Stack * JVM_FIELD_CONST stateStack;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST errString;
    /* @56 */	jboolean processingHeader;
    /* @57 */	jboolean isNill;
    /* @58 */	jboolean faultMode;
    /* @59 */	jbyte ___pad21;
};

struct Java_javax_microedition_xml_rpc_FaultDetailHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/FaultDetailHandler */
};

struct Java_javax_microedition_io_HttpConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/HttpConnection */
};

struct Java_javax_microedition_xml_rpc_Type {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Type */
    /*  @4 */	jint value;
};

struct Java_javax_microedition_xml_rpc_Operation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Operation */
};

struct Java_com_sun_j2mews_xml_rpc_OperationImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Operation */
    /* com/sun/j2mews/xml/rpc/OperationImpl */
    /*  @4 */	jobject_array * JVM_FIELD_CONST properties;
    /*  @8 */	jint propertyIndex;
    /* @12 */	struct Java_com_sun_j2mews_xml_rpc_SOAPEncoder * JVM_FIELD_CONST encoder;
    /* @16 */	struct Java_com_sun_j2mews_xml_rpc_SOAPDecoder * JVM_FIELD_CONST decoder;
    /* @20 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST name;
    /* @24 */	struct Java_javax_microedition_xml_rpc_Element * JVM_FIELD_CONST inputType;
    /* @28 */	struct Java_javax_microedition_xml_rpc_Element * JVM_FIELD_CONST returnType;
    /* @32 */	struct Java_javax_microedition_xml_rpc_FaultDetailHandler * JVM_FIELD_CONST faultHandler;
    /* @36 */	jboolean resourceMoved;
    /* @37 */	jbyte ___pad22;
    /* @38 */	jbyte ___pad23;
    /* @39 */	jbyte ___pad24;
};

struct Java_javax_xml_rpc_JAXRPCException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/xml/rpc/JAXRPCException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST cause;
};

struct Java_java_rmi_RemoteException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/rmi/RemoteException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST detail;
};

struct Java_java_rmi_MarshalException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/rmi/RemoteException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST detail;
    /* java/rmi/MarshalException */
};

struct Java_java_rmi_ServerException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/rmi/RemoteException */
    /* @12 */	struct Java_java_lang_Throwable * JVM_FIELD_CONST detail;
    /* java/rmi/ServerException */
};

struct Java_javax_microedition_xml_rpc_FaultDetailException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/xml/rpc/FaultDetailException */
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST faultDetail;
    /* @16 */	struct Java_javax_xml_namespace_QName * JVM_FIELD_CONST faultDetailName;
};

struct Java_javax_xml_parsers_SAXParserFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParserFactory */
    /*  @4 */	jboolean namespaceAware;
    /*  @5 */	jboolean validating;
    /* @6 */	jbyte ___pad25;
    /* @7 */	jbyte ___pad26;
};

struct Java_javax_xml_parsers_SAXParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParser */
};

struct Java_java_util_Stack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
    /* java/util/Stack */
};

struct Java_org_xml_sax_helpers_DefaultHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
};

struct Java_javax_microedition_xml_rpc_ComplexType {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/xml/rpc/Type */
    /*  @4 */	jint value;
    /* javax/microedition/xml/rpc/ComplexType */
    /*  @8 */	jobject_array * JVM_FIELD_CONST elements;
};

struct Java_java_lang_Boolean {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Boolean */
    /*  @4 */	jboolean value;
    /* @5 */	jbyte ___pad27;
    /* @6 */	jbyte ___pad28;
    /* @7 */	jbyte ___pad29;
};

struct Java_java_lang_Byte {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Byte */
    /*  @4 */	jbyte value;
    /* @5 */	jbyte ___pad30;
    /* @6 */	jbyte ___pad31;
    /* @7 */	jbyte ___pad32;
};

struct Java_java_lang_Short {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Short */
    /*  @4 */	jshort value;
    /* @5 */	jbyte ___pad33;
    /* @6 */	jbyte ___pad34;
};

struct Java_java_lang_Integer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Integer */
    /*  @4 */	jint value;
};

struct Java_java_lang_Long {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Long */
    /*  @4 */	jlong value;
};

struct Java_java_lang_Float {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Float */
    /*  @4 */	jfloat value;
};

struct Java_java_lang_Double {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Double */
    /*  @4 */	jdouble value;
};

struct Java_org_xml_sax_InputSource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/InputSource */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST publicId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST systemId;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST byteStream;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST encoding;
    /* @20 */	struct Java_java_io_Reader * JVM_FIELD_CONST characterStream;
};

struct Java_org_xml_sax_Locator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/Locator */
};

struct Java_org_xml_sax_Attributes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/Attributes */
};

struct Java_org_xml_sax_SAXParseException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
    /* org/xml/sax/SAXParseException */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST publicId;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST systemId;
    /* @20 */	jint lineNumber;
    /* @24 */	jint columnNumber;
};

struct Java_javax_xml_parsers_ParserConfigurationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/xml/parsers/ParserConfigurationException */
};

struct Java_org_xml_sax_SAXException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
};

struct Java_java_lang_NumberFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
    /* java/lang/NumberFormatException */
};

struct Java_java_util_Vector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
};

struct Java_java_util_Enumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Enumeration */
};

struct Java_com_sun_j2mews_xml_rpc_TypedVector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Vector */
    /*  @4 */	jobject_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint elementCount;
    /* @12 */	jint capacityIncrement;
    /* com/sun/j2mews/xml/rpc/TypedVector */
    /* @16 */	jint type;
    /* @20 */	jint minOccurs;
    /* @24 */	jint maxOccurs;
    /* @28 */	jboolean nillable;
    /* @29 */	jboolean isArrayWrapper;
    /* @30 */	jbyte ___pad35;
    /* @31 */	jbyte ___pad36;
};

struct Java_com_sun_kvem_jsr082_bluetooth_BCC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BCC */
};

struct Java_javax_bluetooth_DeviceClass {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/DeviceClass */
    /*  @4 */	jint record;
};

struct Java_com_sun_midp_jsr082_bluetooth_BluetoothStack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothStack */
    /*  @4 */	jint nativeInstance;
    /*  @8 */	struct Java_javax_bluetooth_DiscoveryListener * JVM_FIELD_CONST discListener;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST nameResults;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST authenticateResults;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST encryptResults;
    /* @24 */	jlong ASK_FRIENDLY_NAME_TIMEOUT;
    /* @32 */	jlong AUTHENTICATE_TIMEOUT;
    /* @40 */	jlong ENCRYPT_TIMEOUT;
    /* @48 */	jint pollRequests;
    /* @52 */	struct Java_java_util_Vector * JVM_FIELD_CONST inquiryHistory;
};

struct Java_com_sun_kvem_jsr082_bluetooth_NativeBCC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BCC */
    /* com/sun/kvem/jsr082/bluetooth/NativeBCC */
    /*  @4 */	jchar ADDR_DELIMETER;
    /* @5 */	jbyte ___pad37;
    /* @6 */	jbyte ___pad38;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDDB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDDB */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordSerializer * JVM_FIELD_CONST srs;
};

struct Java_com_sun_midp_io_BluetoothUrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/BluetoothUrl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /*  @8 */	jint port;
    /* @12 */	jint protocol;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST uuid;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST caseSensitiveUrl;
    /* @32 */	jint receiveMTU;
    /* @36 */	jint transmitMTU;
    /* @40 */	jint length;
    /* @44 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST parameters;
    /* @48 */	jboolean isServer;
    /* @49 */	jboolean master;
    /* @50 */	jboolean encrypt;
    /* @51 */	jboolean authenticate;
    /* @52 */	jboolean authorize;
    /* @53 */	jboolean explicitAuthenticate;
    /* @54 */	jboolean isSystem;
    /* @55 */	jbyte ___pad39;
};

struct Java_javax_bluetooth_RemoteDevice {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/RemoteDevice */
    /*  @4 */	jlong l_address;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST s_address;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST friendlyName;
};

struct Java_com_sun_kvem_jsr082_bluetooth_DiscoveryAgentImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/DiscoveryAgentImpl */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST knownDevices;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST cachedDevices;
    /* @12 */	struct Java_javax_bluetooth_DiscoveryListener * JVM_FIELD_CONST d_listener;
    /* @16 */	struct Java_java_lang_Object * JVM_FIELD_CONST d_lock;
    /* @20 */	struct Java_com_sun_kvem_jsr082_bluetooth_SelectServiceHandler * JVM_FIELD_CONST selectServiceHandler;
};

struct Java_com_sun_kvem_jsr082_bluetooth_RemoteDeviceImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/RemoteDevice */
    /*  @4 */	jlong l_address;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST s_address;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST friendlyName;
    /* com/sun/kvem/jsr082/bluetooth/RemoteDeviceImpl */
};

struct Java_com_sun_kvem_jsr082_bluetooth_BluetoothConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BluetoothConnection */
    /*  @4 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST remoteDevice;
    /* @16 */	jboolean authorized;
    /* @17 */	jboolean encrypted;
    /* @18 */	jbyte ___pad40;
    /* @19 */	jbyte ___pad41;
};

struct Java_javax_bluetooth_LocalDevice {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/LocalDevice */
    /*  @4 */	struct Java_javax_bluetooth_DiscoveryAgent * JVM_FIELD_CONST discoveryAgent;
};

struct Java_javax_bluetooth_BluetoothConnectionException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/bluetooth/BluetoothConnectionException */
    /* @12 */	jint status;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceRecordImpl */
    /*  @4 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST remoteDevice;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_BluetoothNotifier * JVM_FIELD_CONST notifier;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST attributesTable;
    /* @16 */	jint serviceClasses;
    /* @20 */	jint protocol;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST btaddr;
    /* @28 */	jint port;
};

struct Java_javax_bluetooth_ServiceRecord {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/ServiceRecord */
};

struct Java_javax_bluetooth_DataElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/DataElement */
    /*  @4 */	jint valueType;
    /*  @8 */	jlong longValue;
    /* @16 */	struct Java_java_lang_Object * JVM_FIELD_CONST miscValue;
    /* @20 */	jboolean booleanValue;
    /* @21 */	jbyte ___pad42;
    /* @22 */	jbyte ___pad43;
    /* @23 */	jbyte ___pad44;
};

struct Java_com_sun_kvem_jsr082_bluetooth_BluetoothNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BluetoothNotifier */
    /*  @4 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordImpl * JVM_FIELD_CONST serviceRec;
    /* @12 */	jint mode;
    /* @16 */	jboolean isClosed;
    /* @17 */	jbyte ___pad45;
    /* @18 */	jbyte ___pad46;
    /* @19 */	jbyte ___pad47;
};

struct Java_java_util_Hashtable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Hashtable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST table;
    /*  @8 */	jint count;
    /* @12 */	jint threshold;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPResponseListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPResponseListener */
};

struct Java_javax_bluetooth_ServiceRegistrationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/bluetooth/ServiceRegistrationException */
};

struct Java_javax_bluetooth_UUID {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/UUID */
    /*  @4 */	jlong highBits;
    /* @12 */	jlong lowBits;
};

struct Java_com_sun_kvem_jsr082_bluetooth_DataElementSerializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/DataElementSerializer */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST readBuffer;
    /* @12 */	jlong writePos;
    /* @20 */	jlong readPos;
    /* @28 */	struct Java_java_util_Stack * JVM_FIELD_CONST readPosStack;
};

struct Java_javax_bluetooth_L2CAPConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/L2CAPConnection */
};

struct Java_com_sun_kvem_jsr082_bluetooth_DataL2CAPReaderWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/DataElementSerializer */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST readBuffer;
    /* @12 */	jlong writePos;
    /* @20 */	jlong readPos;
    /* @28 */	struct Java_java_util_Stack * JVM_FIELD_CONST readPosStack;
    /* com/sun/kvem/jsr082/bluetooth/DataL2CAPReaderWriter */
    /* @32 */	struct Java_javax_bluetooth_L2CAPConnection * JVM_FIELD_CONST con;
    /* @36 */	jlong readSize;
};

struct Java_javax_bluetooth_DiscoveryListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/DiscoveryListener */
};

struct Java_com_sun_kvem_jsr082_bluetooth_DiscoveryAgentImpl_0004Completed {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/DiscoveryAgentImpl$Completed */
    /*  @4 */	jint discType;
    /*  @8 */	struct Java_javax_bluetooth_DiscoveryListener * JVM_FIELD_CONST listener;
    /* @12 */	struct Java_com_sun_kvem_jsr082_bluetooth_DiscoveryAgentImpl * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SelectServiceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SelectServiceHandler */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST btDevs;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST btDevsHash;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST btDevsLock;
    /* @16 */	struct Java_com_sun_kvem_jsr082_bluetooth_DiscoveryAgentImpl * JVM_FIELD_CONST agent;
    /* @20 */	jboolean selectDevDisStarted;
    /* @21 */	jboolean selectDevDisStopped;
    /* @22 */	jbyte ___pad48;
    /* @23 */	jbyte ___pad49;
};

struct Java_javax_bluetooth_BluetoothStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/bluetooth/BluetoothStateException */
};

struct Java_com_sun_kvem_jsr082_bluetooth_LocalDeviceImpl_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/LocalDeviceImpl$1 */
};

struct Java_com_sun_kvem_jsr082_bluetooth_LocalDeviceImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/LocalDeviceImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST bluetoothAddress;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_LocalDeviceImpl_0004CancelerOfLIAC * JVM_FIELD_CONST cancelerOfLIAC;
};

struct Java_com_sun_kvem_jsr082_bluetooth_LocalDeviceImpl_0004CancelerOfLIAC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/LocalDeviceImpl$CancelerOfLIAC */
    /*  @4 */	jlong MINUTE;
    /* @12 */	jint RETRY_DELAY;
    /* @16 */	jint savedCode;
    /* @20 */	jlong startTime;
    /* @28 */	struct Java_com_sun_kvem_jsr082_bluetooth_LocalDeviceImpl * JVM_FIELD_CONST this_0440;
    /* @32 */	jboolean isCanceledFromOutside;
    /* @33 */	jbyte ___pad50;
    /* @34 */	jbyte ___pad51;
    /* @35 */	jbyte ___pad52;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordSerializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceRecordSerializer */
};

struct Java_com_sun_midp_security_SecurityToken {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityToken */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDP {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDP */
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$1 */
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /*  @8 */	jint refCount;
    /* @12 */	struct Java_javax_bluetooth_L2CAPConnection * JVM_FIELD_CONST connection;
    /* @16 */	struct Java_com_sun_kvem_jsr082_bluetooth_DataL2CAPReaderWriter * JVM_FIELD_CONST rw;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST transactions;
    /* @24 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport_0004Receiver * JVM_FIELD_CONST receiver;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST readLock;
    /* @32 */	struct Java_java_lang_Object * JVM_FIELD_CONST writeLock;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport_0004Receiver {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$Receiver */
    /*  @4 */	jint startCounter;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST this_0440;
    /* @12 */	jboolean canceled;
    /* @13 */	jboolean stopped;
    /* @14 */	jbyte ___pad53;
    /* @15 */	jbyte ___pad54;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport_0004ServiceTransaction {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceTransaction */
    /*  @4 */	jint transactionID;
    /*  @8 */	jint effectiveTransactionID;
    /* @12 */	jlong parameterLength;
    /* @20 */	jbyte_array * JVM_FIELD_CONST continuationState;
    /* @24 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPResponseListener * JVM_FIELD_CONST listener;
    /* @28 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST this_0440;
    /* @32 */	jbyte pduID;
    /* @33 */	jbyte ___pad55;
    /* @34 */	jbyte ___pad56;
    /* @35 */	jbyte ___pad57;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport_0004ServiceAttributeTransaction {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceTransaction */
    /*  @4 */	jint transactionID;
    /*  @8 */	jint effectiveTransactionID;
    /* @12 */	jlong parameterLength;
    /* @20 */	jbyte_array * JVM_FIELD_CONST continuationState;
    /* @24 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPResponseListener * JVM_FIELD_CONST listener;
    /* @28 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST __dup1__this_0440;
    /* @32 */	jbyte pduID;
    /* @33 */	jbyte ___pad58;
    /* @34 */	jbyte ___pad59;
    /* @35 */	jbyte ___pad60;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceAttributeTransaction */
    /* @36 */	jint serviceRecordHandle;
    /* @40 */	struct Java_javax_bluetooth_DataElement * JVM_FIELD_CONST attributeIDList;
    /* @44 */	jbyte_array * JVM_FIELD_CONST attributes;
    /* @48 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport_0004ServiceSearchAttributeTransaction {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceTransaction */
    /*  @4 */	jint transactionID;
    /*  @8 */	jint effectiveTransactionID;
    /* @12 */	jlong parameterLength;
    /* @20 */	jbyte_array * JVM_FIELD_CONST continuationState;
    /* @24 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPResponseListener * JVM_FIELD_CONST listener;
    /* @28 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST __dup1__this_0440;
    /* @32 */	jbyte pduID;
    /* @33 */	jbyte ___pad61;
    /* @34 */	jbyte ___pad62;
    /* @35 */	jbyte ___pad63;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceSearchAttributeTransaction */
    /* @36 */	struct Java_javax_bluetooth_DataElement * JVM_FIELD_CONST uuidData;
    /* @40 */	struct Java_javax_bluetooth_DataElement * JVM_FIELD_CONST attrData;
    /* @44 */	jbyte_array * JVM_FIELD_CONST attributes;
    /* @48 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport_0004ServiceSearchTransaction {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceTransaction */
    /*  @4 */	jint transactionID;
    /*  @8 */	jint effectiveTransactionID;
    /* @12 */	jlong parameterLength;
    /* @20 */	jbyte_array * JVM_FIELD_CONST continuationState;
    /* @24 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPResponseListener * JVM_FIELD_CONST listener;
    /* @28 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST __dup1__this_0440;
    /* @32 */	jbyte pduID;
    /* @33 */	jbyte ___pad64;
    /* @34 */	jbyte ___pad65;
    /* @35 */	jbyte ___pad66;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient$SDPTransport$ServiceSearchTransaction */
    /* @36 */	struct Java_javax_bluetooth_DataElement * JVM_FIELD_CONST serviceSearchPattern;
    /* @40 */	jint_array * JVM_FIELD_CONST handleList;
    /* @44 */	jint offset;
    /* @48 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPClient */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient_0004SDPTransport * JVM_FIELD_CONST transport;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPServer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPServer */
    /*  @4 */	struct Java_javax_bluetooth_L2CAPConnectionNotifier * JVM_FIELD_CONST conNotifier;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST connections;
    /* @12 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPServer_0004Acceptor * JVM_FIELD_CONST acceptor;
    /* @16 */	jboolean acceptorStarted;
    /* @17 */	jbyte ___pad67;
    /* @18 */	jbyte ___pad68;
    /* @19 */	jbyte ___pad69;
};

struct Java_javax_bluetooth_L2CAPConnectionNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/L2CAPConnectionNotifier */
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPServer_0004Acceptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPServer$Acceptor */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPServer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_SDPServer_0004Sender {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/SDPServer$Sender */
    /*  @4 */	struct Java_javax_bluetooth_L2CAPConnection * JVM_FIELD_CONST connection;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_DataL2CAPReaderWriter * JVM_FIELD_CONST readerWriter;
    /* @12 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPServer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordImpl_0004SRSDPListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceRecordImpl$SRSDPListener */
    /*  @4 */	jobject_array * JVM_FIELD_CONST attrValues;
    /*  @8 */	struct Java_java_io_IOException * JVM_FIELD_CONST ioExcpt;
    /* @12 */	jint_array * JVM_FIELD_CONST attrIDs;
    /* @16 */	struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordImpl * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceSearcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceSearcherBase */
    /*  @4 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST btDev;
    /*  @8 */	jobject_array * JVM_FIELD_CONST uuidSet;
    /* @12 */	jint_array * JVM_FIELD_CONST attrSet;
    /* com/sun/kvem/jsr082/bluetooth/ServiceSearcher */
    /* @16 */	struct Java_javax_bluetooth_DiscoveryListener * JVM_FIELD_CONST discListener;
    /* @20 */	struct Java_com_sun_kvem_jsr082_bluetooth_SDPClient * JVM_FIELD_CONST sdp;
    /* @24 */	jint_array * JVM_FIELD_CONST handles;
    /* @28 */	jint processedHandle;
    /* @32 */	jshort transactionID;
    /* @34 */	jboolean inactive;
    /* @35 */	jboolean canceled;
    /* @36 */	jboolean notified;
    /* @37 */	jbyte ___pad70;
    /* @38 */	jbyte ___pad71;
    /* @39 */	jbyte ___pad72;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceSearcher_0004NotifyListenerRunner {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceSearcher$NotifyListenerRunner */
    /*  @4 */	jint respCode;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_ServiceSearcher * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceSearcherBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceSearcherBase */
    /*  @4 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST btDev;
    /*  @8 */	jobject_array * JVM_FIELD_CONST uuidSet;
    /* @12 */	jint_array * JVM_FIELD_CONST attrSet;
};

struct Java_com_sun_kvem_jsr082_bluetooth_ServiceSelector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/ServiceSearcherBase */
    /*  @4 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST btDev;
    /*  @8 */	jobject_array * JVM_FIELD_CONST uuidSet;
    /* @12 */	jint_array * JVM_FIELD_CONST attrSet;
    /* com/sun/kvem/jsr082/bluetooth/ServiceSelector */
    /* @16 */	jobject_array * JVM_FIELD_CONST attrValues;
    /* @20 */	struct Java_java_io_IOException * JVM_FIELD_CONST ioExcpt;
};

struct Java_com_sun_kvem_jsr082_obex_ClientOperation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ClientOperation */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ClientSessionImpl * JVM_FIELD_CONST stream;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_obex_HeaderSetImpl * JVM_FIELD_CONST recvHeaders;
    /* @12 */	struct Java_com_sun_kvem_jsr082_obex_HeaderSetImpl * JVM_FIELD_CONST sentHeaders;
    /* @16 */	jbyte_array * JVM_FIELD_CONST head;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* @24 */	jint openObjects;
    /* @28 */	struct Java_com_sun_kvem_jsr082_obex_ClientOperation_0004OperationInputStream * JVM_FIELD_CONST is;
    /* @32 */	struct Java_com_sun_kvem_jsr082_obex_ClientOperation_0004OperationOutputStream * JVM_FIELD_CONST os;
    /* @36 */	jboolean inputStreamOpened;
    /* @37 */	jboolean inputStreamClosed;
    /* @38 */	jboolean outputStreamOpened;
    /* @39 */	jboolean outputStreamClosed;
    /* @40 */	jboolean inputStreamEof;
    /* @41 */	jboolean firstDataBlock;
    /* @42 */	jboolean isGet;
    /* @43 */	jboolean requestEnd;
    /* @44 */	jboolean operationEnd;
    /* @45 */	jboolean operationClosed;
    /* @46 */	jboolean restartable;
    /* @47 */	jboolean restarting;
    /* @48 */	jboolean abortingOperation;
    /* @49 */	jbyte ___pad73;
    /* @50 */	jbyte ___pad74;
    /* @51 */	jbyte ___pad75;
};

struct Java_com_sun_kvem_jsr082_obex_ClientOperation_0004FakeInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/kvem/jsr082/obex/ClientOperation$FakeInputStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ClientOperation * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_obex_ClientSessionImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ObexPacketStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ObexTransport * JVM_FIELD_CONST transport;
    /*  @8 */	struct Java_javax_obex_Authenticator * JVM_FIELD_CONST authenticator;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST authResponses;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST authChallenges;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST queuedHeaders;
    /* @24 */	struct Java_com_sun_kvem_jsr082_obex_QueuedHeader * JVM_FIELD_CONST newHeader;
    /* @28 */	struct Java_java_util_Stack * JVM_FIELD_CONST emptyHeadersPool;
    /* @32 */	jint OBEX_MAXIMUM_PACKET_LENGTH;
    /* @36 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @40 */	jbyte_array * JVM_FIELD_CONST cache;
    /* @44 */	jint packetLength;
    /* @48 */	jint packetOffset;
    /* @52 */	jint packetType;
    /* @56 */	jint maxSendLength;
    /* @60 */	jint dataOffset;
    /* @64 */	jboolean moreHeaders;
    /* @65 */	jboolean challengesToSend;
    /* @66 */	jboolean headerOverflow;
    /* @67 */	jboolean containsTargetHeader;
    /* @68 */	jboolean authFailed;
    /* @69 */	jboolean isClient;
    /* @70 */	jboolean isConnected;
    /* @71 */	jboolean dataOpened;
    /* @72 */	jboolean dataClosed;
    /* @73 */	jboolean isEof;
    /* @74 */	jbyte ___pad76;
    /* @75 */	jbyte ___pad77;
    /* com/sun/kvem/jsr082/obex/ClientSessionImpl */
    /* @76 */	struct Java_java_lang_Object * JVM_FIELD_CONST lockObject;
    /* @80 */	jint owner;
    /* @84 */	struct Java_javax_obex_Operation * JVM_FIELD_CONST operation;
    /* @88 */	jlong connId;
    /* @96 */	jboolean busy;
    /* @97 */	jbyte ___pad78;
    /* @98 */	jbyte ___pad79;
    /* @99 */	jbyte ___pad80;
};

struct Java_com_sun_kvem_jsr082_obex_HeaderSetImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/HeaderSetImpl */
    /*  @4 */	jint owner;
    /*  @8 */	jint packetType;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST headers;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST challenges;
};

struct Java_com_sun_kvem_jsr082_obex_ClientOperation_0004OperationInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/kvem/jsr082/obex/ClientOperation$OperationInputStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ClientOperation * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_obex_ClientOperation_0004OperationOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/kvem/jsr082/obex/ClientOperation$OperationOutputStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ClientOperation * JVM_FIELD_CONST this_0440;
};

struct Java_javax_obex_Operation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/Operation */
};

struct Java_java_io_DataOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* java/io/DataOutputStream */
    /*  @4 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
};

struct Java_javax_microedition_io_OutputConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/OutputConnection */
};

struct Java_java_io_DataInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* java/io/DataInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_javax_microedition_io_InputConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/InputConnection */
};

struct Java_javax_microedition_io_StreamConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/StreamConnection */
};

struct Java_javax_microedition_io_ContentConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/ContentConnection */
};

struct Java_javax_obex_HeaderSet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/HeaderSet */
};

struct Java_com_sun_kvem_jsr082_obex_ObexAuth {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ObexAuth */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST realm;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST nonce;
    /* @12 */	jbyte_array * JVM_FIELD_CONST realm_array;
    /* @16 */	jint challengeLength;
    /* @20 */	jboolean userID;
    /* @21 */	jboolean access;
    /* @22 */	jbyte ___pad81;
    /* @23 */	jbyte ___pad82;
};

struct Java_com_sun_kvem_jsr082_obex_ObexTransport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ObexTransport */
};

struct Java_javax_obex_Authenticator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/Authenticator */
};

struct Java_javax_obex_ClientSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/ClientSession */
};

struct Java_com_sun_kvem_jsr082_obex_ObexPacketStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ObexPacketStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ObexTransport * JVM_FIELD_CONST transport;
    /*  @8 */	struct Java_javax_obex_Authenticator * JVM_FIELD_CONST authenticator;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST authResponses;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST authChallenges;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST queuedHeaders;
    /* @24 */	struct Java_com_sun_kvem_jsr082_obex_QueuedHeader * JVM_FIELD_CONST newHeader;
    /* @28 */	struct Java_java_util_Stack * JVM_FIELD_CONST emptyHeadersPool;
    /* @32 */	jint OBEX_MAXIMUM_PACKET_LENGTH;
    /* @36 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @40 */	jbyte_array * JVM_FIELD_CONST cache;
    /* @44 */	jint packetLength;
    /* @48 */	jint packetOffset;
    /* @52 */	jint packetType;
    /* @56 */	jint maxSendLength;
    /* @60 */	jint dataOffset;
    /* @64 */	jboolean moreHeaders;
    /* @65 */	jboolean challengesToSend;
    /* @66 */	jboolean headerOverflow;
    /* @67 */	jboolean containsTargetHeader;
    /* @68 */	jboolean authFailed;
    /* @69 */	jboolean isClient;
    /* @70 */	jboolean isConnected;
    /* @71 */	jboolean dataOpened;
    /* @72 */	jboolean dataClosed;
    /* @73 */	jboolean isEof;
    /* @74 */	jbyte ___pad83;
    /* @75 */	jbyte ___pad84;
};

struct Java_com_sun_kvem_jsr082_obex_QueuedHeader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/QueuedHeader */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ObexPacketStream * JVM_FIELD_CONST stream;
    /*  @8 */	jint type;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST value;
    /* @16 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @20 */	jint packetLength;
};

struct Java_com_sun_kvem_jsr082_obex_FakeInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/kvem/jsr082/obex/FakeInputStream */
};

struct Java_com_sun_kvem_jsr082_obex_FakeOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/kvem/jsr082/obex/FakeOutputStream */
};

struct Java_javax_obex_PasswordAuthentication {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/PasswordAuthentication */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST password;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST userName;
};

struct Java_java_io_InterruptedIOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/InterruptedIOException */
    /* @12 */	jint bytesTransferred;
};

struct Java_com_sun_kvem_jsr082_obex_ObexTransportNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ObexTransportNotifier */
};

struct Java_com_sun_midp_crypto_MessageDigest {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
};

struct Java_com_sun_kvem_jsr082_obex_SSLWrapper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/SSLWrapper */
    /*  @4 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md5;
};

struct Java_com_sun_midp_crypto_GeneralSecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
};

struct Java_com_sun_midp_crypto_DigestException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/DigestException */
};

struct Java_javax_obex_ServerRequestHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/ServerRequestHandler */
    /*  @4 */	jlong connId;
};

struct Java_com_sun_kvem_jsr082_obex_ServerConnectionImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ObexPacketStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ObexTransport * JVM_FIELD_CONST transport;
    /*  @8 */	struct Java_javax_obex_Authenticator * JVM_FIELD_CONST authenticator;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST authResponses;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST authChallenges;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST queuedHeaders;
    /* @24 */	struct Java_com_sun_kvem_jsr082_obex_QueuedHeader * JVM_FIELD_CONST newHeader;
    /* @28 */	struct Java_java_util_Stack * JVM_FIELD_CONST emptyHeadersPool;
    /* @32 */	jint OBEX_MAXIMUM_PACKET_LENGTH;
    /* @36 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @40 */	jbyte_array * JVM_FIELD_CONST cache;
    /* @44 */	jint packetLength;
    /* @48 */	jint packetOffset;
    /* @52 */	jint packetType;
    /* @56 */	jint maxSendLength;
    /* @60 */	jint dataOffset;
    /* @64 */	jboolean moreHeaders;
    /* @65 */	jboolean challengesToSend;
    /* @66 */	jboolean headerOverflow;
    /* @67 */	jboolean containsTargetHeader;
    /* @68 */	jboolean authFailed;
    /* @69 */	jboolean isClient;
    /* @70 */	jboolean __dup1__isConnected;
    /* @71 */	jboolean dataOpened;
    /* @72 */	jboolean dataClosed;
    /* @73 */	jboolean isEof;
    /* @74 */	jbyte ___pad85;
    /* @75 */	jbyte ___pad86;
    /* com/sun/kvem/jsr082/obex/ServerConnectionImpl */
    /* @76 */	struct Java_javax_obex_ServerRequestHandler * JVM_FIELD_CONST handler;
    /* @80 */	jint owner;
    /* @84 */	jlong connId;
    /* @92 */	jboolean isConnected;
    /* @93 */	jboolean operationHeadersOverflow;
    /* @94 */	jboolean operationClosed;
    /* @95 */	jbyte ___pad87;
};

struct Java_com_sun_kvem_jsr082_obex_ServerOperation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/ServerOperation */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_obex_HeaderSetImpl * JVM_FIELD_CONST recvHeaders;
    /* @12 */	struct Java_com_sun_kvem_jsr082_obex_ServerConnectionImpl * JVM_FIELD_CONST stream;
    /* @16 */	jint opcode;
    /* @20 */	struct Java_com_sun_kvem_jsr082_obex_ServerOperation_0004OperationInputStream * JVM_FIELD_CONST is;
    /* @24 */	struct Java_com_sun_kvem_jsr082_obex_ServerOperation_0004OperationOutputStream * JVM_FIELD_CONST os;
    /* @28 */	jbyte_array * JVM_FIELD_CONST head;
    /* @32 */	jboolean isGet;
    /* @33 */	jboolean isAborted;
    /* @34 */	jboolean requestEnd;
    /* @35 */	jboolean inputStreamOpened;
    /* @36 */	jboolean outputStreamOpened;
    /* @37 */	jboolean inputStreamEof;
    /* @38 */	jbyte ___pad88;
    /* @39 */	jbyte ___pad89;
};

struct Java_com_sun_kvem_jsr082_obex_ServerOperation_0004OperationInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/kvem/jsr082/obex/ServerOperation$OperationInputStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ServerOperation * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_jsr082_obex_ServerOperation_0004OperationOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/kvem/jsr082/obex/ServerOperation$OperationOutputStream */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ServerOperation * JVM_FIELD_CONST this_0440;
};

struct Java_javax_obex_SessionNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/SessionNotifier */
};

struct Java_com_sun_kvem_jsr082_obex_SessionNotifierImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/obex/SessionNotifierImpl */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_obex_ObexTransportNotifier * JVM_FIELD_CONST notifier;
};

struct Java_com_sun_kvem_midp_pim_PIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMField */
};

struct Java_com_sun_kvem_midp_pim_AbstractPIMList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad90;
    /* @26 */	jbyte ___pad91;
    /* @27 */	jbyte ___pad92;
};

struct Java_com_sun_kvem_midp_pim_PIMHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMHandler */
};

struct Java_com_sun_kvem_midp_pim_PIMFormat {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMFormat */
};

struct Java_javax_microedition_pim_PIMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIMItem */
};

struct Java_com_sun_kvem_midp_pim_AbstractPIMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @28 */	jint type;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad93;
    /* @38 */	jbyte ___pad94;
    /* @39 */	jbyte ___pad95;
};

struct Java_javax_microedition_pim_PIMList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIMList */
};

struct Java_javax_microedition_pim_PIMException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/pim/PIMException */
    /* @12 */	jint exception_reason;
};

struct Java_javax_microedition_pim_FieldFullException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/pim/FieldFullException */
    /* @12 */	jint offending_field;
};

struct Java_com_sun_kvem_midp_pim_EmptyPIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/EmptyPIMField */
};

struct Java_com_sun_kvem_midp_pim_ScalarPIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/ScalarPIMField */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST value;
    /*  @8 */	jint attributes;
};

struct Java_com_sun_kvem_midp_pim_VectorPIMField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/VectorPIMField */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST values;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST attributes;
};

struct Java_javax_microedition_pim_UnsupportedFieldException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/pim/UnsupportedFieldException */
};

struct Java_com_sun_kvem_midp_pim_AbstractPIMList_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList$1 */
    /*  @4 */	jint index;
    /*  @8 */	jobject_array * JVM_FIELD_CONST val_044data;
    /* @12 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST this_0440;
};

struct Java_java_util_NoSuchElementException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/util/NoSuchElementException */
};

struct Java_com_sun_kvem_midp_pim_PIMItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMItem */
};

struct Java_com_sun_kvem_midp_pim_Contact {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/Contact */
};

struct Java_javax_microedition_pim_Contact {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/Contact */
};

struct Java_com_sun_kvem_midp_pim_ContactImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @28 */	jint type;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad96;
    /* @38 */	jbyte ___pad97;
    /* @39 */	jbyte ___pad98;
    /* com/sun/kvem/midp/pim/ContactImpl */
};

struct Java_com_sun_kvem_midp_pim_LineReader_0004Matcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/LineReader$Matcher */
};

struct Java_com_sun_kvem_midp_pim_LineReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* java/io/InputStreamReader */
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST __dup1__in;
    /* com/sun/kvem/midp/pim/LineReader */
    /* @16 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* @20 */	struct Java_com_sun_kvem_midp_pim_LineReader_0004Matcher * JVM_FIELD_CONST matcher;
};

struct Java_com_sun_kvem_midp_pim_formats_FormatSupport_0004DataElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/FormatSupport$DataElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST propertyName;
    /*  @8 */	jobject_array * JVM_FIELD_CONST attributes;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST data;
};

struct Java_com_sun_kvem_midp_pim_formats_EndMatcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
};

struct Java_com_sun_kvem_midp_pim_formats_VCardFormat {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCardFormat */
};

struct Java_com_sun_kvem_midp_pim_formats_VCard30Format {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCardFormat */
    /* com/sun/kvem/midp/pim/formats/VCard30Format */
};

struct Java_javax_microedition_pim_ContactList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/ContactList */
};

struct Java_com_sun_kvem_midp_pim_ContactListImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad99;
    /* @26 */	jbyte ___pad100;
    /* @27 */	jbyte ___pad101;
    /* com/sun/kvem/midp/pim/ContactListImpl */
};

struct Java_com_sun_kvem_midp_pim_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/Event */
};

struct Java_javax_microedition_pim_RepeatRule {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/RepeatRule */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST fields;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST exceptions;
};

struct Java_javax_microedition_pim_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/Event */
};

struct Java_com_sun_kvem_midp_pim_EventImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @28 */	jint type;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad102;
    /* @38 */	jbyte ___pad103;
    /* @39 */	jbyte ___pad104;
    /* com/sun/kvem/midp/pim/EventImpl */
    /* @40 */	struct Java_javax_microedition_pim_RepeatRule * JVM_FIELD_CONST repeatRule;
};

struct Java_javax_microedition_pim_ToDo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/ToDo */
};

struct Java_com_sun_kvem_midp_pim_ToDoImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMItem */
    /*  @4 */	jint_array * JVM_FIELD_CONST fieldKeys;
    /*  @8 */	jobject_array * JVM_FIELD_CONST fieldValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST categories;
    /* @16 */	struct Java_com_sun_kvem_midp_pim_AbstractPIMList * JVM_FIELD_CONST pimList;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST pimListHandle;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @28 */	jint type;
    /* @32 */	struct Java_com_sun_kvem_midp_pim_PIMHandler * JVM_FIELD_CONST pimHandler;
    /* @36 */	jboolean modified;
    /* @37 */	jbyte ___pad105;
    /* @38 */	jbyte ___pad106;
    /* @39 */	jbyte ___pad107;
    /* com/sun/kvem/midp/pim/ToDoImpl */
};

struct Java_com_sun_kvem_midp_pim_formats_VCalendar10Format {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCalendar10Format */
};

struct Java_javax_microedition_pim_FieldEmptyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/pim/FieldEmptyException */
    /* @12 */	jint offending_field;
};

struct Java_javax_microedition_pim_EventList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/EventList */
};

struct Java_com_sun_kvem_midp_pim_EventListImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad108;
    /* @26 */	jbyte ___pad109;
    /* @27 */	jbyte ___pad110;
    /* com/sun/kvem/midp/pim/EventListImpl */
};

struct Java_com_sun_kvem_midp_pim_KeySortUtility {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/KeySortUtility */
};

struct Java_com_sun_kvem_midp_pim_MarkableInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/kvem/midp/pim/MarkableInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_io_ByteArrayOutputStream * JVM_FIELD_CONST baos;
    /* @12 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* @16 */	jint bufferIndex;
};

struct Java_java_io_InputStreamReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* java/io/InputStreamReader */
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST in;
};

struct Java_com_sun_kvem_midp_pim_PIMBridge {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMHandler */
    /* com/sun/kvem/midp/pim/PIMBridge */
    /*  @4 */	jint YEAR;
    /*  @8 */	jint MONTH;
    /* @12 */	jint DAY_OF_MONTH;
    /* @16 */	jint HOUR;
    /* @20 */	jint MINUTE;
    /* @24 */	jint SECOND;
};

struct Java_com_sun_kvem_midp_pim_PIMBridge_0004List {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMBridge$List */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @12 */	struct Java_com_sun_kvem_midp_pim_PIMBridge * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_kvem_midp_pim_PIMFieldDescriptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMFieldDescriptor */
    /*  @4 */	jint field;
    /*  @8 */	jint dataType;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST defaultValue;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @20 */	jobject_array * JVM_FIELD_CONST labelResources;
    /* @24 */	jlong attributes;
    /* @32 */	jint maxValues;
    /* @36 */	jboolean hasDefaultValue;
    /* @37 */	jbyte ___pad111;
    /* @38 */	jbyte ___pad112;
    /* @39 */	jbyte ___pad113;
};

struct Java_com_sun_kvem_midp_pim_PIMDatabase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/PIMDatabase */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST dir;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST categoriesMap;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST fileSep;
    /* @16 */	jobject_array * JVM_FIELD_CONST LISTS;
};

struct Java_com_sun_midp_security_ImplicitlyTrustedClass {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/ImplicitlyTrustedClass */
};

struct Java_com_sun_midp_midlet_Scheduler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/Scheduler */
};

struct Java_com_sun_midp_midlet_MIDletSuite {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletSuite */
};

struct Java_javax_microedition_pim_PIM {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIM */
};

struct Java_com_sun_kvem_midp_pim_PIMImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/PIM */
    /* com/sun/kvem/midp/pim/PIMImpl */
};

struct Java_com_sun_kvem_midp_pim_UnsupportedPIMFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/kvem/midp/pim/UnsupportedPIMFormatException */
};

struct Java_javax_microedition_pim_ToDoList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pim/ToDoList */
};

struct Java_com_sun_kvem_midp_pim_ToDoListImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/AbstractPIMList */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST items;
    /* @12 */	jint mode;
    /* @16 */	jint type;
    /* @20 */	struct Java_java_lang_Object * JVM_FIELD_CONST handle;
    /* @24 */	jboolean open;
    /* @25 */	jbyte ___pad114;
    /* @26 */	jbyte ___pad115;
    /* @27 */	jbyte ___pad116;
    /* com/sun/kvem/midp/pim/ToDoListImpl */
};

struct Java_com_sun_kvem_midp_pim_SupportedPIMFields {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/SupportedPIMFields */
};

struct Java_com_sun_kvem_midp_pim_ToDo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/ToDo */
};

struct Java_com_sun_kvem_midp_pim_formats_Base64Encoding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/Base64Encoding */
};

struct Java_com_sun_kvem_midp_pim_formats_Extensions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/Extensions */
};

struct Java_com_sun_kvem_midp_pim_formats_FormatSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/FormatSupport */
};

struct Java_com_sun_kvem_midp_pim_formats_QuotedPrintableEncoding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/QuotedPrintableEncoding */
};

struct Java_java_io_OutputStreamWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Writer */
    /*  @4 */	jchar_array * JVM_FIELD_CONST writeBuffer;
    /*  @8 */	jint writeBufferSize;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /* java/io/OutputStreamWriter */
    /* @16 */	struct Java_java_io_Writer * JVM_FIELD_CONST out;
};

struct Java_com_sun_kvem_midp_pim_formats_VCard21Format {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/EndMatcher */
    /*  @4 */	jchar_array * JVM_FIELD_CONST parameter;
    /*  @8 */	jchar_array * JVM_FIELD_CONST parameter2;
    /* com/sun/kvem/midp/pim/formats/VCardFormat */
    /* com/sun/kvem/midp/pim/formats/VCard21Format */
};

struct Java_com_sun_kvem_midp_pim_formats_VCardSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/VCardSupport */
};

struct Java_com_sun_kvem_midp_pim_formats_VEventSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/VEventSupport */
};

struct Java_com_sun_kvem_midp_pim_formats_VToDoSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/midp/pim/formats/VToDoSupport */
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteStorage */
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletSuiteImpl */
    /*  @4 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /*  @8 */	struct Java_com_sun_midp_security_SecurityHandler * JVM_FIELD_CONST securityHandler;
    /* @12 */	struct Java_com_sun_midp_midletsuite_SuiteProperties * JVM_FIELD_CONST suiteProperties;
    /* @16 */	struct Java_com_sun_midp_midletsuite_SuiteSettings * JVM_FIELD_CONST suiteSettings;
    /* @20 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet_1_name;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet_1_class;
    /* @36 */	jint numberOfMidlets;
    /* @40 */	jboolean locked;
    /* @41 */	jbyte ___pad117;
    /* @42 */	jbyte ___pad118;
    /* @43 */	jbyte ___pad119;
};

struct Java_javax_microedition_lcdui_Image {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Image */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	struct Java_javax_microedition_lcdui_ImageData * JVM_FIELD_CONST imageData;
};

struct Java_javax_microedition_lcdui_Item {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
};

struct Java_com_sun_midp_midletsuite_InstallInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/InstallInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST jadUrl;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST jarUrl;
    /* @12 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @20 */	jbyte_array * JVM_FIELD_CONST verifyHash;
    /* @24 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST midletSuite;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @32 */	jboolean trusted;
    /* @33 */	jbyte ___pad120;
    /* @34 */	jbyte ___pad121;
    /* @35 */	jbyte ___pad122;
};

struct Java_com_sun_midp_midlet_MIDletStateHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletStateHandler */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /*  @8 */	jobject_array * JVM_FIELD_CONST midlets;
    /* @12 */	jint nmidlets;
    /* @16 */	jint scanIndex;
    /* @20 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /* @24 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /* @28 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
};

struct Java_javax_microedition_lcdui_Screen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad123;
    /* @30 */	jbyte ___pad124;
    /* @31 */	jbyte ___pad125;
    /* javax/microedition/lcdui/Screen */
};

struct Java_javax_microedition_lcdui_LFFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFFactory */
};

struct Java_javax_microedition_lcdui_Form {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad126;
    /* @30 */	jbyte ___pad127;
    /* @31 */	jbyte ___pad128;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
};

struct Java_javax_microedition_lcdui_FormLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/FormLF */
};

struct Java_javax_microedition_lcdui_DisplayableLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLF */
};

struct Java_javax_microedition_lcdui_ItemStateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemStateListener */
};

struct Java_javax_microedition_lcdui_Ticker {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Ticker */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST message;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayedMessage;
    /* @12 */	struct Java_javax_microedition_lcdui_TickerLF * JVM_FIELD_CONST tickerLF;
};

struct Java_javax_microedition_lcdui_Command {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Command */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST shortLabel;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST longLabel;
    /* @12 */	jint commandType;
    /* @16 */	jint priority;
    /* @20 */	jint id;
};

struct Java_javax_microedition_lcdui_CommandListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CommandListener */
};

struct Java_javax_microedition_lcdui_Displayable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad129;
    /* @30 */	jbyte ___pad130;
    /* @31 */	jbyte ___pad131;
};

struct Java_com_sun_midp_appmanager_ApplicationManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/ApplicationManager */
};

struct Java_com_sun_midp_appmanager_AppInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad132;
    /* @30 */	jbyte ___pad133;
    /* @31 */	jbyte ___pad134;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppInfo */
    /* @48 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST suiteIcon;
    /* @52 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST singleSuiteIcon;
    /* @56 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @60 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @64 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @68 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @72 */	jint numberOfMidlets;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteCorruptedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/midletsuite/MIDletSuiteCorruptedException */
};

struct Java_javax_microedition_lcdui_ImageItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/ImageItem */
    /* @44 */	struct Java_javax_microedition_lcdui_ImageItemLF * JVM_FIELD_CONST imageItemLF;
    /* @48 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST immutableImg;
    /* @52 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImg;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST altText;
    /* @60 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_ImageItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageItemLF */
};

struct Java_javax_microedition_lcdui_ItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLF */
};

struct Java_javax_microedition_lcdui_ItemCommandListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemCommandListener */
};

struct Java_javax_microedition_lcdui_StringItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/StringItem */
    /* @44 */	struct Java_javax_microedition_lcdui_StringItemLF * JVM_FIELD_CONST stringItemLF;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST str;
    /* @52 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @56 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_StringItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/StringItemLF */
};

struct Java_javax_microedition_lcdui_Font {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Font */
    /*  @4 */	jint face;
    /*  @8 */	jint style;
    /* @12 */	jint size;
    /* @16 */	jint baseline;
    /* @20 */	jint height;
};

struct Java_com_sun_midp_appmanager_AppManagerUI {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad135;
    /* @30 */	jbyte ___pad136;
    /* @31 */	jbyte ___pad137;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppManagerUI */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchInstallCmd;
    /* @56 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCaManagerCmd;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST infoCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST updateCmd;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST appSettingsCmd;
    /* @80 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @84 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeOkCmd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @92 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST fgCmd;
    /* @96 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @100 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @104 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @108 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @112 */	jlong lastDisplayChange;
    /* @120 */	struct Java_com_sun_midp_appmanager_MIDletSuiteInfo * JVM_FIELD_CONST removeMsi;
    /* @124 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST appManagerMidlet;
    /* @128 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @132 */	jboolean caManagerIncluded;
    /* @133 */	jbyte ___pad138;
    /* @134 */	jbyte ___pad139;
    /* @135 */	jbyte ___pad140;
};

struct Java_com_sun_midp_main_MIDletProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxy */
    /*  @4 */	jint externalId;
    /*  @8 */	jint isolateId;
    /* @12 */	jint displayId;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @28 */	jint midletState;
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST preempting;
    /* @36 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST preempted;
    /* @40 */	struct Java_java_util_Timer * JVM_FIELD_CONST proxyTimer;
    /* @44 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST parent;
    /* @48 */	jboolean wantsForegroundState;
    /* @49 */	jboolean alertWaiting;
    /* @50 */	jbyte ___pad141;
    /* @51 */	jbyte ___pad142;
};

struct Java_com_sun_midp_appmanager_MIDletSuiteInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSuiteInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @24 */	jboolean singleMidlet;
    /* @25 */	jboolean enabled;
    /* @26 */	jbyte ___pad143;
    /* @27 */	jbyte ___pad144;
};

struct Java_com_sun_midp_appmanager_AppManagerUI_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSuiteInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletToRun;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST proxy;
    /* @24 */	jboolean singleMidlet;
    /* @25 */	jboolean enabled;
    /* @26 */	jbyte ___pad145;
    /* @27 */	jbyte ___pad146;
    /* com/sun/midp/appmanager/AppManagerUI$1 */
    /* @28 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_CustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
};

struct Java_javax_microedition_lcdui_CustomItemLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CustomItemLF */
};

struct Java_javax_microedition_lcdui_Graphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Graphics */
    /*  @4 */	jint transX;
    /*  @8 */	jint transY;
    /* @12 */	jint ax;
    /* @16 */	jint ay;
    /* @20 */	jint rgbColor;
    /* @24 */	jint gray;
    /* @28 */	jint pixel;
    /* @32 */	jint style;
    /* @36 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST currentFont;
    /* @40 */	jint displayId;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST img;
    /* @48 */	jshort clipX1;
    /* @50 */	jshort clipY1;
    /* @52 */	jshort clipX2;
    /* @54 */	jshort clipY2;
    /* @56 */	jshort systemClipX1;
    /* @58 */	jshort systemClipY1;
    /* @60 */	jshort systemClipX2;
    /* @62 */	jshort systemClipY2;
    /* @64 */	jshort maxWidth;
    /* @66 */	jshort maxHeight;
    /* @68 */	jboolean clipped;
    /* @69 */	jboolean runtimeClipEnforce;
    /* @70 */	jbyte ___pad147;
    /* @71 */	jbyte ___pad148;
};

struct Java_com_sun_midp_appmanager_AppManagerUI_0004MidletCustomItem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST __dup1__owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/CustomItem */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItemLF * JVM_FIELD_CONST customItemLF;
    /* com/sun/midp/appmanager/AppManagerUI$MidletCustomItem */
    /* @48 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST owner;
    /* @52 */	struct Java_com_sun_midp_appmanager_MIDletSuiteInfo * JVM_FIELD_CONST msi;
    /* @56 */	jint width;
    /* @60 */	jint height;
    /* @64 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @68 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST this_0440;
    /* @72 */	jboolean hasFocus;
    /* @73 */	jbyte ___pad149;
    /* @74 */	jbyte ___pad150;
    /* @75 */	jbyte ___pad151;
};

struct Java_javax_microedition_lcdui_Display {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display */
    /*  @4 */	jint displayId;
    /*  @8 */	struct Java_javax_microedition_lcdui_Display_0004DisplayAccessImpl * JVM_FIELD_CONST accessor;
    /* @12 */	struct Java_javax_microedition_lcdui_Display_0004DisplayEventConsumerImpl * JVM_FIELD_CONST consumer;
    /* @16 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST cham_tunnel;
    /* @20 */	jint_array * JVM_FIELD_CONST region;
    /* @24 */	struct Java_com_sun_midp_midlet_MIDletEventConsumer * JVM_FIELD_CONST midletEventConsumer;
    /* @28 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @32 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST screenGraphics;
    /* @36 */	jint wantsForeground;
    /* @40 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST current;
    /* @44 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST transitionCurrent;
    /* @48 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST pendingCurrent;
    /* @52 */	struct Java_com_sun_midp_chameleon_MIDPWindow * JVM_FIELD_CONST window;
    /* @56 */	struct Java_com_sun_midp_chameleon_CGraphicsQ * JVM_FIELD_CONST graphicsQ;
    /* @60 */	jboolean hasForeground;
    /* @61 */	jboolean paintSuspended;
    /* @62 */	jbyte ___pad152;
    /* @63 */	jbyte ___pad153;
};

struct Java_com_sun_midp_appmanager_DisplayError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/DisplayError */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
};

struct Java_javax_microedition_lcdui_AlertType {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AlertType */
    /*  @4 */	jint type;
};

struct Java_javax_microedition_lcdui_Alert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad154;
    /* @30 */	jbyte ___pad155;
    /* @31 */	jbyte ___pad156;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
};

struct Java_javax_microedition_rms_RecordStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordStore */
    /*  @4 */	struct Java_com_sun_midp_rms_RecordStoreImpl * JVM_FIELD_CONST peer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST recordStoreName;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteID;
    /* @16 */	jint opencount;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST recordListener;
};

struct Java_java_util_TimerTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
};

struct Java_java_util_Timer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Timer */
    /*  @4 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /*  @8 */	struct Java_java_util_TimerThread * JVM_FIELD_CONST thread;
};

struct Java_com_sun_midp_appmanager_SplashScreen {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad157;
    /* @30 */	jbyte ___pad158;
    /* @31 */	jbyte ___pad159;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad160;
    /* @38 */	jbyte ___pad161;
    /* @39 */	jbyte ___pad162;
    /* com/sun/midp/appmanager/SplashScreen */
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST splashScreen;
    /* @44 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @48 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @52 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST timerTask;
    /* @56 */	struct Java_java_util_Timer * JVM_FIELD_CONST timeoutTimer;
};

struct Java_javax_microedition_lcdui_Canvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad163;
    /* @30 */	jbyte ___pad164;
    /* @31 */	jbyte ___pad165;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad166;
    /* @38 */	jbyte ___pad167;
    /* @39 */	jbyte ___pad168;
};

struct Java_javax_microedition_lcdui_CanvasLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/CanvasLF */
};

struct Java_com_sun_midp_appmanager_RadioButtonSet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @48 */	jint choiceType;
    /* @52 */	jint fitPolicy;
    /* @56 */	jint numOfEls;
    /* @60 */	jobject_array * JVM_FIELD_CONST cgElements;
    /* com/sun/midp/appmanager/RadioButtonSet */
    /* @64 */	jint_array * JVM_FIELD_CONST ids;
};

struct Java_com_sun_midp_security_PermissionGroup {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionGroup */
    /*  @4 */	jint name;
    /*  @8 */	jint settingsQuestion;
    /* @12 */	jint disableSettingChoice;
    /* @16 */	jint runtimeDialogTitle;
    /* @20 */	jint runtimeQuestion;
    /* @24 */	jint runtimeOneshotQuestion;
    /* @28 */	jbyte identifiedMaxiumLevel;
    /* @29 */	jbyte identifiedDefaultLevel;
    /* @30 */	jbyte unidentifiedMaxiumLevel;
    /* @31 */	jbyte unidentifiedDefaultLevel;
};

struct Java_com_sun_midp_appmanager_AppSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad169;
    /* @30 */	jbyte ___pad170;
    /* @31 */	jbyte ___pad171;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/AppSettings */
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveAppSettingsCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @56 */	jint displayedSettingID;
    /* @60 */	jint lastPopupChoice;
    /* @64 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST initialSetting;
    /* @68 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST settingsPopup;
    /* @72 */	struct Java_com_sun_midp_appmanager_RadioButtonSet * JVM_FIELD_CONST interruptChoice;
    /* @76 */	jobject_array * JVM_FIELD_CONST groupSettings;
    /* @80 */	jint numberOfSettings;
    /* @84 */	jbyte_array * JVM_FIELD_CONST maxLevels;
    /* @88 */	jbyte_array * JVM_FIELD_CONST curLevels;
    /* @92 */	jint pushOptions;
    /* @96 */	jobject_array * JVM_FIELD_CONST groups;
    /* @100 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @104 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @108 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @112 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteDisplayName;
    /* @120 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST midletSuite;
    /* @124 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST installInfo;
    /* @128 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @132 */	jbyte pushInterruptSetting;
    /* @133 */	jbyte ___pad172;
    /* @134 */	jbyte ___pad173;
    /* @135 */	jbyte ___pad174;
};

struct Java_javax_microedition_rms_RecordStoreException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
};

struct Java_javax_microedition_lcdui_ChoiceGroup_0004CGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChoiceGroup$CGElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST stringEl;
    /*  @8 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST imageEl;
    /* @12 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImageEl;
    /* @16 */	struct Java_javax_microedition_lcdui_ImageData * JVM_FIELD_CONST imageDataEl;
    /* @20 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST fontEl;
    /* @24 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST this_0440;
    /* @28 */	jboolean selected;
    /* @29 */	jbyte ___pad175;
    /* @30 */	jbyte ___pad176;
    /* @31 */	jbyte ___pad177;
};

struct Java_javax_microedition_lcdui_ChoiceGroup {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/ChoiceGroup */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroupLF * JVM_FIELD_CONST choiceGroupLF;
    /* @48 */	jint choiceType;
    /* @52 */	jint fitPolicy;
    /* @56 */	jint numOfEls;
    /* @60 */	jobject_array * JVM_FIELD_CONST cgElements;
};

struct Java_javax_microedition_lcdui_ChoiceGroupLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChoiceGroupLF */
};

struct Java_javax_microedition_lcdui_Choice {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Choice */
};

struct Java_javax_microedition_lcdui_AlertLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AlertLF */
};

struct Java_javax_microedition_lcdui_Gauge {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/Gauge */
    /* @44 */	struct Java_javax_microedition_lcdui_GaugeLF * JVM_FIELD_CONST gaugeLF;
    /* @48 */	jint value;
    /* @52 */	jint maxValue;
    /* @56 */	jboolean interactive;
    /* @57 */	jbyte ___pad178;
    /* @58 */	jbyte ___pad179;
    /* @59 */	jbyte ___pad180;
};

struct Java_com_sun_midp_appmanager_Ca {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/Ca */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	jboolean enabled;
    /*  @9 */	jboolean willBeEnabled;
    /* @10 */	jbyte ___pad181;
    /* @11 */	jbyte ___pad182;
};

struct Java_com_sun_midp_appmanager_CaManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/CaManager */
};

struct Java_com_sun_midp_publickeystore_WebPublicKeyStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
    /* com/sun/midp/publickeystore/WebPublicKeyStore */
};

struct Java_com_sun_midp_publickeystore_PublicKeyInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST owner;
    /*  @8 */	jlong notBefore;
    /* @16 */	jlong notAfter;
    /* @24 */	jbyte_array * JVM_FIELD_CONST modulus;
    /* @28 */	jbyte_array * JVM_FIELD_CONST exponent;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @36 */	jboolean enabled;
    /* @37 */	jbyte ___pad183;
    /* @38 */	jbyte ___pad184;
    /* @39 */	jbyte ___pad185;
};

struct Java_com_sun_midp_appmanager_CaForm {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad186;
    /* @30 */	jbyte ___pad187;
    /* @31 */	jbyte ___pad188;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Form */
    /* @32 */	jobject_array * JVM_FIELD_CONST items;
    /* @36 */	jint numOfItems;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST formLF;
    /* @44 */	struct Java_javax_microedition_lcdui_ItemStateListener * JVM_FIELD_CONST itemStateListener;
    /* com/sun/midp/appmanager/CaForm */
    /* @48 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST suiteStorage;
    /* @52 */	struct Java_java_util_Vector * JVM_FIELD_CONST disableSuites;
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST enableSuites;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST confirmCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exitCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST caList;
    /* @80 */	struct Java_com_sun_midp_appmanager_CaManager * JVM_FIELD_CONST parent;
    /* @84 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @88 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST choices;
    /* @92 */	jint firstIndex;
};

struct Java_com_sun_midp_midletsuite_SuiteProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/SuiteProperties */
    /*  @4 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST properties;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
};

struct Java_com_sun_midp_midletsuite_SuiteSettings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/SuiteSettings */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
    /*  @8 */	jint pushOptions;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @16 */	jbyte pushInterruptSetting;
    /* @17 */	jboolean enabled;
    /* @18 */	jbyte ___pad189;
    /* @19 */	jbyte ___pad190;
};

struct Java_com_sun_midp_security_SecurityHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityHandler */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST permissions;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST permissionAsked;
    /* @12 */	jbyte_array * JVM_FIELD_CONST maxPermissionLevels;
    /* @16 */	jboolean trusted;
    /* @17 */	jbyte ___pad191;
    /* @18 */	jbyte ___pad192;
    /* @19 */	jbyte ___pad193;
};

struct Java_javax_microedition_midlet_MIDlet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
};

struct Java_com_sun_midp_midlet_MIDletPeer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletPeer */
    /*  @4 */	jint state;
    /*  @8 */	struct Java_com_sun_midp_lcdui_DisplayAccess * JVM_FIELD_CONST accessor;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	jint displayId;
    /* @20 */	struct Java_javax_microedition_midlet_MIDlet * JVM_FIELD_CONST midlet;
};

struct Java_com_sun_midp_midlet_MIDletTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletTunnel */
};

struct Java_com_sun_midp_midletsuite_MIDletInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midletsuite/MIDletInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST icon;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST classname;
};

struct Java_javax_microedition_lcdui_List {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad194;
    /* @30 */	jbyte ___pad195;
    /* @31 */	jbyte ___pad196;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/List */
    /* @32 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST selectCommand;
    /* @40 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST listLF;
};

struct Java_com_sun_midp_appmanager_MIDletSelector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/appmanager/MIDletSelector */
    /*  @4 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST mlist;
    /*  @8 */	struct Java_com_sun_midp_appmanager_MIDletSuiteInfo * JVM_FIELD_CONST suiteInfo;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST parentDisplayable;
    /* @20 */	struct Java_com_sun_midp_appmanager_ApplicationManager * JVM_FIELD_CONST manager;
    /* @24 */	jint mcount;
    /* @28 */	jobject_array * JVM_FIELD_CONST minfo;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @36 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST launchCmd;
    /* @40 */	jint selectedMidlet;
};

struct Java_com_sun_midp_midletsuite_MIDletSuiteLockedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/midletsuite/MIDletSuiteLockedException */
};

struct Java_com_sun_midp_main_MIDletProxyList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyList */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST midletProxies;
    /* @12 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST foregroundMidlet;
    /* @16 */	struct Java_com_sun_midp_main_DisplayController * JVM_FIELD_CONST displayController;
    /* @20 */	jboolean allPaused;
    /* @21 */	jbyte ___pad197;
    /* @22 */	jbyte ___pad198;
    /* @23 */	jbyte ___pad199;
};

struct Java_com_sun_midp_main_MIDletProxyListListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyListListener */
};

struct Java_com_sun_midp_main_DisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
};

struct Java_com_sun_midp_appmanager_MVMManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/MVMManager */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST appManagerUI;
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @20 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
};

struct Java_com_sun_midp_main_MVMDisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* com/sun/midp/main/MVMDisplayController */
    /* @12 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST foregroundSelector;
};

struct Java_com_sun_midp_appmanager_SMMManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/appmanager/SMMManager */
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @12 */	struct Java_com_sun_midp_appmanager_AppManagerUI * JVM_FIELD_CONST appManagerUI;
    /* @16 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
    /* @44 */	struct Java_com_sun_midp_appmanager_DisplayError * JVM_FIELD_CONST displayError;
    /* @48 */	jboolean allowMidletLaunch;
    /* @49 */	jbyte ___pad200;
    /* @50 */	jbyte ___pad201;
    /* @51 */	jbyte ___pad202;
};

struct Java_com_sun_midp_main_SMMDisplayController {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/DisplayController */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletCreated;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
    /* com/sun/midp/main/SMMDisplayController */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletSuiteId;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletClassName;
    /* @20 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST lastMidletInForeground;
};

struct Java_com_sun_midp_appmanager_SplashScreen_0004TimeoutTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/appmanager/SplashScreen$TimeoutTask */
    /* @28 */	struct Java_com_sun_midp_appmanager_SplashScreen * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_events_EventQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventQueue */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST eventQueueThread;
    /*  @8 */	struct Java_java_lang_Thread * JVM_FIELD_CONST eventMonitorThread;
    /* @12 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST nextEvent;
    /* @16 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST lastEvent;
    /* @20 */	jobject_array * JVM_FIELD_CONST dispatchTable;
    /* @24 */	jint numEvents;
    /* @28 */	struct Java_com_sun_midp_events_NativeEventPool * JVM_FIELD_CONST pool;
    /* @32 */	jint nativeEventQueueHandle;
    /* @36 */	jboolean alive;
    /* @37 */	jbyte ___pad203;
    /* @38 */	jbyte ___pad204;
    /* @39 */	jbyte ___pad205;
};

struct Java_com_sun_midp_main_MIDletControllerEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	jint amsIsolateId;
    /* @12 */	jint currentIsolateId;
    /* @16 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST startErrorEvent;
    /* @20 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletCreatedEvent;
    /* @24 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletActiveEvent;
    /* @28 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletPausedEvent;
    /* @32 */	struct Java_com_sun_midp_events_NativeEvent * JVM_FIELD_CONST midletDestroyedEvent;
};

struct Java_com_sun_midp_automation_AutomationInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/automation/AutomationInitializer */
};

struct Java_java_lang_IllegalStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalStateException */
};

struct Java_com_sun_midp_chameleon_CGraphicsQ {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CGraphicsQ */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST refreshQ;
};

struct Java_com_sun_midp_chameleon_CGraphicsUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CGraphicsUtil */
};

struct Java_com_sun_midp_chameleon_CWindow {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CWindow */
    /*  @4 */	jint_array * JVM_FIELD_CONST bounds;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST layers;
    /* @12 */	jint bgColor;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST bgImage;
    /* @20 */	jint cX;
    /* @24 */	jint cY;
    /* @28 */	jint cW;
    /* @32 */	jint cH;
    /* @36 */	jint tranX;
    /* @40 */	jint tranY;
    /* @44 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @48 */	jint color;
    /* @52 */	jboolean dirty;
    /* @53 */	jbyte ___pad206;
    /* @54 */	jbyte ___pad207;
    /* @55 */	jbyte ___pad208;
};

struct Java_com_sun_midp_chameleon_CLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad209;
    /* @43 */	jbyte ___pad210;
};

struct Java_com_sun_midp_chameleon_ChamDisplayTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/ChamDisplayTunnel */
};

struct Java_com_sun_midp_chameleon_layers_BodyLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad211;
    /* @43 */	jbyte ___pad212;
    /* com/sun/midp/chameleon/layers/BodyLayer */
    /* @44 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
};

struct Java_com_sun_midp_chameleon_layers_TitleLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad213;
    /* @43 */	jbyte ___pad214;
    /* com/sun/midp/chameleon/layers/TitleLayer */
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @48 */	jint titlex;
    /* @52 */	jint titley;
    /* @56 */	jint titlew;
    /* @60 */	jint titleh;
};

struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad215;
    /* @43 */	jbyte ___pad216;
    /* com/sun/midp/chameleon/layers/ScrollIndLayer */
    /* @44 */	jboolean upViz;
    /* @45 */	jboolean downViz;
    /* @46 */	jboolean alertMode;
    /* @47 */	jbyte ___pad217;
};

struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad218;
    /* @43 */	jbyte ___pad219;
    /* com/sun/midp/chameleon/layers/SoftButtonLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST labels;
    /* @48 */	jobject_array * JVM_FIELD_CONST scrCmds;
    /* @52 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST scrListener;
    /* @56 */	jobject_array * JVM_FIELD_CONST itmCmds;
    /* @60 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST itemListener;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST soft1;
    /* @68 */	jobject_array * JVM_FIELD_CONST soft2;
    /* @72 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST subMenu;
    /* @76 */	struct Java_com_sun_midp_chameleon_layers_MenuLayer * JVM_FIELD_CONST menuLayer;
    /* @80 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* @84 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST swap;
    /* @92 */	jint typeX;
    /* @96 */	jint typeY;
    /* @100 */	jint buttonx;
    /* @104 */	jint buttony;
    /* @108 */	jint buttonw;
    /* @112 */	jint buttonh;
    /* @116 */	jboolean menuUP;
    /* @117 */	jboolean alertUP;
    /* @118 */	jbyte ___pad220;
    /* @119 */	jbyte ___pad221;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad222;
    /* @43 */	jbyte ___pad223;
    /* com/sun/midp/chameleon/layers/TickerLayer */
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @48 */	jint textLoc;
    /* @52 */	jint textLen;
    /* @56 */	struct Java_java_util_Timer * JVM_FIELD_CONST tickerTimer;
    /* @60 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer_0004TickerPainter * JVM_FIELD_CONST tickerPainter;
};

struct Java_com_sun_midp_chameleon_layers_WashLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad224;
    /* @43 */	jbyte ___pad225;
    /* com/sun/midp/chameleon/layers/WashLayer */
};

struct Java_com_sun_midp_chameleon_layers_AlertLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad226;
    /* @43 */	jbyte ___pad227;
    /* com/sun/midp/chameleon/layers/BodyLayer */
    /* @44 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* com/sun/midp/chameleon/layers/AlertLayer */
    /* @48 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
};

struct Java_com_sun_midp_chameleon_layers_PTILayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad228;
    /* @43 */	jbyte ___pad229;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/PTILayer */
    /* @52 */	jobject_array * JVM_FIELD_CONST list;
    /* @56 */	jint selId;
    /* @60 */	struct Java_com_sun_midp_chameleon_input_TextInputSession * JVM_FIELD_CONST iSession;
    /* @64 */	jint widthMax;
};

struct Java_com_sun_midp_chameleon_layers_PopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad230;
    /* @43 */	jbyte ___pad231;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_chameleon_MIDPWindow {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CWindow */
    /*  @4 */	jint_array * JVM_FIELD_CONST bounds;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST layers;
    /* @12 */	jint bgColor;
    /* @16 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST bgImage;
    /* @20 */	jint cX;
    /* @24 */	jint cY;
    /* @28 */	jint cW;
    /* @32 */	jint cH;
    /* @36 */	jint tranX;
    /* @40 */	jint tranY;
    /* @44 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @48 */	jint color;
    /* @52 */	jboolean dirty;
    /* @53 */	jbyte ___pad232;
    /* @54 */	jbyte ___pad233;
    /* @55 */	jbyte ___pad234;
    /* com/sun/midp/chameleon/MIDPWindow */
    /* @56 */	struct Java_com_sun_midp_chameleon_ChamDisplayTunnel * JVM_FIELD_CONST tunnel;
    /* @60 */	jobject_array * JVM_FIELD_CONST scrCmdCache;
    /* @64 */	jint scrCmdCount;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST scrCmdListener;
    /* @72 */	jobject_array * JVM_FIELD_CONST itemCmdCache;
    /* @76 */	jint itemCmdCount;
    /* @80 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST itemCmdListener;
    /* @84 */	struct Java_com_sun_midp_chameleon_layers_BodyLayer * JVM_FIELD_CONST bodyLayer;
    /* @88 */	struct Java_com_sun_midp_chameleon_layers_PTILayer * JVM_FIELD_CONST ptiLayer;
    /* @92 */	struct Java_com_sun_midp_chameleon_layers_TitleLayer * JVM_FIELD_CONST titleLayer;
    /* @96 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer * JVM_FIELD_CONST tickerLayer;
    /* @100 */	struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer * JVM_FIELD_CONST btnLayer;
    /* @104 */	struct Java_com_sun_midp_chameleon_layers_AlertLayer * JVM_FIELD_CONST alertLayer;
    /* @108 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollLayer;
    /* @112 */	struct Java_com_sun_midp_chameleon_layers_WashLayer * JVM_FIELD_CONST washLayer;
    /* @116 */	jboolean hasFullScreen;
    /* @117 */	jboolean sizeChangedOccured;
    /* @118 */	jbyte ___pad235;
    /* @119 */	jbyte ___pad236;
};

struct Java_com_sun_midp_lcdui_TextCursor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextCursor */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jint index;
    /* @24 */	jint option;
    /* @28 */	jint preferredX;
    /* @32 */	jint yOffset;
    /* @36 */	jboolean visible;
    /* @37 */	jbyte ___pad237;
    /* @38 */	jbyte ___pad238;
    /* @39 */	jbyte ___pad239;
};

struct Java_com_sun_midp_chameleon_layers_MenuLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad240;
    /* @43 */	jbyte ___pad241;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/MenuLayer */
    /* @52 */	jobject_array * JVM_FIELD_CONST menuCmds;
    /* @56 */	jint selI;
    /* @60 */	jint scrollIndex;
    /* @64 */	struct Java_com_sun_midp_chameleon_layers_SoftButtonLayer * JVM_FIELD_CONST btnLayer;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
    /* @72 */	struct Java_com_sun_midp_chameleon_layers_CascadeMenuLayer * JVM_FIELD_CONST cascadeMenu;
    /* @76 */	jboolean cascadeMenuUp;
    /* @77 */	jbyte ___pad242;
    /* @78 */	jbyte ___pad243;
    /* @79 */	jbyte ___pad244;
};

struct Java_com_sun_midp_chameleon_SubMenuCommand {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Command */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST shortLabel;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST longLabel;
    /* @12 */	jint commandType;
    /* @16 */	jint priority;
    /* @20 */	jint id;
    /* com/sun/midp/chameleon/SubMenuCommand */
    /* @24 */	jobject_array * JVM_FIELD_CONST subCommands;
    /* @28 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer_0004TickerPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/chameleon/layers/TickerLayer$TickerPainter */
    /* @28 */	struct Java_com_sun_midp_chameleon_layers_TickerLayer * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_layers_TickerLayer_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/layers/TickerLayer$1 */
};

struct Java_com_sun_midp_chameleon_input_InputModeMediator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputModeMediator */
};

struct Java_com_sun_midp_chameleon_input_InputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/InputMode */
};

struct Java_com_sun_midp_chameleon_input_BasicInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad245;
};

struct Java_com_sun_midp_chameleon_input_AlphaNumericInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad246;
    /* com/sun/midp/chameleon/input/AlphaNumericInputMode */
    /* @32 */	jint capsModePointer;
};

struct Java_com_sun_midp_chameleon_input_TextInputComponent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/TextInputComponent */
};

struct Java_com_sun_midp_chameleon_input_TextInputSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/TextInputSession */
};

struct Java_com_sun_midp_chameleon_input_BasicTextInputSession {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicTextInputSession */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST currentMode;
    /*  @8 */	jobject_array * JVM_FIELD_CONST inputModeSet;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST previousScreen;
    /* @20 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST stickyMode;
    /* @24 */	struct Java_com_sun_midp_chameleon_input_TextInputComponent * JVM_FIELD_CONST textComponent;
};

struct Java_com_sun_midp_chameleon_input_KeyboardInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/KeyboardInputMode */
    /*  @4 */	jint lastKey;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
};

struct Java_com_sun_midp_chameleon_input_NumericInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/BasicInputMode */
    /*  @4 */	jint constraints;
    /*  @8 */	jint modifiers;
    /* @12 */	jint lastKey;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @20 */	jint clickCount;
    /* @24 */	jint pendingChar;
    /* @28 */	jboolean commitChar;
    /* @29 */	jboolean hasMoreMatches;
    /* @30 */	jboolean sessionIsLive;
    /* @31 */	jbyte ___pad247;
    /* com/sun/midp/chameleon/input/NumericInputMode */
    /* @32 */	jobject_array * JVM_FIELD_CONST numericKeyMap;
    /* @36 */	jobject_array * JVM_FIELD_CONST decimalKeyMap;
    /* @40 */	jobject_array * JVM_FIELD_CONST phoneNumericKeyMap;
    /* @44 */	jobject_array * JVM_FIELD_CONST anyKeyMap;
};

struct Java_com_sun_midp_chameleon_input_PTIterator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTIterator */
};

struct Java_com_sun_midp_chameleon_input_PTDictionary {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionary */
};

struct Java_com_sun_midp_chameleon_input_PTDictionaryFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionaryFactory */
};

struct Java_com_sun_midp_chameleon_input_PTDictionaryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTDictionaryImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST language;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_PTIterator * JVM_FIELD_CONST iterator;
};

struct Java_com_sun_midp_chameleon_input_PTIteratorImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PTIteratorImpl */
    /*  @4 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST buffer;
    /*  @8 */	jint selected;
    /* @12 */	jobject_array * JVM_FIELD_CONST keyMap;
    /* @16 */	jobject_array * JVM_FIELD_CONST list;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST states;
};

struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PredictiveTextInputMode */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST part;
    /* @12 */	struct Java_com_sun_midp_chameleon_input_PTIterator * JVM_FIELD_CONST iterator;
    /* @16 */	struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode_0004StringDiff * JVM_FIELD_CONST diff;
    /* @20 */	jint capsMode;
};

struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode_0004StringDiff {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/PredictiveTextInputMode$StringDiff */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST state;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_PredictiveTextInputMode * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$1 */
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad248;
    /* @30 */	jbyte ___pad249;
    /* @31 */	jbyte ___pad250;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad251;
    /* @38 */	jbyte ___pad252;
    /* @39 */	jbyte ___pad253;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable */
    /* @40 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @44 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @48 */	jint cc;
    /* @52 */	jint hmargin;
    /* @56 */	jint wmargin;
    /* @60 */	jint margin;
    /* @64 */	jint wx;
    /* @68 */	jint wy;
    /* @72 */	jint ww;
    /* @76 */	jint wh;
    /* @80 */	jint cols;
    /* @84 */	jint rows;
    /* @88 */	jint pos;
    /* @92 */	jint newpos;
    /* @96 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST font;
    /* @100 */	jint defaultSymbolCursorPos;
    /* @104 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST accept;
    /* @108 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST reject;
    /* @112 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode * JVM_FIELD_CONST this_0440;
    /* @116 */	jboolean firstTime;
    /* @117 */	jbyte ___pad254;
    /* @118 */	jbyte ___pad255;
    /* @119 */	jbyte ___pad256;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode */
    /*  @4 */	jint lastKey;
    /*  @8 */	struct Java_com_sun_midp_chameleon_input_InputModeMediator * JVM_FIELD_CONST mediator;
    /* @12 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable * JVM_FIELD_CONST st;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable_0004Accept {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable$Accept */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable_0004Reject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/input/SymbolInputMode$SymbolTable$Reject */
    /*  @4 */	struct Java_com_sun_midp_chameleon_input_SymbolInputMode_0004SymbolTable * JVM_FIELD_CONST this_0441;
};

struct Java_com_sun_midp_chameleon_layers_CascadeMenuLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad257;
    /* @43 */	jbyte ___pad258;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/CascadeMenuLayer */
    /* @52 */	jobject_array * JVM_FIELD_CONST menuCmds;
    /* @56 */	jint selI;
    /* @60 */	jint scrollIndex;
    /* @64 */	struct Java_com_sun_midp_chameleon_layers_MenuLayer * JVM_FIELD_CONST menuLayer;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_ScrollIndLayer * JVM_FIELD_CONST scrollInd;
};

struct Java_com_sun_midp_chameleon_layers_InputModeLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad259;
    /* @43 */	jbyte ___pad260;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* com/sun/midp/chameleon/layers/InputModeLayer */
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST mode;
    /* @56 */	jint stringWidth;
    /* @60 */	jint stringHeight;
    /* @64 */	jint_array * JVM_FIELD_CONST anchor;
};

struct Java_com_sun_midp_chameleon_skins_AlertSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/AlertSkin */
};

struct Java_com_sun_midp_chameleon_skins_BusyCursorSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/BusyCursorSkin */
};

struct Java_com_sun_midp_chameleon_skins_ChoiceGroupSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ChoiceGroupSkin */
};

struct Java_com_sun_midp_chameleon_skins_DateEditorSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/DateEditorSkin */
};

struct Java_com_sun_midp_chameleon_skins_DateFieldSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/DateFieldSkin */
};

struct Java_com_sun_midp_chameleon_skins_GaugeSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/GaugeSkin */
};

struct Java_com_sun_midp_chameleon_skins_ImageItemSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ImageItemSkin */
};

struct Java_com_sun_midp_chameleon_skins_MenuSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/MenuSkin */
};

struct Java_com_sun_midp_chameleon_skins_PTISkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/PTISkin */
};

struct Java_com_sun_midp_chameleon_skins_ProgressBarSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ProgressBarSkin */
};

struct Java_com_sun_midp_chameleon_skins_ScreenSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ScreenSkin */
};

struct Java_com_sun_midp_chameleon_skins_ScrollIndSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/ScrollIndSkin */
};

struct Java_com_sun_midp_chameleon_skins_SkinPropertiesIDs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/SkinPropertiesIDs */
};

struct Java_com_sun_midp_chameleon_skins_SoftButtonSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/SoftButtonSkin */
};

struct Java_com_sun_midp_chameleon_skins_StringItemSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/StringItemSkin */
};

struct Java_com_sun_midp_chameleon_skins_TextFieldSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TextFieldSkin */
};

struct Java_com_sun_midp_chameleon_skins_TickerSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TickerSkin */
};

struct Java_com_sun_midp_chameleon_skins_TitleSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/TitleSkin */
};

struct Java_com_sun_midp_chameleon_skins_UpdateBarSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/UpdateBarSkin */
};

struct Java_com_sun_midp_chameleon_skins_resources_AlertResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/AlertResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_BusyCursorResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/BusyCursorResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ChoiceGroupResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ChoiceGroupResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_DateEditorResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/DateEditorResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_DateFieldResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/DateFieldResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_FontResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/FontResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_GaugeResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/GaugeResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ImageItemResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ImageItemResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ImageTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ImageTunnel */
};

struct Java_com_sun_midp_chameleon_skins_resources_LoadedSkinProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/LoadedSkinProperties */
    /*  @4 */	jint_array * JVM_FIELD_CONST properties;
    /*  @8 */	jobject_array * JVM_FIELD_CONST stringValues;
    /* @12 */	jobject_array * JVM_FIELD_CONST imageValues;
    /* @16 */	jint_array * JVM_FIELD_CONST fontValues;
    /* @20 */	jint_array * JVM_FIELD_CONST intSeqValues;
};

struct Java_com_sun_midp_chameleon_skins_resources_LoadedSkinResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/LoadedSkinResources */
    /*  @4 */	jobject_array * JVM_FIELD_CONST fonts;
    /*  @8 */	jobject_array * JVM_FIELD_CONST images;
};

struct Java_com_sun_midp_chameleon_skins_resources_MenuResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/MenuResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_PTIResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/PTIResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ProgressBarResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ProgressBarResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_RomizedSkin {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/RomizedSkin */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScreenResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScreenResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_ScrollIndResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/ScrollIndResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_SkinResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SkinResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_SoftButtonResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/SoftButtonResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_StringItemResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/StringItemResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TextFieldResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TextFieldResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TickerResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TickerResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_TitleResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/TitleResources */
};

struct Java_com_sun_midp_chameleon_skins_resources_UpdateBarResources {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/skins/resources/UpdateBarResources */
};

struct Java_com_sun_midp_configurator_Constants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/configurator/Constants */
};

struct Java_com_sun_midp_content_CHManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/content/CHManager */
};

struct Java_com_sun_midp_installer_Installer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpConnection;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST httpInputStream;
    /* @12 */	struct Java_com_sun_midp_installer_Installer_0004InstallStateImpl * JVM_FIELD_CONST state;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
};

struct Java_com_sun_midp_installer_InstallState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallState */
};

struct Java_com_sun_midp_crypto_Cipher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
};

struct Java_com_sun_midp_crypto_Key {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Key */
};

struct Java_com_sun_midp_crypto_CryptoParameter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/CryptoParameter */
};

struct Java_com_sun_midp_crypto_AES {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/AES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_crypto_Padder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Padder */
};

struct Java_com_sun_midp_crypto_BlockCipherBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad261;
};

struct Java_com_sun_midp_crypto_AES_1ECB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad262;
    /* com/sun/midp/crypto/AES_ECB */
    /* @40 */	jint_array * JVM_FIELD_CONST SB0;
    /* @44 */	jint_array * JVM_FIELD_CONST SB1;
    /* @48 */	jint_array * JVM_FIELD_CONST SB2;
    /* @52 */	jint_array * JVM_FIELD_CONST SB3;
    /* @56 */	jint Nk;
    /* @60 */	jint Nr;
    /* @64 */	jint_array * JVM_FIELD_CONST W;
    /* @68 */	jbyte_array * JVM_FIELD_CONST state;
};

struct Java_com_sun_midp_crypto_AES_1CBC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad263;
    /* com/sun/midp/crypto/AES_ECB */
    /* @40 */	jint_array * JVM_FIELD_CONST SB0;
    /* @44 */	jint_array * JVM_FIELD_CONST SB1;
    /* @48 */	jint_array * JVM_FIELD_CONST SB2;
    /* @52 */	jint_array * JVM_FIELD_CONST SB3;
    /* @56 */	jint Nk;
    /* @60 */	jint Nr;
    /* @64 */	jint_array * JVM_FIELD_CONST W;
    /* @68 */	jbyte_array * JVM_FIELD_CONST state;
    /* com/sun/midp/crypto/AES_CBC */
    /* @72 */	jbyte_array * JVM_FIELD_CONST scratchPad;
    /* @76 */	jbyte_array * JVM_FIELD_CONST savedState;
};

struct Java_com_sun_midp_crypto_InvalidKeyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidKeyException */
};

struct Java_com_sun_midp_crypto_SecretKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecretKey */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST alg;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST secret;
};

struct Java_com_sun_midp_crypto_ARC4 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/ARC4 */
    /*  @4 */	jint mode;
    /*  @8 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST ckey;
    /* @12 */	jbyte_array * JVM_FIELD_CONST S;
    /* @16 */	jint_array * JVM_FIELD_CONST ii;
    /* @20 */	jint_array * JVM_FIELD_CONST jj;
};

struct Java_com_sun_midp_crypto_NoSuchPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/NoSuchPaddingException */
};

struct Java_com_sun_midp_crypto_ShortBufferException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/ShortBufferException */
};

struct Java_com_sun_midp_crypto_BadPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/BadPaddingException */
};

struct Java_com_sun_midp_crypto_PKCS5Padding {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PKCS5Padding */
    /*  @4 */	jint blockSize;
};

struct Java_com_sun_midp_crypto_InvalidAlgorithmParameterException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidAlgorithmParameterException */
};

struct Java_com_sun_midp_crypto_IllegalBlockSizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/IllegalBlockSizeException */
};

struct Java_com_sun_midp_crypto_NoSuchAlgorithmException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/NoSuchAlgorithmException */
};

struct Java_com_sun_midp_crypto_DES {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/DES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_crypto_DES_1ECB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad264;
    /* com/sun/midp/crypto/DES_ECB */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST keyAlgorithm;
    /* @44 */	jobject_array * JVM_FIELD_CONST dkey;
    /* @48 */	jboolean tripleDes;
    /* @49 */	jbyte ___pad265;
    /* @50 */	jbyte ___pad266;
    /* @51 */	jbyte ___pad267;
};

struct Java_com_sun_midp_crypto_DES_1CBC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/BlockCipherBase */
    /*  @4 */	jint blockSize;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_com_sun_midp_crypto_Padder * JVM_FIELD_CONST padder;
    /* @16 */	jbyte_array * JVM_FIELD_CONST holdData;
    /* @20 */	jint holdCount;
    /* @24 */	jbyte_array * JVM_FIELD_CONST savedHoldData;
    /* @28 */	jint savedHoldCount;
    /* @32 */	jbyte_array * JVM_FIELD_CONST IV;
    /* @36 */	jboolean isUpdated;
    /* @37 */	jboolean savedIsUpdated;
    /* @38 */	jboolean keepLastBlock;
    /* @39 */	jbyte ___pad268;
    /* com/sun/midp/crypto/DES_ECB */
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST keyAlgorithm;
    /* @44 */	jobject_array * JVM_FIELD_CONST dkey;
    /* @48 */	jboolean tripleDes;
    /* @49 */	jbyte ___pad269;
    /* @50 */	jbyte ___pad270;
    /* @51 */	jbyte ___pad271;
    /* com/sun/midp/crypto/DES_CBC */
    /* @52 */	jbyte_array * JVM_FIELD_CONST chainingBlock;
    /* @56 */	jbyte_array * JVM_FIELD_CONST storeBuffer;
    /* @60 */	jbyte_array * JVM_FIELD_CONST savedChainingBlock;
};

struct Java_com_sun_midp_crypto_DESEDE {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/DES */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
    /* com/sun/midp/crypto/DESEDE */
};

struct Java_com_sun_midp_crypto_InvalidKeySpecException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/InvalidKeySpecException */
};

struct Java_com_sun_midp_crypto_IvParameter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/IvParameter */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST IV;
};

struct Java_com_sun_midp_crypto_MD2 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/MD2 */
    /*  @4 */	jint_array * JVM_FIELD_CONST num;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint_array * JVM_FIELD_CONST cksm;
    /* @16 */	jint_array * JVM_FIELD_CONST state;
};

struct Java_com_sun_midp_crypto_MD5 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/MD5 */
    /*  @4 */	jint_array * JVM_FIELD_CONST state;
    /*  @8 */	jint_array * JVM_FIELD_CONST num;
    /* @12 */	jint_array * JVM_FIELD_CONST count;
    /* @16 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_midp_crypto_SHA {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/MessageDigest */
    /* com/sun/midp/crypto/SHA */
    /*  @4 */	jint_array * JVM_FIELD_CONST state;
    /*  @8 */	jint_array * JVM_FIELD_CONST num;
    /* @12 */	jint_array * JVM_FIELD_CONST count;
    /* @16 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_midp_crypto_SecureRandom {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecureRandom */
};

struct Java_com_sun_midp_crypto_PRand {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/SecureRandom */
    /* com/sun/midp/crypto/PRand */
};

struct Java_com_sun_midp_crypto_PrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PrivateKey */
};

struct Java_com_sun_midp_crypto_PublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/PublicKey */
};

struct Java_com_sun_midp_crypto_RSAKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
};

struct Java_com_sun_midp_crypto_RSA {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Cipher */
    /* com/sun/midp/crypto/RSA */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSAKey * JVM_FIELD_CONST ckey;
    /*  @8 */	jint mode;
    /* @12 */	jbyte_array * JVM_FIELD_CONST messageToSign;
    /* @16 */	jint bytesInMessage;
};

struct Java_com_sun_midp_crypto_RSAPrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
    /* com/sun/midp/crypto/RSAPrivateKey */
};

struct Java_com_sun_midp_crypto_RSAPublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSAKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST exp;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST mod;
    /* com/sun/midp/crypto/RSAPublicKey */
};

struct Java_com_sun_midp_crypto_RSASig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/RSASig */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST alg;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md;
    /* @12 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST c;
    /* @16 */	struct Java_com_sun_midp_crypto_RSAKey * JVM_FIELD_CONST k;
    /* @20 */	jbyte_array * JVM_FIELD_CONST prefix;
};

struct Java_com_sun_midp_crypto_SignatureException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* com/sun/midp/crypto/GeneralSecurityException */
    /* com/sun/midp/crypto/SignatureException */
};

struct Java_com_sun_midp_crypto_Signature {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
};

struct Java_com_sun_midp_crypto_RsaMd5Sig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
    /* com/sun/midp/crypto/RsaMd5Sig */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSASig * JVM_FIELD_CONST rsaSig;
};

struct Java_com_sun_midp_crypto_RsaShaSig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Signature */
    /* com/sun/midp/crypto/RsaShaSig */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSASig * JVM_FIELD_CONST rsaSig;
};

struct Java_com_sun_midp_crypto_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/crypto/Util */
};

struct Java_com_sun_midp_events_EventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventListener */
};

struct Java_com_sun_midp_events_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
};

struct Java_com_sun_midp_events_DispatchData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/DispatchData */
    /*  @4 */	struct Java_com_sun_midp_events_EventListener * JVM_FIELD_CONST listener;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST waitingEvent;
};

struct Java_com_sun_midp_events_NativeEventPool {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/NativeEventPool */
    /*  @4 */	jobject_array * JVM_FIELD_CONST eventStack;
    /*  @8 */	jint eventsInPool;
};

struct Java_com_sun_midp_events_NativeEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/events/NativeEvent */
    /* @12 */	jint intParam1;
    /* @16 */	jint intParam2;
    /* @20 */	jint intParam3;
    /* @24 */	jint intParam4;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam1;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam2;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam3;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam4;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam5;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST stringParam6;
};

struct Java_com_sun_midp_events_NativeEventMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/NativeEventMonitor */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST eventQueueLock;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /* @12 */	struct Java_com_sun_midp_events_NativeEventPool * JVM_FIELD_CONST pool;
};

struct Java_com_sun_midp_events_EventTypes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/EventTypes */
};

struct Java_com_sun_midp_i18n_ResourceBundle {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/ResourceBundle */
};

struct Java_com_sun_midp_i18n_Resource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/Resource */
};

struct Java_com_sun_midp_l10n_LocalizedStringsBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBase */
};

struct Java_com_sun_midp_l10n_LocalizedStrings {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/l10n/LocalizedStringsBase */
    /* com/sun/midp/l10n/LocalizedStrings */
};

struct Java_com_sun_midp_i18n_ResourceConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/i18n/ResourceConstants */
};

struct Java_com_sun_midp_installer_InstallListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallListener */
};

struct Java_com_sun_midp_installer_AutoTesterInterface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterInterface */
};

struct Java_javax_microedition_lcdui_TextField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/TextField */
    /* @44 */	struct Java_javax_microedition_lcdui_TextFieldLF * JVM_FIELD_CONST textFieldLF;
    /* @48 */	struct Java_com_sun_midp_lcdui_DynamicCharacterArray * JVM_FIELD_CONST buffer;
    /* @52 */	jint constraints;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
};

struct Java_com_sun_midp_installer_InvalidJadException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/midp/installer/InvalidJadException */
    /* @12 */	jint reason;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST extraData;
};

struct Java_com_sun_midp_installer_AutoTesterBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
};

struct Java_com_sun_midp_installer_AutoTester {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
    /* com/sun/midp/installer/AutoTester */
};

struct Java_com_sun_midp_lcdui_DynamicCharacterArray {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DynamicCharacterArray */
    /*  @4 */	jchar_array * JVM_FIELD_CONST buffer;
    /*  @8 */	jint length;
};

struct Java_javax_microedition_lcdui_TextFieldLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldLF */
};

struct Java_com_sun_midp_installer_AutoTesterMulti_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterMulti$1 */
};

struct Java_com_sun_midp_installer_AutoTesterMulti {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/AutoTesterBase */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST parameterForm;
    /* @16 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST urlTextField;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST domainTextField;
    /* @24 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
    /* @28 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST testCmd;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @40 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @44 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @48 */	jint loopCount;
    /* @52 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST installListener;
    /* com/sun/midp/installer/AutoTesterMulti */
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST installList;
};

struct Java_com_sun_midp_installer_AutoTesterMulti_0004AutoTesterRunner {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/AutoTesterMulti$AutoTesterRunner */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST storage;
    /* @12 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @16 */	struct Java_com_sun_midp_installer_AutoTesterMulti * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_DiscoveryApp_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DiscoveryApp$1 */
};

struct Java_com_sun_midp_installer_DiscoveryApp {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/DiscoveryApp */
    /*  @8 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultInstallListUrl;
    /* @16 */	struct Java_javax_microedition_lcdui_TextBox * JVM_FIELD_CONST urlTextBox;
    /* @20 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @24 */	jint progressGaugeIndex;
    /* @28 */	jint progressUrlIndex;
    /* @32 */	jlong lastDisplayChange;
    /* @40 */	struct Java_javax_microedition_lcdui_List * JVM_FIELD_CONST installListBox;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST installList;
    /* @48 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST discoverCmd;
    /* @52 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST installCmd;
    /* @56 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST backCmd;
    /* @60 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST saveCmd;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST endCmd;
};

struct Java_javax_microedition_lcdui_TextBox {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad272;
    /* @30 */	jbyte ___pad273;
    /* @31 */	jbyte ___pad274;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/TextBox */
    /* @32 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST textField;
    /* @36 */	struct Java_javax_microedition_lcdui_FormLF * JVM_FIELD_CONST textBoxLF;
};

struct Java_com_sun_midp_installer_DiscoveryApp_0004BackgroundInstallListGetter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/DiscoveryApp$BackgroundInstallListGetter */
    /*  @4 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_com_sun_midp_installer_DiscoveryApp * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_GaugeLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/GaugeLF */
};

struct Java_com_sun_midp_installer_GraphicalInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/installer/GraphicalInstaller */
    /*  @8 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST installer;
    /* @12 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST display;
    /* @16 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST passwordForm;
    /* @20 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST usernameField;
    /* @24 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST passwordField;
    /* @28 */	struct Java_com_sun_midp_installer_GraphicalInstaller_0004BackgroundInstaller * JVM_FIELD_CONST backgroundInstaller;
    /* @32 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST progressForm;
    /* @36 */	jint progressGaugeIndex;
    /* @40 */	jint progressUrlIndex;
    /* @44 */	jlong lastDisplayChange;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST cancelledMessage;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST finishingMessage;
    /* @60 */	struct Java_com_sun_midp_content_CHManager * JVM_FIELD_CONST chmanager;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST stopCmd;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @72 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST continueCmd;
    /* @76 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST nextCmd;
    /* @80 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @84 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST exceptionCmd;
    /* @88 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST keepRMSCmd;
    /* @92 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST removeRMSCmd;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$1 */
    /*  @4 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_installer_GraphicalInstaller_0004BackgroundInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/GraphicalInstaller$BackgroundInstaller */
    /*  @4 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST parent;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST successMessage;
    /* @20 */	struct Java_com_sun_midp_installer_InstallState * JVM_FIELD_CONST installState;
    /* @24 */	struct Java_com_sun_midp_installer_GraphicalInstaller * JVM_FIELD_CONST this_0440;
    /* @28 */	jboolean update;
    /* @29 */	jboolean continueInstall;
    /* @30 */	jboolean jarOnly;
    /* @31 */	jboolean proxyAuth;
};

struct Java_com_sun_midp_installer_InstallRetryHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InstallRetryHandler */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST token;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST suite;
};

struct Java_com_sun_midp_installer_Installer_0004InstallStateImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer$InstallStateImpl */
    /*  @4 */	struct Java_com_sun_midp_installer_InstallListener * JVM_FIELD_CONST listener;
    /*  @8 */	jlong startTime;
    /* @16 */	jint nextStep;
    /* @20 */	struct Java_com_sun_midp_installer_InvalidJadException * JVM_FIELD_CONST exception;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST jadUrl;
    /* @28 */	jbyte_array * JVM_FIELD_CONST jad;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST jadEncoding;
    /* @36 */	struct Java_com_sun_midp_installer_JadProperties * JVM_FIELD_CONST jadProps;
    /* @40 */	struct Java_com_sun_midp_installer_ManifestProperties * JVM_FIELD_CONST jarProps;
    /* @44 */	struct Java_com_sun_midp_io_j2me_storage_File * JVM_FIELD_CONST file;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST username;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST password;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST proxyUsername;
    /* @60 */	struct Java_java_lang_String * JVM_FIELD_CONST proxyPassword;
    /* @64 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteName;
    /* @68 */	struct Java_java_lang_String * JVM_FIELD_CONST vendor;
    /* @72 */	struct Java_java_lang_String * JVM_FIELD_CONST version;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST description;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @84 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @88 */	jint expectedJarSize;
    /* @92 */	struct Java_java_lang_String * JVM_FIELD_CONST jarUrl;
    /* @96 */	jint beginTransferDataStatus;
    /* @100 */	jint transferStatus;
    /* @104 */	jint pushOptions;
    /* @108 */	jbyte_array * JVM_FIELD_CONST permissions;
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
    /* @116 */	struct Java_com_sun_midp_security_SecurityHandler * JVM_FIELD_CONST securityHandler;
    /* @120 */	jbyte_array * JVM_FIELD_CONST manifest;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST tempFilename;
    /* @128 */	struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream * JVM_FIELD_CONST storage;
    /* @132 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteStorage * JVM_FIELD_CONST midletSuiteStorage;
    /* @136 */	struct Java_java_lang_String * JVM_FIELD_CONST storageRoot;
    /* @140 */	struct Java_com_sun_midp_midletsuite_MIDletSuiteImpl * JVM_FIELD_CONST previousSuite;
    /* @144 */	struct Java_com_sun_midp_midletsuite_InstallInfo * JVM_FIELD_CONST previousInstallInfo;
    /* @148 */	struct Java_com_sun_midp_content_CHManager * JVM_FIELD_CONST chmanager;
    /* @152 */	jbyte_array * JVM_FIELD_CONST verifyHash;
    /* @156 */	struct Java_com_sun_midp_installer_Installer * JVM_FIELD_CONST this_0440;
    /* @160 */	jboolean stopInstallation;
    /* @161 */	jboolean ignoreCancel;
    /* @162 */	jboolean force;
    /* @163 */	jboolean removeRMS;
    /* @164 */	jbyte pushInterruptSetting;
    /* @165 */	jboolean trusted;
    /* @166 */	jboolean isPreviousVersion;
    /* @167 */	jbyte ___pad275;
};

struct Java_com_sun_midp_installer_JadProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
    /* com/sun/midp/installer/JadProperties */
    /* @16 */	jchar_array * JVM_FIELD_CONST lineBuffer;
};

struct Java_com_sun_midp_installer_ManifestProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
    /* com/sun/midp/installer/JadProperties */
    /* @16 */	jchar_array * JVM_FIELD_CONST lineBuffer;
    /* com/sun/midp/installer/ManifestProperties */
    /* @20 */	jint remainder;
};

struct Java_com_sun_midp_io_j2me_storage_File {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/storage/File */
};

struct Java_com_sun_midp_io_j2me_storage_RandomAccessStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad276;
    /* @22 */	jbyte ___pad277;
    /* @23 */	jbyte ___pad278;
    /* com/sun/midp/io/j2me/storage/RandomAccessStream */
    /* @24 */	jint handle;
};

struct Java_com_sun_midp_util_Properties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/Properties */
    /*  @4 */	jobject_array * JVM_FIELD_CONST initProps;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keys;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST vals;
};

struct Java_javax_microedition_io_ConnectionNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/microedition/io/ConnectionNotFoundException */
};

struct Java_com_sun_midp_installer_InternalMIDletSuiteImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/InternalMIDletSuiteImpl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @12 */	jbyte_array * JVM_FIELD_CONST permissions;
    /* @16 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST properties;
    /* @20 */	jint numberOfMidlets;
    /* @24 */	jboolean trusted;
    /* @25 */	jbyte ___pad279;
    /* @26 */	jbyte ___pad280;
    /* @27 */	jbyte ___pad281;
};

struct Java_com_sun_midp_installer_JarReader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/JarReader */
};

struct Java_com_sun_midp_installer_PendingNotification {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/PendingNotification */
    /*  @4 */	jint retries;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
};

struct Java_com_sun_midp_installer_OtaNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/OtaNotifier */
};

struct Java_com_sun_midp_io_HttpUrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/HttpUrl */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST scheme;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST authority;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST fragment;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @28 */	jint port;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST machine;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST domain;
};

struct Java_com_sun_midp_io_j2me_http_StreamConnectionPool {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/StreamConnectionPool */
    /*  @4 */	jlong m_connectionLingerTime;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST m_connections;
    /* @16 */	jint m_max_connections;
};

struct Java_com_sun_midp_io_j2me_http_StreamConnectionElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/http/StreamConnectionElement */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST m_protocol;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST m_host;
    /* @12 */	jint m_port;
    /* @16 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST m_stream;
    /* @20 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST m_data_input_stream;
    /* @24 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST m_data_output_stream;
    /* @28 */	jlong m_time;
    /* @36 */	jboolean m_in_use;
    /* @37 */	jboolean m_removed;
    /* @38 */	jbyte ___pad282;
    /* @39 */	jbyte ___pad283;
};

struct Java_com_sun_midp_io_ConnectionBaseAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad284;
    /* @22 */	jbyte ___pad285;
    /* @23 */	jbyte ___pad286;
};

struct Java_com_sun_midp_io_j2me_http_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad287;
    /* @22 */	jbyte ___pad288;
    /* @23 */	jbyte ___pad289;
    /* com/sun/midp/io/j2me/http/Protocol */
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /* @28 */	jint default_port;
    /* @32 */	struct Java_com_sun_midp_io_HttpUrl * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST hostAndPort;
    /* @40 */	jint responseCode;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST responseMsg;
    /* @48 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST reqProperties;
    /* @52 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST headerFields;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST method;
    /* @60 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST streamConnection;
    /* @64 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST streamOutput;
    /* @68 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST streamInput;
    /* @72 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST stringbuffer;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST httpVer;
    /* @80 */	jint contentLength;
    /* @84 */	jint chunksize;
    /* @88 */	jint totalbytesread;
    /* @92 */	jbyte_array * JVM_FIELD_CONST readbuf;
    /* @96 */	jint bytesleft;
    /* @100 */	jint bytesread;
    /* @104 */	jbyte_array * JVM_FIELD_CONST writebuf;
    /* @108 */	jint bytesToWrite;
    /* @112 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST proxyHeaders;
    /* @116 */	jboolean permissionChecked;
    /* @117 */	jboolean ownerTrusted;
    /* @118 */	jboolean ConnectionCloseFlag;
    /* @119 */	jboolean chunkedIn;
    /* @120 */	jboolean chunkedOut;
    /* @121 */	jboolean firstChunkSent;
    /* @122 */	jboolean sendingRequest;
    /* @123 */	jboolean requestFinished;
    /* @124 */	jboolean eof;
    /* @125 */	jbyte handshakeError;
    /* @126 */	jboolean readInProgress;
    /* @127 */	jbyte ___pad290;
};

struct Java_com_sun_midp_pki_X509Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/X509Certificate */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST fp;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST serialNumber;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST subject;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST issuer;
    /* @20 */	jlong from;
    /* @28 */	jlong until;
    /* @36 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST pubKey;
    /* @40 */	jint idx;
    /* @44 */	jbyte_array * JVM_FIELD_CONST enc;
    /* @48 */	jint TBSStart;
    /* @52 */	jint TBSLen;
    /* @56 */	jbyte_array * JVM_FIELD_CONST signature;
    /* @60 */	jbyte_array * JVM_FIELD_CONST TBSCertHash;
    /* @64 */	struct Java_java_lang_Object * JVM_FIELD_CONST subAltName;
    /* @68 */	jint pLenConstr;
    /* @72 */	jint keyUsage;
    /* @76 */	jint extKeyUsage;
    /* @80 */	jboolean selfSigned;
    /* @81 */	jbyte version;
    /* @82 */	jbyte sigAlg;
    /* @83 */	jboolean badExt;
    /* @84 */	jbyte subAltNameType;
    /* @85 */	jboolean hasBC;
    /* @86 */	jboolean isCA;
    /* @87 */	jbyte ___pad291;
};

struct Java_com_sun_midp_pki_CertStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/CertStore */
};

struct Java_javax_microedition_pki_Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pki/Certificate */
};

struct Java_com_sun_midp_installer_SecureInstaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/Installer */
    /*  @4 */	struct Java_javax_microedition_io_HttpConnection * JVM_FIELD_CONST httpConnection;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST httpInputStream;
    /* @12 */	struct Java_com_sun_midp_installer_Installer_0004InstallStateImpl * JVM_FIELD_CONST state;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST cldcConfig;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST supportedProfiles;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST unsignedSecurityDomain;
    /* com/sun/midp/installer/SecureInstaller */
    /* @28 */	jobject_array * JVM_FIELD_CONST authPath;
    /* @32 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST cpCert;
};

struct Java_javax_microedition_pki_CertificateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/microedition/pki/CertificateException */
    /* @12 */	struct Java_javax_microedition_pki_Certificate * JVM_FIELD_CONST cert;
    /* @16 */	jbyte reason;
    /* @17 */	jbyte ___pad292;
    /* @18 */	jbyte ___pad293;
    /* @19 */	jbyte ___pad294;
};

struct Java_com_sun_midp_publickeystore_InputStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
    /* com/sun/midp/publickeystore/InputStorage */
    /*  @4 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST in;
};

struct Java_com_sun_midp_publickeystore_PublicKeyStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
};

struct Java_com_sun_midp_installer_SuiteDownloadInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/installer/SuiteDownloadInfo */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
};

struct Java_com_sun_midp_io_Base64 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/Base64 */
};

struct Java_com_sun_midp_io_BaseInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/io/BaseInputStream */
    /*  @4 */	struct Java_com_sun_midp_io_ConnectionBaseAdapter * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @12 */	jbyte_array * JVM_FIELD_CONST markBuf;
    /* @16 */	jint markSize;
    /* @20 */	jint markPos;
    /* @24 */	jboolean isReadFromBuffer;
    /* @25 */	jbyte ___pad295;
    /* @26 */	jbyte ___pad296;
    /* @27 */	jbyte ___pad297;
};

struct Java_com_sun_midp_io_BaseOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/io/BaseOutputStream */
    /*  @4 */	struct Java_com_sun_midp_io_ConnectionBaseAdapter * JVM_FIELD_CONST parent;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
};

struct Java_com_sun_midp_io_BluetoothProtocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/BluetoothProtocol */
    /*  @4 */	jint protocol;
    /*  @8 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
};

struct Java_com_sun_midp_io_BufferedConnectionAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad298;
    /* @22 */	jbyte ___pad299;
    /* @23 */	jbyte ___pad300;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad301;
    /* @38 */	jbyte ___pad302;
    /* @39 */	jbyte ___pad303;
};

struct Java_com_sun_midp_io_NetworkConnectionBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad304;
    /* @22 */	jbyte ___pad305;
    /* @23 */	jbyte ___pad306;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad307;
    /* @38 */	jbyte ___pad308;
    /* @39 */	jbyte ___pad309;
    /* com/sun/midp/io/NetworkConnectionBase */
};

struct Java_com_sun_midp_io_Util {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/Util */
};

struct Java_com_sun_midp_io_j2me_apdu_Slot {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/apdu/Slot */
    /*  @4 */	jint slot;
    /*  @8 */	jint received;
    /* @12 */	jbyte_array * JVM_FIELD_CONST respBuffer;
    /* @16 */	jbyte_array * JVM_FIELD_CONST getChannelAPDU;
    /* @20 */	jbyte_array * JVM_FIELD_CONST closeChannelAPDU;
    /* @24 */	jbyte_array * JVM_FIELD_CONST getResponseAPDU;
    /* @28 */	jbyte_array * JVM_FIELD_CONST isAliveAPDU;
    /* @32 */	jbyte_array * JVM_FIELD_CONST atr;
    /* @36 */	jbyte_array * JVM_FIELD_CONST FCI;
    /* @40 */	jint cardSessionId;
    /* @44 */	jboolean SIMPresent;
    /* @45 */	jboolean locked;
    /* @46 */	jboolean basicChannelInUse;
    /* @47 */	jboolean powered;
};

struct Java_com_sun_midp_io_j2me_apdu_Handle {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/apdu/Handle */
    /*  @4 */	jint slot;
    /*  @8 */	jint channel;
    /* @12 */	struct Java_com_sun_midp_io_j2me_apdu_Slot * JVM_FIELD_CONST cardSlot;
    /* @16 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST token;
    /* @20 */	jbyte_array * JVM_FIELD_CONST FCI;
    /* @24 */	jint cardSessionId;
    /* @28 */	jint handleInstance;
    /* @32 */	jboolean opened;
    /* @33 */	jbyte ___pad310;
    /* @34 */	jbyte ___pad311;
    /* @35 */	jbyte ___pad312;
};

struct Java_com_sun_midp_io_j2me_apdu_APDUManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/apdu/APDUManager */
};

struct Java_com_sun_satsa_acl_APDUPermissions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACLPermissions */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST permissions;
    /* @12 */	jobject_array * JVM_FIELD_CONST pins;
    /* @16 */	struct Java_com_sun_satsa_acl_ACSlot * JVM_FIELD_CONST parent;
    /* @20 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST attr1;
    /* @24 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST attr2;
    /* com/sun/satsa/acl/APDUPermissions */
};

struct Java_javax_microedition_apdu_APDUConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/apdu/APDUConnection */
};

struct Java_com_sun_midp_io_j2me_apdu_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/apdu/Protocol */
    /*  @4 */	struct Java_com_sun_satsa_acl_APDUPermissions * JVM_FIELD_CONST verifier;
    /*  @8 */	struct Java_com_sun_midp_io_j2me_apdu_Handle * JVM_FIELD_CONST h;
    /* @12 */	jboolean openForSAT;
    /* @13 */	jbyte ___pad313;
    /* @14 */	jbyte ___pad314;
    /* @15 */	jbyte ___pad315;
};

struct Java_com_sun_midp_io_j2me_btgoep_BTGOEPConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/btgoep/BTGOEPConnection */
    /*  @4 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST sock;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST is;
    /* @12 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST os;
};

struct Java_javax_microedition_io_StreamConnectionNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/StreamConnectionNotifier */
};

struct Java_com_sun_midp_io_j2me_btgoep_BTGOEPNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/btgoep/BTGOEPNotifier */
    /*  @4 */	struct Java_javax_microedition_io_StreamConnectionNotifier * JVM_FIELD_CONST notifier;
};

struct Java_com_sun_midp_io_j2me_btgoep_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/BluetoothProtocol */
    /*  @4 */	jint protocol;
    /*  @8 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /* com/sun/midp/io/j2me/btgoep/Protocol */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
};

struct Java_com_sun_midp_io_j2me_btl2cap_L2CAPNotifierImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BluetoothNotifier */
    /*  @4 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordImpl * JVM_FIELD_CONST serviceRec;
    /* @12 */	jint mode;
    /* @16 */	jboolean isClosed;
    /* @17 */	jbyte ___pad316;
    /* @18 */	jbyte ___pad317;
    /* @19 */	jbyte ___pad318;
    /* com/sun/midp/io/j2me/btl2cap/L2CAPNotifierImpl */
    /* @20 */	jint handle;
    /* @24 */	jint peerHandle;
    /* @28 */	jbyte_array * JVM_FIELD_CONST peerAddress;
    /* @32 */	jint mtus;
    /* @36 */	struct Java_javax_bluetooth_DataElement * JVM_FIELD_CONST PSM;
    /* @40 */	jint pushHandle;
    /* @44 */	jboolean isListenMode;
    /* @45 */	jbyte ___pad319;
    /* @46 */	jbyte ___pad320;
    /* @47 */	jbyte ___pad321;
};

struct Java_com_sun_midp_io_j2me_btl2cap_L2CAPConnectionImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BluetoothConnection */
    /*  @4 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST remoteDevice;
    /* @16 */	jboolean authorized;
    /* @17 */	jboolean encrypted;
    /* @18 */	jbyte ___pad322;
    /* @19 */	jbyte ___pad323;
    /* com/sun/midp/io/j2me/btl2cap/L2CAPConnectionImpl */
    /* @20 */	jbyte_array * JVM_FIELD_CONST remoteDeviceAddress;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @32 */	jint mtus;
    /* @36 */	jint handle;
    /* @40 */	jint receiveMTU;
    /* @44 */	jint transmitMTU;
};

struct Java_com_sun_midp_io_j2me_btl2cap_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/BluetoothProtocol */
    /*  @4 */	jint protocol;
    /*  @8 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /* com/sun/midp/io/j2me/btl2cap/Protocol */
};

struct Java_com_sun_midp_io_j2me_btspp_BTSPPConnectionImpl_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/btspp/BTSPPConnectionImpl$1 */
};

struct Java_com_sun_midp_io_j2me_btspp_BTSPPConnectionImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BluetoothConnection */
    /*  @4 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /*  @8 */	jint mode;
    /* @12 */	struct Java_javax_bluetooth_RemoteDevice * JVM_FIELD_CONST remoteDevice;
    /* @16 */	jboolean authorized;
    /* @17 */	jboolean encrypted;
    /* @18 */	jbyte ___pad324;
    /* @19 */	jbyte ___pad325;
    /* com/sun/midp/io/j2me/btspp/BTSPPConnectionImpl */
    /* @20 */	jbyte_array * JVM_FIELD_CONST remoteDeviceAddress;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @32 */	jint handle;
    /* @36 */	jint objects;
    /* @40 */	jboolean isOpened;
    /* @41 */	jboolean osOpened;
    /* @42 */	jbyte ___pad326;
    /* @43 */	jbyte ___pad327;
};

struct Java_com_sun_midp_io_j2me_btspp_BTSPPConnectionImpl_0004SPPInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/io/j2me/btspp/BTSPPConnectionImpl$SPPInputStream */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_btspp_BTSPPConnectionImpl * JVM_FIELD_CONST this_0440;
    /*  @8 */	jboolean isClosed;
    /* @9 */	jbyte ___pad328;
    /* @10 */	jbyte ___pad329;
    /* @11 */	jbyte ___pad330;
};

struct Java_com_sun_midp_io_j2me_btspp_BTSPPConnectionImpl_0004SPPOutputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/io/j2me/btspp/BTSPPConnectionImpl$SPPOutputStream */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_btspp_BTSPPConnectionImpl * JVM_FIELD_CONST this_0440;
    /*  @8 */	jboolean isClosed;
    /* @9 */	jbyte ___pad331;
    /* @10 */	jbyte ___pad332;
    /* @11 */	jbyte ___pad333;
};

struct Java_com_sun_midp_io_j2me_btspp_BTSPPNotifierImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/kvem/jsr082/bluetooth/BluetoothNotifier */
    /*  @4 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /*  @8 */	struct Java_com_sun_kvem_jsr082_bluetooth_ServiceRecordImpl * JVM_FIELD_CONST serviceRec;
    /* @12 */	jint mode;
    /* @16 */	jboolean isClosed;
    /* @17 */	jbyte ___pad334;
    /* @18 */	jbyte ___pad335;
    /* @19 */	jbyte ___pad336;
    /* com/sun/midp/io/j2me/btspp/BTSPPNotifierImpl */
    /* @20 */	jint handle;
    /* @24 */	jint peerHandle;
    /* @28 */	jbyte_array * JVM_FIELD_CONST peerAddress;
    /* @32 */	jint cid;
    /* @36 */	struct Java_javax_bluetooth_DataElement * JVM_FIELD_CONST CHANNEL_ID;
    /* @40 */	jint pushHandle;
    /* @44 */	jboolean isListenMode;
    /* @45 */	jbyte ___pad337;
    /* @46 */	jbyte ___pad338;
    /* @47 */	jbyte ___pad339;
};

struct Java_com_sun_midp_io_j2me_btspp_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/BluetoothProtocol */
    /*  @4 */	jint protocol;
    /*  @8 */	struct Java_com_sun_midp_io_BluetoothUrl * JVM_FIELD_CONST url;
    /* com/sun/midp/io/j2me/btspp/Protocol */
};

struct Java_javax_wireless_messaging_Message {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/Message */
};

struct Java_javax_wireless_messaging_BinaryMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/BinaryMessage */
};

struct Java_com_sun_midp_io_j2me_sms_MessageObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
};

struct Java_com_sun_midp_io_j2me_sms_BinaryObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/BinaryObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_io_j2me_cbs_BinaryObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/BinaryObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* com/sun/midp/io/j2me/cbs/BinaryObject */
};

struct Java_com_sun_midp_io_j2me_cbs_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/cbs/Protocol */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST CBS_URL_PREFIX;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @12 */	jint m_mode;
    /* @16 */	jint m_imsgid;
    /* @20 */	jint cbsHandle;
    /* @24 */	struct Java_javax_wireless_messaging_MessageListener * JVM_FIELD_CONST m_listener;
    /* @28 */	struct Java_java_lang_Thread * JVM_FIELD_CONST m_listenerThread;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @36 */	jboolean open;
    /* @37 */	jboolean openPermission;
    /* @38 */	jboolean readPermission;
    /* @39 */	jboolean doneRetrieving;
};

struct Java_javax_wireless_messaging_MessageConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessageConnection */
};

struct Java_javax_wireless_messaging_MessageListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessageListener */
};

struct Java_com_sun_midp_io_j2me_cbs_Protocol_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/io/j2me/cbs/Protocol$1 */
    /* @28 */	struct Java_javax_wireless_messaging_MessageConnection * JVM_FIELD_CONST val_044messageConnection;
    /* @32 */	struct Java_com_sun_midp_io_j2me_cbs_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_cbs_Protocol_0004CBSPacket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/cbs/Protocol$CBSPacket */
    /*  @4 */	jint encodingType;
    /*  @8 */	jint msgID;
    /* @12 */	jbyte_array * JVM_FIELD_CONST message;
    /* @16 */	struct Java_com_sun_midp_io_j2me_cbs_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_javax_wireless_messaging_TextMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/TextMessage */
};

struct Java_com_sun_midp_io_j2me_sms_TextObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/TextObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_io_j2me_cbs_TextObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/sms/TextObject */
    /* @20 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* com/sun/midp/io/j2me/cbs/TextObject */
};

struct Java_java_io_DataInput {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/DataInput */
};

struct Java_java_io_DataOutput {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/DataOutput */
};

struct Java_javax_microedition_io_Datagram {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Datagram */
};

struct Java_com_sun_midp_io_j2me_datagram_DatagramObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/DatagramObject */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST buffer;
    /*  @8 */	jint offset;
    /* @12 */	jint length;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /* @20 */	jint ipNumber;
    /* @24 */	jint port;
    /* @28 */	jint readWritePosition;
};

struct Java_java_io_UTFDataFormatException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/UTFDataFormatException */
};

struct Java_java_io_EOFException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* java/io/EOFException */
};

struct Java_javax_microedition_io_DatagramConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/DatagramConnection */
};

struct Java_javax_microedition_io_UDPDatagramConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/UDPDatagramConnection */
};

struct Java_com_sun_midp_io_j2me_datagram_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/datagram/Protocol */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @12 */	jint nativeHandle;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @20 */	jint port;
    /* @24 */	jboolean open;
    /* @25 */	jboolean ownerTrusted;
    /* @26 */	jbyte ___pad340;
    /* @27 */	jbyte ___pad341;
};

struct Java_com_sun_midp_io_j2me_file_BaseFileHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/BaseFileHandler */
};

struct Java_com_sun_midp_io_j2me_file_DefaultFileHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/DefaultFileHandler */
    /*  @4 */	jint readHandle;
    /*  @8 */	jint writeHandle;
    /* @12 */	jlong fileName;
    /* @20 */	jlong rootDir;
};

struct Java_com_sun_midp_io_j2me_file_EscapedUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/EscapedUtil */
};

struct Java_javax_microedition_io_file_FileConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileConnection */
};

struct Java_com_sun_midp_io_j2me_file_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad342;
    /* @22 */	jbyte ___pad343;
    /* @23 */	jbyte ___pad344;
    /* com/sun/midp/io/j2me/file/Protocol */
    /* @24 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST classSecurityToken;
    /* @28 */	jint mode;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST fileName;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST filePath;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST fileRoot;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST fileURL;
    /* @48 */	struct Java_com_sun_midp_io_j2me_file_BaseFileHandler * JVM_FIELD_CONST fileHandler;
    /* @52 */	struct Java_java_io_InputStream * JVM_FIELD_CONST fis;
    /* @56 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST fos;
};

struct Java_javax_microedition_io_file_ConnectionClosedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/io/file/ConnectionClosedException */
};

struct Java_javax_microedition_io_file_IllegalModeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javax/microedition/io/file/IllegalModeException */
};

struct Java_com_sun_midp_io_j2me_file_RootCache {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/file/RootCache */
    /*  @4 */	jobject_array * JVM_FIELD_CONST roots;
};

struct Java_javax_microedition_io_SocketConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SocketConnection */
};

struct Java_com_sun_midp_io_j2me_socket_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad345;
    /* @22 */	jbyte ___pad346;
    /* @23 */	jbyte ___pad347;
    /* com/sun/midp/io/BufferedConnectionAdapter */
    /* @24 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @28 */	jint count;
    /* @32 */	jint pos;
    /* @36 */	jboolean eof;
    /* @37 */	jbyte ___pad348;
    /* @38 */	jbyte ___pad349;
    /* @39 */	jbyte ___pad350;
    /* com/sun/midp/io/NetworkConnectionBase */
    /* com/sun/midp/io/j2me/socket/Protocol */
    /* @40 */	jint handle;
    /* @44 */	struct Java_java_lang_Object * JVM_FIELD_CONST readerLock;
    /* @48 */	struct Java_java_lang_Object * JVM_FIELD_CONST writerLock;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @56 */	jint port;
    /* @60 */	jbyte_array * JVM_FIELD_CONST ipBytes;
    /* @64 */	jboolean outputShutdown;
    /* @65 */	jboolean ownerTrusted;
    /* @66 */	jbyte ___pad351;
    /* @67 */	jbyte ___pad352;
};

struct Java_com_sun_midp_ssl_SSLStreamConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/SSLStreamConnection */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	struct Java_com_sun_midp_ssl_In * JVM_FIELD_CONST uin;
    /* @12 */	struct Java_com_sun_midp_ssl_Out * JVM_FIELD_CONST uout;
    /* @16 */	struct Java_java_io_InputStream * JVM_FIELD_CONST sin;
    /* @20 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST sout;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @28 */	jint port;
    /* @32 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST serverCert;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST cipherSuite;
    /* @40 */	jint inputStreamState;
    /* @44 */	jint outputStreamState;
    /* @48 */	jboolean copen;
    /* @49 */	jbyte ___pad353;
    /* @50 */	jbyte ___pad354;
    /* @51 */	jbyte ___pad355;
};

struct Java_javax_microedition_io_SecurityInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SecurityInfo */
};

struct Java_javax_microedition_io_HttpsConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/HttpsConnection */
};

struct Java_com_sun_midp_io_j2me_https_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/ConnectionBaseAdapter */
    /*  @4 */	jint iStreams;
    /*  @8 */	jint maxIStreams;
    /* @12 */	jint oStreams;
    /* @16 */	jint maxOStreams;
    /* @20 */	jboolean connectionOpen;
    /* @21 */	jbyte ___pad356;
    /* @22 */	jbyte ___pad357;
    /* @23 */	jbyte ___pad358;
    /* com/sun/midp/io/j2me/http/Protocol */
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /* @28 */	jint default_port;
    /* @32 */	struct Java_com_sun_midp_io_HttpUrl * JVM_FIELD_CONST url;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST hostAndPort;
    /* @40 */	jint responseCode;
    /* @44 */	struct Java_java_lang_String * JVM_FIELD_CONST responseMsg;
    /* @48 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST reqProperties;
    /* @52 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST headerFields;
    /* @56 */	struct Java_java_lang_String * JVM_FIELD_CONST method;
    /* @60 */	struct Java_javax_microedition_io_StreamConnection * JVM_FIELD_CONST streamConnection;
    /* @64 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST streamOutput;
    /* @68 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST streamInput;
    /* @72 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST stringbuffer;
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST httpVer;
    /* @80 */	jint contentLength;
    /* @84 */	jint chunksize;
    /* @88 */	jint totalbytesread;
    /* @92 */	jbyte_array * JVM_FIELD_CONST readbuf;
    /* @96 */	jint bytesleft;
    /* @100 */	jint bytesread;
    /* @104 */	jbyte_array * JVM_FIELD_CONST writebuf;
    /* @108 */	jint bytesToWrite;
    /* @112 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST __dup1__proxyHeaders;
    /* @116 */	jboolean __dup1__permissionChecked;
    /* @117 */	jboolean __dup1__ownerTrusted;
    /* @118 */	jboolean ConnectionCloseFlag;
    /* @119 */	jboolean chunkedIn;
    /* @120 */	jboolean chunkedOut;
    /* @121 */	jboolean firstChunkSent;
    /* @122 */	jboolean sendingRequest;
    /* @123 */	jboolean requestFinished;
    /* @124 */	jboolean eof;
    /* @125 */	jbyte handshakeError;
    /* @126 */	jboolean readInProgress;
    /* @127 */	jbyte ___pad359;
    /* com/sun/midp/io/j2me/https/Protocol */
    /* @128 */	struct Java_com_sun_midp_util_Properties * JVM_FIELD_CONST proxyHeaders;
    /* @132 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST sslConnection;
    /* @136 */	jboolean permissionChecked;
    /* @137 */	jboolean ownerTrusted;
    /* @138 */	jbyte ___pad360;
    /* @139 */	jbyte ___pad361;
};

struct Java_com_sun_midp_ssl_Record {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Record */
    /*  @4 */	jint HEADER_SIZE;
    /*  @8 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* @12 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* @16 */	jbyte_array * JVM_FIELD_CONST inputHeader;
    /* @20 */	jint headerBytesRead;
    /* @24 */	jint dataLength;
    /* @28 */	jint dataBytesRead;
    /* @32 */	jbyte_array * JVM_FIELD_CONST inputData;
    /* @36 */	jint plainTextLength;
    /* @40 */	struct Java_com_sun_midp_ssl_RecordEncoder * JVM_FIELD_CONST encoder;
    /* @44 */	struct Java_com_sun_midp_ssl_RecordDecoder * JVM_FIELD_CONST decoder;
    /* @48 */	jbyte rActive;
    /* @49 */	jbyte wActive;
    /* @50 */	jbyte ver;
    /* @51 */	jboolean shutdown;
};

struct Java_com_sun_midp_ssl_In {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/midp/ssl/In */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	jint start;
    /* @12 */	jint cnt;
    /* @16 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST ssc;
    /* @20 */	jboolean endOfStream;
    /* @21 */	jbyte ___pad362;
    /* @22 */	jbyte ___pad363;
    /* @23 */	jbyte ___pad364;
};

struct Java_com_sun_midp_ssl_Out {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/OutputStream */
    /* com/sun/midp/ssl/Out */
    /*  @4 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /*  @8 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST ssc;
    /* @12 */	jbyte_array * JVM_FIELD_CONST buf;
};

struct Java_com_sun_satsa_acl_JCRMIPermissions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACLPermissions */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST permissions;
    /* @12 */	jobject_array * JVM_FIELD_CONST pins;
    /* @16 */	struct Java_com_sun_satsa_acl_ACSlot * JVM_FIELD_CONST parent;
    /* @20 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST attr1;
    /* @24 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST attr2;
    /* com/sun/satsa/acl/JCRMIPermissions */
};

struct Java_java_rmi_Remote {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/rmi/Remote */
};

struct Java_com_sun_midp_io_j2me_jcrmi_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/jcrmi/Protocol */
    /*  @4 */	struct Java_java_rmi_Remote * JVM_FIELD_CONST initialReference;
    /*  @8 */	struct Java_com_sun_midp_io_j2me_jcrmi_Reference * JVM_FIELD_CONST internalReference;
    /* @12 */	jbyte_array * JVM_FIELD_CONST APDUBuffer;
    /* @16 */	jint offset;
    /* @20 */	jbyte_array * JVM_FIELD_CONST response;
    /* @24 */	jint r_offset;
    /* @28 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST SHA;
    /* @32 */	struct Java_com_sun_midp_io_j2me_apdu_Handle * JVM_FIELD_CONST h;
    /* @36 */	struct Java_com_sun_satsa_acl_JCRMIPermissions * JVM_FIELD_CONST verifier;
    /* @40 */	jboolean connectionOpen;
    /* @41 */	jbyte ___pad365;
    /* @42 */	jbyte ___pad366;
    /* @43 */	jbyte ___pad367;
};

struct Java_com_sun_midp_io_j2me_jcrmi_Reference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/jcrmi/Reference */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_jcrmi_Protocol * JVM_FIELD_CONST connection;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST hashModifier;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST className;
    /* @16 */	jshort objectID;
    /* @17 */	jbyte ___pad368;
    /* @18 */	jbyte ___pad369;
};

struct Java_javax_microedition_jcrmi_RemoteRef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/jcrmi/RemoteRef */
};

struct Java_javax_microedition_jcrmi_JavaCardRMIConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/jcrmi/JavaCardRMIConnection */
};

struct Java_java_lang_ArrayStoreException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/ArrayStoreException */
};

struct Java_java_lang_NegativeArraySizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/NegativeArraySizeException */
};

struct Java_javacard_framework_CardRuntimeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad370;
    /* @14 */	jbyte ___pad371;
};

struct Java_javacard_framework_APDUException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad372;
    /* @14 */	jbyte ___pad373;
    /* javacard/framework/APDUException */
};

struct Java_javacard_framework_CardException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javacard/framework/CardException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad374;
    /* @14 */	jbyte ___pad375;
};

struct Java_javacard_framework_ISOException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad376;
    /* @14 */	jbyte ___pad377;
    /* javacard/framework/ISOException */
};

struct Java_javacard_framework_PINException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad378;
    /* @14 */	jbyte ___pad379;
    /* javacard/framework/PINException */
};

struct Java_javacard_framework_SystemException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad380;
    /* @14 */	jbyte ___pad381;
    /* javacard/framework/SystemException */
};

struct Java_javacard_framework_TransactionException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad382;
    /* @14 */	jbyte ___pad383;
    /* javacard/framework/TransactionException */
};

struct Java_javacard_framework_UserException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javacard/framework/CardException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad384;
    /* @14 */	jbyte ___pad385;
    /* javacard/framework/UserException */
};

struct Java_javacard_security_CryptoException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad386;
    /* @14 */	jbyte ___pad387;
    /* javacard/security/CryptoException */
};

struct Java_javacard_framework_service_ServiceException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* javacard/framework/CardRuntimeException */
    /* @12 */	jshort reason;
    /* @13 */	jbyte ___pad388;
    /* @14 */	jbyte ___pad389;
    /* javacard/framework/service/ServiceException */
};

struct Java_com_sun_midp_io_j2me_mms_MMSAddress {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/mms/MMSAddress */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST appId;
    /* @12 */	jint type;
};

struct Java_javax_wireless_messaging_MessagePart {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MessagePart */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST content;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST contentID;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST contentLocation;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST encoding;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST mimeType;
};

struct Java_javax_wireless_messaging_MultipartMessage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/wireless/messaging/MultipartMessage */
};

struct Java_com_sun_midp_io_j2me_mms_MultipartObject {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/MessageObject */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST messtype;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST messaddr;
    /* @12 */	jlong sentAt;
    /* com/sun/midp/io/j2me/mms/MultipartObject */
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST to;
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST cc;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST bcc;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST parts;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST startContentID;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST subject;
    /* @44 */	jobject_array * JVM_FIELD_CONST headerValues;
    /* @48 */	struct Java_java_lang_String * JVM_FIELD_CONST applicationID;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST replyToApplicationID;
};

struct Java_javax_wireless_messaging_SizeExceededException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* javax/wireless/messaging/SizeExceededException */
};

struct Java_com_sun_midp_io_j2me_mms_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/mms/Protocol */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST MMS_URL_PREFIX;
    /*  @8 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @12 */	jint mmsHandle;
    /* @16 */	jint m_mode;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST appID;
    /* @28 */	struct Java_javax_wireless_messaging_MessageListener * JVM_FIELD_CONST m_listener;
    /* @32 */	struct Java_java_lang_Thread * JVM_FIELD_CONST m_listenerThread;
    /* @36 */	jboolean open;
    /* @37 */	jboolean openPermission;
    /* @38 */	jboolean readPermission;
    /* @39 */	jboolean writePermission;
};

struct Java_com_sun_midp_io_j2me_mms_Protocol_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/io/j2me/mms/Protocol$1 */
    /* @28 */	struct Java_javax_wireless_messaging_MessageConnection * JVM_FIELD_CONST val_044messageConnection;
    /* @32 */	struct Java_com_sun_midp_io_j2me_mms_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_mms_Protocol_0004MMSPacket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/mms/Protocol$MMSPacket */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST fromAddress;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST appID;
    /* @12 */	jbyte_array * JVM_FIELD_CONST replyToAppID;
    /* @16 */	jbyte_array * JVM_FIELD_CONST message;
    /* @20 */	struct Java_com_sun_midp_io_j2me_mms_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_push_PushRegistryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/push/PushRegistryImpl */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST midletProxyList;
};

struct Java_com_sun_midp_io_j2me_socket_ServerSocket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/socket/ServerSocket */
};

struct Java_javax_microedition_io_ServerSocketConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/ServerSocketConnection */
};

struct Java_com_sun_midp_io_j2me_serversocket_Socket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/serversocket/Socket */
    /*  @4 */	jint nativeHandle;
    /*  @8 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST privilegedSecurityToken;
    /* @12 */	jboolean connectionOpen;
    /* @13 */	jbyte ___pad390;
    /* @14 */	jbyte ___pad391;
    /* @15 */	jbyte ___pad392;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/Protocol */
    /*  @4 */	jint connectionMode;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST url;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @16 */	jint m_iport;
    /* @20 */	jint smsHandle;
    /* @24 */	jint m_mode;
    /* @28 */	struct Java_javax_wireless_messaging_MessageListener * JVM_FIELD_CONST m_listener;
    /* @32 */	struct Java_java_lang_Thread * JVM_FIELD_CONST m_listenerThread;
    /* @36 */	struct Java_com_sun_midp_midlet_MIDletSuite * JVM_FIELD_CONST midletSuite;
    /* @40 */	jint_array * JVM_FIELD_CONST restrictedPorts;
    /* @44 */	jboolean open;
    /* @45 */	jboolean openPermission;
    /* @46 */	jboolean readPermission;
    /* @47 */	jboolean writePermission;
    /* @48 */	jboolean doneRetrieving;
    /* @49 */	jbyte ___pad393;
    /* @50 */	jbyte ___pad394;
    /* @51 */	jbyte ___pad395;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/io/j2me/sms/Protocol$1 */
    /* @28 */	struct Java_javax_wireless_messaging_MessageConnection * JVM_FIELD_CONST val_044messageConnection;
    /* @32 */	struct Java_com_sun_midp_io_j2me_sms_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_sms_Protocol_0004SMSPacket {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/Protocol$SMSPacket */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST message;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST address;
    /* @12 */	jint port;
    /* @16 */	jlong sentAt;
    /* @24 */	jint messageType;
    /* @28 */	struct Java_com_sun_midp_io_j2me_sms_Protocol * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_io_j2me_sms_TextEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/sms/TextEncoder */
};

struct Java_javax_microedition_io_SecureConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/SecureConnection */
};

struct Java_com_sun_midp_io_j2me_ssl_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/ssl/Protocol */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_socket_Protocol * JVM_FIELD_CONST tcpConnection;
    /*  @8 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST sslConnection;
};

struct Java_com_sun_midp_io_j2me_tcpobex_TCPOBEXNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/tcpobex/TCPOBEXNotifier */
    /*  @4 */	struct Java_com_sun_midp_io_j2me_serversocket_Socket * JVM_FIELD_CONST serverSocket;
    /*  @8 */	jint port;
    /* @12 */	jboolean isClosed;
    /* @13 */	jbyte ___pad396;
    /* @14 */	jbyte ___pad397;
    /* @15 */	jbyte ___pad398;
};

struct Java_com_sun_midp_io_j2me_tcpobex_TCPOBEXConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/tcpobex/TCPOBEXConnection */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* @12 */	jboolean isClosed;
    /* @13 */	jbyte ___pad399;
    /* @14 */	jbyte ___pad400;
    /* @15 */	jbyte ___pad401;
};

struct Java_com_sun_midp_io_j2me_tcpobex_Protocol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/io/j2me/tcpobex/Protocol */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST origName;
    /*  @8 */	jboolean clientPermitted;
    /*  @9 */	jboolean serverPermitted;
    /* @10 */	jbyte ___pad402;
    /* @11 */	jbyte ___pad403;
};

struct Java_com_sun_midp_jsr082_BluetoothUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/BluetoothUtils */
};

struct Java_com_sun_midp_jsr082_SecurityInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/SecurityInitializer */
};

struct Java_com_sun_midp_jsr082_bluetooth_BluetoothEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothEvent */
};

struct Java_com_sun_midp_jsr082_bluetooth_AuthenticationCompleteEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothEvent */
    /* com/sun/midp/jsr082/bluetooth/AuthenticationCompleteEvent */
    /*  @4 */	jint handle;
    /*  @8 */	jboolean success;
    /* @9 */	jbyte ___pad404;
    /* @10 */	jbyte ___pad405;
    /* @11 */	jbyte ___pad406;
};

struct Java_com_sun_midp_jsr082_bluetooth_BluetoothPush {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothPush */
};

struct Java_com_sun_midp_jsr082_bluetooth_InquiryResult {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/InquiryResult */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST address;
    /*  @8 */	struct Java_javax_bluetooth_DeviceClass * JVM_FIELD_CONST deviceClass;
};

struct Java_com_sun_midp_jsr082_bluetooth_GenericBluetoothStack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothStack */
    /*  @4 */	jint nativeInstance;
    /*  @8 */	struct Java_javax_bluetooth_DiscoveryListener * JVM_FIELD_CONST discListener;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST nameResults;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST authenticateResults;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST encryptResults;
    /* @24 */	jlong ASK_FRIENDLY_NAME_TIMEOUT;
    /* @32 */	jlong AUTHENTICATE_TIMEOUT;
    /* @40 */	jlong ENCRYPT_TIMEOUT;
    /* @48 */	jint pollRequests;
    /* @52 */	struct Java_java_util_Vector * JVM_FIELD_CONST inquiryHistory;
    /* com/sun/midp/jsr082/bluetooth/GenericBluetoothStack */
    /* @56 */	jint MAX_HCI_PACKET_SIZE;
    /* @60 */	jint HCI_INQUIRY_COMPLETE;
    /* @64 */	jint HCI_INQUIRY_RESULT;
    /* @68 */	jint HCI_AUTH_COMPLETE;
    /* @72 */	jint HCI_NAME_COMPLETE;
    /* @76 */	jint HCI_ENCRYPT_CHANGE;
    /* @80 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_jsr082_bluetooth_Dispatcher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/jsr082/bluetooth/Dispatcher */
};

struct Java_java_lang_IllegalThreadStateException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/IllegalArgumentException */
    /* java/lang/IllegalThreadStateException */
};

struct Java_com_sun_midp_jsr082_bluetooth_EncryptionChangeEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothEvent */
    /* com/sun/midp/jsr082/bluetooth/EncryptionChangeEvent */
    /*  @4 */	jint handle;
    /*  @8 */	jboolean success;
    /*  @9 */	jboolean enabled;
    /* @10 */	jbyte ___pad407;
    /* @11 */	jbyte ___pad408;
};

struct Java_com_sun_midp_jsr082_bluetooth_InquiryCompleteEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothEvent */
    /* com/sun/midp/jsr082/bluetooth/InquiryCompleteEvent */
    /*  @4 */	jboolean success;
    /* @5 */	jbyte ___pad409;
    /* @6 */	jbyte ___pad410;
    /* @7 */	jbyte ___pad411;
};

struct Java_com_sun_midp_jsr082_bluetooth_InquiryResultEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothEvent */
    /* com/sun/midp/jsr082/bluetooth/InquiryResultEvent */
    /*  @4 */	jobject_array * JVM_FIELD_CONST results;
};

struct Java_com_sun_midp_jsr082_bluetooth_NameResultEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/BluetoothEvent */
    /* com/sun/midp/jsr082/bluetooth/NameResultEvent */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST deviceAddr;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST deviceName;
};

struct Java_com_sun_midp_jsr082_bluetooth_NameListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr082/bluetooth/NameListener */
};

struct Java_com_sun_midp_jsr082_bluetooth_PollingThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/midp/jsr082/bluetooth/PollingThread */
    /* @28 */	jint POLL_INTERVAL;
};

struct Java_com_sun_midp_jsr82emul_BytePack {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/BytePack */
    /*  @4 */	jint offset;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buffer;
};

struct Java_com_sun_midp_jsr82emul_DeviceState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/DeviceState */
    /*  @4 */	jint data;
};

struct Java_com_sun_midp_jsr82emul_Messenger {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/Messenger */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST bytes;
    /*  @8 */	jbyte code;
    /* @9 */	jbyte ___pad412;
    /* @10 */	jbyte ___pad413;
    /* @11 */	jbyte ___pad414;
};

struct Java_com_sun_midp_jsr82emul_EmulationServer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulationServer */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST services;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST devices;
    /* @12 */	jint nextAddr;
};

struct Java_com_sun_midp_jsr82emul_ServiceConnectionData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/BytePack */
    /*  @4 */	jint offset;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buffer;
    /* com/sun/midp/jsr82emul/ServiceConnectionData */
    /* @12 */	jint error;
    /* @16 */	jint socketPort;
    /* @20 */	jbyte_array * JVM_FIELD_CONST address;
    /* @24 */	jint port;
    /* @28 */	jint receiveMTU;
    /* @32 */	jint transmitMTU;
    /* @36 */	jint protocol;
    /* @40 */	jboolean master;
    /* @41 */	jboolean encrypt;
    /* @42 */	jboolean authorize;
    /* @43 */	jboolean authenticate;
    /* @44 */	jboolean accepting;
    /* @45 */	jbyte ___pad415;
    /* @46 */	jbyte ___pad416;
    /* @47 */	jbyte ___pad417;
};

struct Java_com_sun_midp_jsr82emul_ServiceKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/ServiceKey */
    /*  @4 */	struct Java_com_sun_midp_jsr82emul_DeviceKey * JVM_FIELD_CONST btaddr;
    /*  @8 */	jint protocol;
    /* @12 */	jint channelOrPsm;
};

struct Java_com_sun_midp_jsr82emul_InquiryResults {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/InquiryResults */
    /*  @4 */	jint count;
    /*  @8 */	jobject_array * JVM_FIELD_CONST addresses;
    /* @12 */	jint_array * JVM_FIELD_CONST classes;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST results;
};

struct Java_com_sun_midp_jsr82emul_ClientHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/ClientHandler */
    /*  @4 */	jint handle;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST bluetoothAddress;
    /* @12 */	jbyte_array * JVM_FIELD_CONST ipAddress;
    /* @16 */	struct Java_com_sun_midp_jsr82emul_DeviceState * JVM_FIELD_CONST deviceState;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST deviceServices;
    /* @24 */	struct Java_com_sun_midp_jsr82emul_Messenger * JVM_FIELD_CONST messenger;
    /* @28 */	struct Java_javax_microedition_io_SocketConnection * JVM_FIELD_CONST connection;
    /* @32 */	struct Java_java_io_InputStream * JVM_FIELD_CONST fromClient;
    /* @36 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST toClient;
};

struct Java_com_sun_midp_jsr82emul_EmulationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* com/sun/midp/jsr82emul/EmulationException */
};

struct Java_com_sun_midp_jsr82emul_EmulUnit {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulUnit */
};

struct Java_com_sun_midp_jsr82emul_ConnRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulUnitCaller */
    /*  @4 */	jobject_array * JVM_FIELD_CONST callee;
    /* com/sun/midp/jsr82emul/ConnRegistry */
};

struct Java_com_sun_midp_jsr82emul_EmulUnitCaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulUnitCaller */
    /*  @4 */	jobject_array * JVM_FIELD_CONST callee;
};

struct Java_com_sun_midp_jsr82emul_ConnectionCreator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/ConnectionCreator */
};

struct Java_com_sun_midp_jsr82emul_ConnectionEmul {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulationClient */
    /*  @4 */	struct Java_com_sun_midp_jsr82emul_Messenger * JVM_FIELD_CONST messenger;
    /*  @8 */	struct Java_javax_microedition_io_SocketConnection * JVM_FIELD_CONST connection;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST fromServer;
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST toServer;
    /* com/sun/midp/jsr82emul/ConnectionEmul */
    /* @20 */	struct Java_com_sun_midp_jsr82emul_ServiceConnectionData * JVM_FIELD_CONST serviceData;
    /* @24 */	struct Java_com_sun_midp_jsr82emul_ConnectionEmul_0004Opener * JVM_FIELD_CONST opener;
    /* @28 */	struct Java_javax_microedition_io_SocketConnection * JVM_FIELD_CONST socketConnection;
    /* @32 */	struct Java_com_sun_midp_jsr82emul_Sender * JVM_FIELD_CONST sender;
    /* @36 */	struct Java_com_sun_midp_jsr82emul_Receiver * JVM_FIELD_CONST receiver;
    /* @40 */	jint handle;
};

struct Java_com_sun_midp_jsr82emul_ConnectionEmul_0004Opener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad418;
    /* com/sun/midp/jsr82emul/ConnectionEmul$Opener */
    /* @12 */	struct Java_com_sun_midp_jsr82emul_ConnectionEmul * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_jsr82emul_RunnableProcessor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad419;
};

struct Java_com_sun_midp_jsr82emul_DeviceEmul {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulationClient */
    /*  @4 */	struct Java_com_sun_midp_jsr82emul_Messenger * JVM_FIELD_CONST messenger;
    /*  @8 */	struct Java_javax_microedition_io_SocketConnection * JVM_FIELD_CONST connection;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST fromServer;
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST toServer;
    /* com/sun/midp/jsr82emul/DeviceEmul */
    /* @20 */	struct Java_com_sun_midp_jsr82emul_DeviceEmul_0004Inquiry * JVM_FIELD_CONST curInquiry;
    /* @24 */	jbyte_array * JVM_FIELD_CONST address;
    /* @28 */	struct Java_com_sun_midp_jsr82emul_DeviceState * JVM_FIELD_CONST deviceState;
    /* @32 */	struct Java_java_lang_Object * JVM_FIELD_CONST serverTransaction;
};

struct Java_com_sun_midp_jsr82emul_Sender {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad420;
    /* com/sun/midp/jsr82emul/Sender */
    /* @12 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* @16 */	jbyte_array * JVM_FIELD_CONST outbuf;
    /* @20 */	jint handle;
};

struct Java_com_sun_midp_jsr82emul_Receiver {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad421;
    /* com/sun/midp/jsr82emul/Receiver */
    /* @12 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST in;
    /* @16 */	jbyte_array * JVM_FIELD_CONST inbuf;
    /* @20 */	jint handle;
};

struct Java_com_sun_midp_jsr82emul_EmulationClient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulationClient */
    /*  @4 */	struct Java_com_sun_midp_jsr82emul_Messenger * JVM_FIELD_CONST messenger;
    /*  @8 */	struct Java_javax_microedition_io_SocketConnection * JVM_FIELD_CONST connection;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST fromServer;
    /* @16 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST toServer;
};

struct Java_com_sun_midp_jsr82emul_Const {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/Const */
};

struct Java_com_sun_midp_jsr82emul_DeviceEmul_0004Inquiry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/DeviceEmul$Inquiry */
    /*  @4 */	jint accessCode;
    /*  @8 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /* @12 */	struct Java_com_sun_midp_jsr82emul_DeviceEmul * JVM_FIELD_CONST this_0440;
    /* @16 */	jboolean cancelled;
    /* @17 */	jbyte ___pad422;
    /* @18 */	jbyte ___pad423;
    /* @19 */	jbyte ___pad424;
};

struct Java_com_sun_midp_jsr82emul_DeviceKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/DeviceKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST addr;
};

struct Java_com_sun_midp_jsr82emul_MainCaller {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulUnitCaller */
    /*  @4 */	jobject_array * JVM_FIELD_CONST callee;
    /* com/sun/midp/jsr82emul/MainCaller */
};

struct Java_com_sun_midp_jsr82emul_EmulationPolling {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/EmulationPolling */
    /*  @4 */	jint length;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST requestBuf;
    /* @12 */	struct Java_com_sun_midp_jsr82emul_BytePack * JVM_FIELD_CONST request;
};

struct Java_com_sun_midp_jsr82emul_L2CAPReceiver {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad425;
    /* com/sun/midp/jsr82emul/Receiver */
    /* @12 */	struct Java_java_io_DataInputStream * JVM_FIELD_CONST in;
    /* @16 */	jbyte_array * JVM_FIELD_CONST inbuf;
    /* @20 */	jint handle;
    /* com/sun/midp/jsr82emul/L2CAPReceiver */
};

struct Java_com_sun_midp_jsr82emul_L2CAPSender {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad426;
    /* com/sun/midp/jsr82emul/Sender */
    /* @12 */	struct Java_java_io_OutputStream * JVM_FIELD_CONST out;
    /* @16 */	jbyte_array * JVM_FIELD_CONST outbuf;
    /* @20 */	jint handle;
    /* com/sun/midp/jsr82emul/L2CAPSender */
};

struct Java_com_sun_midp_jsr82emul_Log {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/Log */
};

struct Java_com_sun_midp_jsr82emul_NotifierCreator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/NotifierCreator */
};

struct Java_com_sun_midp_jsr82emul_NotifierEmul_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/NotifierEmul$1 */
};

struct Java_com_sun_midp_jsr82emul_NotifierEmul {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/NotifierEmul */
    /*  @4 */	jint handle;
    /*  @8 */	struct Java_com_sun_midp_jsr82emul_DeviceEmul * JVM_FIELD_CONST device;
    /* @12 */	struct Java_com_sun_midp_io_j2me_serversocket_Socket * JVM_FIELD_CONST serverSocket;
    /* @16 */	struct Java_com_sun_midp_jsr82emul_ServiceConnectionData * JVM_FIELD_CONST serviceData;
    /* @20 */	jint port;
    /* @24 */	struct Java_com_sun_midp_jsr82emul_ConnectionEmul * JVM_FIELD_CONST clientConnection;
    /* @28 */	struct Java_com_sun_midp_jsr82emul_NotifierEmul_0004Acceptor * JVM_FIELD_CONST acceptor;
};

struct Java_com_sun_midp_jsr82emul_NotifierEmul_0004Acceptor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/jsr82emul/RunnableProcessor */
    /*  @4 */	struct Java_java_lang_Thread * JVM_FIELD_CONST thread;
    /*  @8 */	jboolean ready;
    /*  @9 */	jboolean interrupted;
    /* @10 */	jboolean loop;
    /* @11 */	jbyte ___pad427;
    /* com/sun/midp/jsr82emul/NotifierEmul$Acceptor */
    /* @12 */	struct Java_com_sun_midp_jsr82emul_NotifierEmul * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_jsr82emul_ServerLauncher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDlet */
    /*  @4 */	struct Java_com_sun_midp_midlet_MIDletPeer * JVM_FIELD_CONST peer;
    /* com/sun/midp/jsr82emul/ServerLauncher */
};

struct Java_com_sun_midp_lcdui_CommandAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/CommandAccess */
};

struct Java_com_sun_midp_midlet_MIDletEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventConsumer */
};

struct Java_com_sun_midp_lcdui_DisplayEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventConsumer */
};

struct Java_com_sun_midp_lcdui_DisplayAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayAccess */
};

struct Java_com_sun_midp_lcdui_DisplayContainer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayContainer */
    /*  @4 */	jint isolateId;
    /*  @8 */	jint lastLocalDisplayId;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST displays;
};

struct Java_com_sun_midp_lcdui_DisplayDeviceAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayDeviceAccess */
    /*  @4 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST task;
    /*  @8 */	jint flashCount;
    /* @12 */	jboolean isLit;
    /* @13 */	jbyte ___pad428;
    /* @14 */	jbyte ___pad429;
    /* @15 */	jbyte ___pad430;
};

struct Java_com_sun_midp_lcdui_DisplayDeviceAccess_0004TimerClient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/lcdui/DisplayDeviceAccess$TimerClient */
    /* @28 */	jint displayId;
    /* @32 */	struct Java_com_sun_midp_lcdui_DisplayDeviceAccess * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_midp_lcdui_DisplayEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_RepaintEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/RepaintEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent1;
    /* @12 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent2;
    /* @16 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST pooledEvent3;
    /* @20 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST queuedEvent;
    /* @24 */	struct Java_com_sun_midp_lcdui_RepaintEvent * JVM_FIELD_CONST eventInProcess;
};

struct Java_com_sun_midp_lcdui_DisplayEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventHandler */
};

struct Java_com_sun_midp_lcdui_DisplayEventHandlerFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/DisplayEventHandlerFactory */
};

struct Java_com_sun_midp_lcdui_LCDUIEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/lcdui/LCDUIEvent */
    /* @12 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST changedItem;
    /* @16 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST nextScreen;
    /* @20 */	struct Java_com_sun_midp_lcdui_DisplayEventConsumer * JVM_FIELD_CONST display;
    /* @24 */	jint minorCode;
    /* @28 */	jboolean hasForeground;
    /* @29 */	jbyte ___pad431;
    /* @30 */	jbyte ___pad432;
    /* @31 */	jbyte ___pad433;
};

struct Java_com_sun_midp_lcdui_EventConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/EventConstants */
};

struct Java_com_sun_midp_lcdui_GameMap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/GameMap */
};

struct Java_com_sun_midp_lcdui_ItemEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/ItemEventConsumer */
};

struct Java_com_sun_midp_lcdui_LCDUIEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/LCDUIEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_ItemEventConsumer * JVM_FIELD_CONST itemEventConsumer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_lcdui_PhoneDial {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/PhoneDial */
};

struct Java_com_sun_midp_lcdui_RepaintEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/events/Event */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_com_sun_midp_events_Event * JVM_FIELD_CONST next;
    /* com/sun/midp/lcdui/RepaintEvent */
    /* @12 */	jint paintX1;
    /* @16 */	jint paintY1;
    /* @20 */	jint paintX2;
    /* @24 */	jint paintY2;
    /* @28 */	struct Java_java_lang_Object * JVM_FIELD_CONST paintTarget;
    /* @32 */	jint perUseID;
    /* @36 */	struct Java_com_sun_midp_lcdui_DisplayEventConsumer * JVM_FIELD_CONST display;
};

struct Java_com_sun_midp_lcdui_SystemAlert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad434;
    /* @30 */	jbyte ___pad435;
    /* @31 */	jbyte ___pad436;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
    /* com/sun/midp/lcdui/SystemAlert */
    /* @72 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @76 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
};

struct Java_com_sun_midp_lcdui_TextInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextInfo */
    /*  @4 */	jint numLines;
    /*  @8 */	jint visLines;
    /* @12 */	jint topVis;
    /* @16 */	jint cursorLine;
    /* @20 */	jint_array * JVM_FIELD_CONST lineStart;
    /* @24 */	jint_array * JVM_FIELD_CONST lineEnd;
    /* @28 */	jint height;
    /* @32 */	jboolean isModified;
    /* @33 */	jboolean scrollY;
    /* @34 */	jboolean scrollX;
    /* @35 */	jbyte ___pad437;
};

struct Java_com_sun_midp_lcdui_Text {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/Text */
};

struct Java_com_sun_midp_lcdui_TextPolicy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/lcdui/TextPolicy */
};

struct Java_com_sun_midp_log_LogChannels {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/LogChannels */
};

struct Java_com_sun_midp_log_Logging {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/log/Logging */
};

struct Java_com_sun_midp_main_MIDletExecuteEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletExecuteEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
    /*  @8 */	jint amsIsolateId;
};

struct Java_com_sun_midp_main_StartMIDletMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/StartMIDletMonitor */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet;
    /* @12 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST isolate;
};

struct Java_com_sun_midp_main_AmsUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AmsUtil */
};

struct Java_com_sun_midp_main_AppImageWriter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AppImageWriter */
};

struct Java_com_sun_midp_main_AppIsolateMIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/AppIsolateMIDletSuiteLoader */
};

struct Java_com_sun_midp_main_CommandState {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/CommandState */
    /*  @4 */	jint status;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteID;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midletClassName;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST lastSuiteID;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST lastMidletClassName;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
    /* @36 */	jboolean logoDisplayed;
    /* @37 */	jbyte ___pad438;
    /* @38 */	jbyte ___pad439;
    /* @39 */	jbyte ___pad440;
};

struct Java_com_sun_midp_main_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/Configuration */
};

struct Java_com_sun_midp_main_ExecuteMIDletEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/ExecuteMIDletEventListener */
    /*  @4 */	jint externalAppId;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST midlet;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST displayName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST arg0;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST arg1;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST arg2;
};

struct Java_com_sun_midp_main_IndicatorManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IndicatorManager */
};

struct Java_com_sun_midp_main_IsolateMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateMonitor */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST isolates;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
};

struct Java_com_sun_midp_main_IsolateMonitorListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/IsolateMonitorListener */
};

struct Java_com_sun_midp_main_TerminationNotifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/TerminationNotifier */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST midlet;
    /*  @8 */	struct Java_com_sun_cldc_isolate_Isolate * JVM_FIELD_CONST isolate;
    /* @12 */	struct Java_com_sun_midp_main_IsolateMonitor * JVM_FIELD_CONST parent;
};

struct Java_com_sun_midp_main_MIDletAppImageGenerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletAppImageGenerator */
};

struct Java_com_sun_midp_main_MIDletAppImageGeneratorBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletAppImageGeneratorBase */
};

struct Java_com_sun_midp_main_MIDletControllerEventConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventConsumer */
};

struct Java_com_sun_midp_main_MIDletControllerEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletControllerEventListener */
    /*  @4 */	struct Java_com_sun_midp_main_MIDletControllerEventConsumer * JVM_FIELD_CONST midletControllerEventConsumer;
};

struct Java_com_sun_midp_main_MIDletDestroyTimer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletDestroyTimer */
};

struct Java_com_sun_midp_main_TerminateMIDlet {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* com/sun/midp/main/TerminateMIDlet */
    /* @28 */	struct Java_com_sun_midp_main_MIDletProxy * JVM_FIELD_CONST mp;
    /* @32 */	struct Java_com_sun_midp_main_MIDletProxyList * JVM_FIELD_CONST mpl;
};

struct Java_com_sun_midp_midlet_MIDletEventProducer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventProducer */
    /*  @4 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_com_sun_midp_main_MIDletProxyUtils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletProxyUtils */
};

struct Java_com_sun_midp_main_MIDletSuiteLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletSuiteLoader */
};

struct Java_com_sun_midp_main_MIDletSuiteVerifier {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/main/MIDletSuiteVerifier */
};

struct Java_com_sun_midp_midlet_MIDletEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/midlet/MIDletEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_javax_microedition_midlet_MIDletStateChangeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/midlet/MIDletStateChangeException */
};

struct Java_com_sun_midp_payment_PAPICleanUp {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/payment/PAPICleanUp */
};

struct Java_com_sun_midp_pki_Utils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/pki/Utils */
};

struct Java_com_sun_midp_publickeystore_Storage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
};

struct Java_com_sun_midp_publickeystore_OutputStorage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/Storage */
    /* com/sun/midp/publickeystore/OutputStorage */
    /*  @4 */	struct Java_java_io_DataOutputStream * JVM_FIELD_CONST out;
};

struct Java_com_sun_midp_publickeystore_PublicKeyStoreBuilderBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/publickeystore/PublicKeyStore */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST __dup1__keyList;
    /* com/sun/midp/publickeystore/PublicKeyStoreBuilderBase */
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST keyList;
};

struct Java_com_sun_midp_rms_AbstractRecordStoreFile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/AbstractRecordStoreFile */
};

struct Java_com_sun_midp_rms_AbstractRecordStoreImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/AbstractRecordStoreImpl */
};

struct Java_com_sun_midp_rms_IntToIntMapper {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/IntToIntMapper */
    /*  @4 */	jint_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint_array * JVM_FIELD_CONST elementKey;
    /* @12 */	jint elementCount;
    /* @16 */	jint capacityIncrement;
    /* @20 */	jint defaultValue;
};

struct Java_com_sun_midp_rms_OffsetCache {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/IntToIntMapper */
    /*  @4 */	jint_array * JVM_FIELD_CONST elementData;
    /*  @8 */	jint_array * JVM_FIELD_CONST elementKey;
    /* @12 */	jint elementCount;
    /* @16 */	jint capacityIncrement;
    /* @20 */	jint defaultValue;
    /* com/sun/midp/rms/OffsetCache */
    /* @24 */	jint LastSeenOffset;
};

struct Java_com_sun_midp_rms_RMSConfig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RMSConfig */
};

struct Java_com_sun_midp_rms_RecordStoreFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreFactory */
};

struct Java_com_sun_midp_rms_RecordStoreFile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreFile */
    /*  @4 */	jint handle;
};

struct Java_com_sun_midp_rms_RecordStoreIndex {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreIndex */
    /*  @4 */	struct Java_com_sun_midp_rms_AbstractRecordStoreImpl * JVM_FIELD_CONST recordStore;
    /*  @8 */	struct Java_com_sun_midp_rms_AbstractRecordStoreFile * JVM_FIELD_CONST dbFile;
    /* @12 */	struct Java_com_sun_midp_rms_OffsetCache * JVM_FIELD_CONST recordIdOffsets;
};

struct Java_com_sun_midp_rms_RecordStoreImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreImpl */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST compactBuffer;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST suiteID;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST rsLock;
    /* @16 */	jbyte_array * JVM_FIELD_CONST dbHeader;
    /* @20 */	struct Java_com_sun_midp_rms_RecordStoreIndex * JVM_FIELD_CONST dbIndex;
    /* @24 */	struct Java_com_sun_midp_rms_RecordStoreFile * JVM_FIELD_CONST dbFile;
};

struct Java_javax_microedition_rms_RecordStoreNotFoundException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreNotFoundException */
};

struct Java_javax_microedition_rms_RecordStoreFullException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreFullException */
};

struct Java_javax_microedition_rms_InvalidRecordIDException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/InvalidRecordIDException */
};

struct Java_com_sun_midp_rms_RecordStoreUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/rms/RecordStoreUtil */
};

struct Java_com_sun_midp_security_PermissionDialog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionDialog */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /*  @8 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST yesCmd;
    /* @12 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST noCmd;
    /* @16 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @20 */	jboolean answer;
    /* @21 */	jbyte ___pad441;
    /* @22 */	jbyte ___pad442;
    /* @23 */	jbyte ___pad443;
};

struct Java_com_sun_midp_security_PermissionSpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/PermissionSpec */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_com_sun_midp_security_PermissionGroup * JVM_FIELD_CONST group;
};

struct Java_com_sun_midp_security_Permissions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/Permissions */
};

struct Java_com_sun_midp_security_SecurityInitializer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/security/SecurityInitializer */
};

struct Java_com_sun_midp_ssl_CipherSuiteData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/CipherSuiteData */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST clientMACSecret;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST serverMACSecret;
    /* @12 */	jbyte_array * JVM_FIELD_CONST clientKey;
    /* @16 */	jbyte_array * JVM_FIELD_CONST serverKey;
    /* @20 */	jbyte_array * JVM_FIELD_CONST clientIV;
    /* @24 */	jbyte_array * JVM_FIELD_CONST serverIV;
    /* @28 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST clientBulkKey;
    /* @32 */	struct Java_com_sun_midp_crypto_SecretKey * JVM_FIELD_CONST serverBulkKey;
    /* @36 */	jint digestLength;
    /* @40 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST encodeDigest;
    /* @44 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST decodeDigest;
    /* @48 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST encodeCipher;
    /* @52 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST decodeCipher;
    /* @56 */	jint padLength;
    /* @60 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST md;
    /* @64 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST sd;
    /* @68 */	jbyte_array * JVM_FIELD_CONST keyBlock;
    /* @72 */	jbyte suiteType;
    /* @73 */	jbyte ___pad444;
    /* @74 */	jbyte ___pad445;
    /* @75 */	jbyte ___pad446;
};

struct Java_com_sun_midp_ssl_Session {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Session */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /*  @8 */	jint port;
    /* @12 */	jbyte_array * JVM_FIELD_CONST id;
    /* @16 */	jbyte_array * JVM_FIELD_CONST master;
    /* @20 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST cert;
};

struct Java_com_sun_midp_ssl_Handshake {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/Handshake */
    /*  @4 */	struct Java_com_sun_midp_pki_CertStore * JVM_FIELD_CONST certStore;
    /*  @8 */	struct Java_com_sun_midp_ssl_Record * JVM_FIELD_CONST rec;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST peerHost;
    /* @16 */	jint peerPort;
    /* @20 */	struct Java_com_sun_midp_crypto_SecureRandom * JVM_FIELD_CONST rnd;
    /* @24 */	struct Java_com_sun_midp_ssl_Session * JVM_FIELD_CONST cSession;
    /* @28 */	jbyte_array * JVM_FIELD_CONST sSessionId;
    /* @32 */	jbyte_array * JVM_FIELD_CONST crand;
    /* @36 */	jbyte_array * JVM_FIELD_CONST srand;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST negSuiteName;
    /* @44 */	jbyte_array * JVM_FIELD_CONST preMaster;
    /* @48 */	jbyte_array * JVM_FIELD_CONST master;
    /* @52 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST eKey;
    /* @56 */	struct Java_com_sun_midp_pki_X509Certificate * JVM_FIELD_CONST sCert;
    /* @60 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST ourMD5;
    /* @64 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST ourSHA;
    /* @68 */	jint start;
    /* @72 */	jint nextMsgStart;
    /* @76 */	jint cnt;
    /* @80 */	jbyte ver;
    /* @81 */	jbyte role;
    /* @82 */	jbyte negSuite;
    /* @83 */	jbyte gotCertReq;
};

struct Java_com_sun_midp_ssl_MAC {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
};

struct Java_com_sun_midp_ssl_RecordEncoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
    /* com/sun/midp/ssl/RecordEncoder */
    /* @28 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_ssl_RecordDecoder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/MAC */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST macSecret;
    /*  @8 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST digest;
    /* @12 */	jint digestLength;
    /* @16 */	jint padLength;
    /* @20 */	jlong sequenceNumber;
    /* com/sun/midp/ssl/RecordDecoder */
    /* @28 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_com_sun_midp_ssl_SSLSecurityInfo {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/ssl/SSLSecurityInfo */
    /*  @4 */	struct Java_com_sun_midp_ssl_SSLStreamConnection * JVM_FIELD_CONST parent;
};

struct Java_com_sun_midp_util_DateParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/DateParser */
    /*  @4 */	jint year;
    /*  @8 */	jint month;
    /* @12 */	jint day;
    /* @16 */	jint hour;
    /* @20 */	jint minute;
    /* @24 */	jint second;
    /* @28 */	jint milli;
    /* @32 */	jint tzoffset;
    /* @36 */	jint_array * JVM_FIELD_CONST days_in_month;
    /* @40 */	jobject_array * JVM_FIELD_CONST month_shorts;
    /* @44 */	jobject_array * JVM_FIELD_CONST weekday_shorts;
};

struct Java_com_sun_midp_util_ResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/util/ResourceHandler */
};

struct Java_com_sun_midp_wma_WMACleanupMonitor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/wma/WMACleanupMonitor */
};

struct Java_com_sun_mmedia_MIDletPauseListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MIDletPauseListener */
};

struct Java_com_sun_mmedia_PlayerEventQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/mmedia/PlayerEventQueue */
    /* @28 */	struct Java_com_sun_mmedia_ABBBasicPlayer * JVM_FIELD_CONST p;
    /* @32 */	struct Java_com_sun_mmedia_EventQueueEntry * JVM_FIELD_CONST evt;
};

struct Java_javax_microedition_media_Player {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Player */
};

struct Java_com_sun_mmedia_ABBBasicPlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/ABBBasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	jint eventQueueSize;
    /* @44 */	struct Java_java_io_InputStream * JVM_FIELD_CONST source;
    /* @48 */	jboolean EOM;
    /* @49 */	jboolean loopAfterEOM;
    /* @50 */	jboolean listenersModified;
    /* @51 */	jboolean isTrusted;
    /* @52 */	jboolean closedDelivered;
    /* @53 */	jbyte ___pad447;
    /* @54 */	jbyte ___pad448;
    /* @55 */	jbyte ___pad449;
};

struct Java_javax_microedition_media_Control {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Control */
};

struct Java_javax_microedition_media_Controllable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Controllable */
};

struct Java_javax_microedition_media_PlayerListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/PlayerListener */
};

struct Java_javax_microedition_media_MediaException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/media/MediaException */
};

struct Java_com_sun_mmedia_Configuration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
};

struct Java_com_sun_mmedia_PCMAudioOut {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/PCMAudioOut */
};

struct Java_com_sun_mmedia_VideoRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/VideoRenderer */
};

struct Java_com_sun_mmedia_TonePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/TonePlayer */
};

struct Java_com_sun_mmedia_ImageAccess {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/ImageAccess */
};

struct Java_com_sun_mmedia_DefaultConfiguration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
    /* com/sun/mmedia/DefaultConfiguration */
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedProtocols;
    /* @24 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedContentTypes;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST nullContentTypes;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST captureContentTypes;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST deviceContentTypes;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST fileContentTypes;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST httpContentTypes;
    /* @48 */	jboolean needAMMS;
    /* @49 */	jboolean needQSound;
    /* @50 */	jbyte ___pad450;
    /* @51 */	jbyte ___pad451;
};

struct Java_com_sun_mmedia_CougarQSoundAbbConfig {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/Configuration */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST handlers;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST processors;
    /* @12 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mimeTypes;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST properties;
    /* com/sun/mmedia/DefaultConfiguration */
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedProtocols;
    /* @24 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST supportedContentTypes;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST nullContentTypes;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST captureContentTypes;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST deviceContentTypes;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST fileContentTypes;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST httpContentTypes;
    /* @48 */	jboolean needAMMS;
    /* @49 */	jboolean needQSound;
    /* @50 */	jbyte ___pad452;
    /* @51 */	jbyte ___pad453;
    /* com/sun/mmedia/CougarQSoundAbbConfig */
};

struct Java_com_sun_mmedia_QSoundSynthPerformance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundSynthPerformance */
    /*  @4 */	jint qsmPeer;
    /*  @8 */	jint spPeer;
    /* @12 */	jint gmPeer;
    /* @16 */	jint tchnl;
};

struct Java_com_sun_mmedia_QSoundTonePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundTonePlayer */
    /*  @4 */	struct Java_com_sun_mmedia_QSoundSynthPerformance * JVM_FIELD_CONST qsSP;
};

struct Java_com_sun_mmedia_EventQueueEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/EventQueueEntry */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST data;
    /* @12 */	struct Java_com_sun_mmedia_EventQueueEntry * JVM_FIELD_CONST link;
};

struct Java_com_sun_mmedia_MMEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/MMEventHandler */
};

struct Java_com_sun_mmedia_QSoundABBVolumeCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundABBVolumeCtrl */
    /*  @4 */	jint peer;
    /*  @8 */	struct Java_com_sun_mmedia_ABBBasicPlayer * JVM_FIELD_CONST player;
};

struct Java_com_sun_mmedia_QSoundMIDIPlayBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIPlayBase */
    /*  @4 */	jint qsMIDI;
    /*  @8 */	jint globMan;
    /* @12 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
    /* @16 */	jint loopCount;
    /* @20 */	jint currentLoopCount;
    /* @24 */	jint lastLoopCount;
    /* @28 */	jboolean opened;
    /* @29 */	jbyte ___pad454;
    /* @30 */	jbyte ___pad455;
    /* @31 */	jbyte ___pad456;
};

struct Java_com_sun_mmedia_QSoundABBMIDIPlayControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundMIDIPlayBase */
    /*  @4 */	jint qsMIDI;
    /*  @8 */	jint globMan;
    /* @12 */	struct Java_javax_microedition_media_Player * JVM_FIELD_CONST player;
    /* @16 */	jint loopCount;
    /* @20 */	jint currentLoopCount;
    /* @24 */	jint lastLoopCount;
    /* @28 */	jboolean opened;
    /* @29 */	jbyte ___pad457;
    /* @30 */	jbyte ___pad458;
    /* @31 */	jbyte ___pad459;
    /* com/sun/mmedia/QSoundABBMIDIPlayControl */
    /* @32 */	struct Java_com_sun_mmedia_QSoundABBVolumeCtrl * JVM_FIELD_CONST vc;
};

struct Java_javax_microedition_media_control_VolumeControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/VolumeControl */
};

struct Java_com_sun_mmedia_QSoundABBToneSequencePlayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/ABBBasicPlayer */
    /*  @4 */	jint state;
    /*  @8 */	jint loopCountSet;
    /* @12 */	jint loopCount;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST listeners;
    /* @20 */	struct Java_com_sun_mmedia_PlayerEventQueue * JVM_FIELD_CONST eventQueue;
    /* @24 */	struct Java_java_lang_Object * JVM_FIELD_CONST evtLock;
    /* @28 */	jint pID;
    /* @32 */	jobject_array * JVM_FIELD_CONST control_names;
    /* @36 */	jint_array * JVM_FIELD_CONST permissions;
    /* @40 */	jint eventQueueSize;
    /* @44 */	struct Java_java_io_InputStream * JVM_FIELD_CONST source;
    /* @48 */	jboolean EOM;
    /* @49 */	jboolean loopAfterEOM;
    /* @50 */	jboolean listenersModified;
    /* @51 */	jboolean isTrusted;
    /* @52 */	jboolean closedDelivered;
    /* @53 */	jbyte ___pad460;
    /* @54 */	jbyte ___pad461;
    /* @55 */	jbyte ___pad462;
    /* com/sun/mmedia/QSoundABBToneSequencePlayer */
    /* @56 */	struct Java_com_sun_mmedia_QSoundABBMIDIPlayControl * JVM_FIELD_CONST qsmc;
    /* @60 */	struct Java_java_lang_Object * JVM_FIELD_CONST playLock;
    /* @64 */	struct Java_java_lang_Thread * JVM_FIELD_CONST playThread;
    /* @68 */	struct Java_com_sun_mmedia_QSoundABBToneCtrl * JVM_FIELD_CONST tctrl;
    /* @72 */	jint bufferSize;
    /* @76 */	jboolean stopped;
    /* @77 */	jbyte ___pad463;
    /* @78 */	jbyte ___pad464;
    /* @79 */	jbyte ___pad465;
};

struct Java_javax_microedition_media_control_ToneControl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/control/ToneControl */
};

struct Java_com_sun_mmedia_QSoundABBToneCtrl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundABBToneCtrl */
    /*  @4 */	struct Java_com_sun_mmedia_QSoundABBToneSequencePlayer * JVM_FIELD_CONST qstsp;
};

struct Java_com_sun_mmedia_QSoundConnectable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundConnectable */
};

struct Java_com_sun_mmedia_QSoundGlobalEffectModule {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundGlobalEffectModule */
    /*  @4 */	jint peer;
    /*  @8 */	jint gmPeer;
    /* @12 */	jint gmMIDIPeer;
};

struct Java_com_sun_mmedia_QSoundRenderThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* com/sun/mmedia/QSoundRenderThread */
    /* @28 */	jint gm;
    /* @32 */	jboolean keepRendering;
    /* @33 */	jbyte ___pad466;
    /* @34 */	jbyte ___pad467;
    /* @35 */	jbyte ___pad468;
};

struct Java_com_sun_mmedia_QSoundHiddenManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/mmedia/QSoundHiddenManager */
};

struct Java_com_sun_perseus_model_FontFace {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad469;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad470;
    /* @75 */	jbyte ___pad471;
    /* com/sun/perseus/model/FontFace */
    /* @76 */	jobject_array * JVM_FIELD_CONST fontFamilies;
    /* @80 */	jint fontStyles;
    /* @84 */	jint fontWeights;
    /* @88 */	jfloat_array * JVM_FIELD_CONST fontSizes;
    /* @92 */	jfloat unitsPerEm;
    /* @96 */	struct Java_com_sun_perseus_model_Font * JVM_FIELD_CONST font;
    /* @100 */	jfloat emSquareScale;
};

struct Java_com_sun_perseus_model_ModelNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad472;
};

struct Java_com_sun_perseus_model_UpdateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/UpdateListener */
};

struct Java_com_sun_perseus_model_DocumentNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad473;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/Viewport */
    /* @36 */	jint width;
    /* @40 */	jint height;
    /* @44 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* @52 */	jint zoomAndPan;
    /* com/sun/perseus/model/DocumentNode */
    /* @56 */	jfloat pxMMSize;
    /* @60 */	jfloat_array * JVM_FIELD_CONST upt;
    /* @64 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST namespaceMap;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST unknownTraitsNS;
    /* @72 */	struct Java_com_sun_perseus_parser_ClockParser * JVM_FIELD_CONST clockParser;
    /* @76 */	struct Java_com_sun_perseus_parser_LengthParser * JVM_FIELD_CONST lengthParser;
    /* @80 */	struct Java_com_sun_perseus_parser_TimeConditionParser * JVM_FIELD_CONST timeConditionParser;
    /* @84 */	struct Java_com_sun_perseus_parser_NumberListParser * JVM_FIELD_CONST numberListParser;
    /* @88 */	struct Java_com_sun_perseus_parser_TransformListParser * JVM_FIELD_CONST transformListParser;
    /* @92 */	struct Java_com_sun_perseus_parser_ColorParser * JVM_FIELD_CONST colorParser;
    /* @96 */	struct Java_com_sun_perseus_parser_ViewBoxParser * JVM_FIELD_CONST viewBoxParser;
    /* @100 */	struct Java_com_sun_perseus_parser_PathParser * JVM_FIELD_CONST pathParser;
    /* @104 */	struct Java_com_sun_perseus_parser_UnicodeParser * JVM_FIELD_CONST unicodeParser;
    /* @108 */	struct Java_com_sun_perseus_model_ImageLoader * JVM_FIELD_CONST imageLoader;
    /* @112 */	struct Java_com_sun_perseus_model_FontFace * JVM_FIELD_CONST defaultFontFace;
    /* @116 */	struct Java_org_w3c_dom_DOMException * JVM_FIELD_CONST delayedException;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST defaultNamespaceURI;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST docURI;
    /* @128 */	jobject_array * JVM_FIELD_CONST initialFontFaces;
    /* @132 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST fontFaceDB;
    /* @136 */	struct Java_java_util_Vector * JVM_FIELD_CONST activeTraitAnims;
    /* @140 */	struct Java_java_util_Vector * JVM_FIELD_CONST activeMediaElements;
    /* @144 */	struct Java_com_sun_perseus_model_EventSupport * JVM_FIELD_CONST eventSupport;
    /* @148 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST updateListener;
    /* @152 */	struct Java_com_sun_perseus_util_RunnableQueue * JVM_FIELD_CONST updateQueue;
    /* @156 */	struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableHandler * JVM_FIELD_CONST runHandler;
    /* @160 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST idToElement;
    /* @164 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST reservedIds;
    /* @168 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST prefixes;
    /* @172 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST namespaces;
    /* @176 */	struct Java_com_sun_perseus_model_TimeContainerRootSupport * JVM_FIELD_CONST timeContainerRootSupport;
    /* @180 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST unresolvedIDRefs;
    /* @184 */	struct Java_java_util_Vector * JVM_FIELD_CONST animations;
    /* @188 */	struct Java_com_sun_perseus_model_ModelEvent * JVM_FIELD_CONST engineEvent;
    /* @192 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST hitChunkTxf;
    /* @196 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST bboxChunkTxf;
    /* @200 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintChunkTxf;
    /* @204 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintGlyphTxf;
    /* @208 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST bboxGlyphTxf;
    /* @212 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST hitGlyphTxf;
    /* @216 */	jboolean playing;
    /* @217 */	jbyte ___pad474;
    /* @218 */	jbyte ___pad475;
    /* @219 */	jbyte ___pad476;
};

struct Java_com_sun_perseus_builder_DefaultFontFace {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/DefaultFontFace */
};

struct Java_com_sun_perseus_model_UpdateAdapter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/UpdateAdapter */
    /*  @4 */	struct Java_java_lang_Exception * JVM_FIELD_CONST loadingFailedException;
    /*  @8 */	jboolean loadComplete;
    /*  @9 */	jboolean loadingFailed;
    /* @10 */	jboolean loadStarting;
    /* @11 */	jbyte ___pad477;
};

struct Java_com_sun_perseus_model_ElementNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad478;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad479;
    /* @75 */	jbyte ___pad480;
};

struct Java_com_sun_perseus_builder_ModelBuilder {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/xml/sax/helpers/DefaultHandler */
    /* com/sun/perseus/builder/ModelBuilder */
    /*  @4 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST currentElement;
    /*  @8 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST modelRoot;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST entityStreams;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST pendingPrefixMapping;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST pendingPrefixMappingCache;
};

struct Java_org_w3c_dom_Element {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/Element */
};

struct Java_com_sun_perseus_model_CompositeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad481;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
};

struct Java_com_sun_perseus_platform_MessagesSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/MessagesSupport */
};

struct Java_com_sun_perseus_builder_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/Messages */
};

struct Java_com_sun_perseus_builder_ModelBuilder_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$1 */
    /*  @4 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_parser_ClockParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/ClockParser */
    /* @16 */	jlong millis;
};

struct Java_com_sun_perseus_parser_LengthParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/LengthParser */
};

struct Java_com_sun_perseus_parser_TimeConditionParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/ClockParser */
    /* @16 */	jlong millis;
    /* com/sun/perseus/parser/TimeConditionParser */
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST conditions;
    /* @28 */	struct Java_com_sun_perseus_model_TimedElementNode * JVM_FIELD_CONST ten;
    /* @32 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST tes;
    /* @36 */	jboolean isBegin;
    /* @37 */	jbyte ___pad482;
    /* @38 */	jbyte ___pad483;
    /* @39 */	jbyte ___pad484;
};

struct Java_com_sun_perseus_parser_NumberListParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/NumberListParser */
};

struct Java_com_sun_perseus_parser_TransformListParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/TransformListParser */
    /* @16 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
};

struct Java_com_sun_perseus_parser_ColorParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/ColorParser */
};

struct Java_com_sun_perseus_parser_ViewBoxParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/ViewBoxParser */
};

struct Java_com_sun_perseus_parser_PathParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
    /* com/sun/perseus/parser/PathParser */
    /* @16 */	jfloat currentX;
    /* @20 */	jfloat currentY;
    /* @24 */	jfloat lastMoveToX;
    /* @28 */	jfloat lastMoveToY;
    /* @32 */	jfloat smoothQCenterX;
    /* @36 */	jfloat smoothQCenterY;
    /* @40 */	jfloat smoothCCenterX;
    /* @44 */	jfloat smoothCCenterY;
    /* @48 */	struct Java_com_sun_perseus_j2d_Path * JVM_FIELD_CONST p;
};

struct Java_com_sun_perseus_parser_UnicodeParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/UnicodeParser */
};

struct Java_com_sun_perseus_model_EventSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/EventSupport */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST allListeners;
    /*  @8 */	jobject_array * JVM_FIELD_CONST freezeList;
};

struct Java_com_sun_perseus_model_TimeContainerRootSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimedElementSupport */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /*  @8 */	jint state;
    /* @12 */	jint curIter;
    /* @16 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST dur;
    /* @20 */	jfloat repeatCount;
    /* @24 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST repeatDur;
    /* @28 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST implicitDuration;
    /* @32 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST min;
    /* @36 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST max;
    /* @40 */	jint restart;
    /* @44 */	jint fillBehavior;
    /* @48 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainer;
    /* @52 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST currentInterval;
    /* @56 */	jlong __dup1__lastSampleTime;
    /* @64 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleDur;
    /* @68 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST previousInterval;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginInstances;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST endInstances;
    /* @80 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginConditions;
    /* @84 */	struct Java_java_util_Vector * JVM_FIELD_CONST endConditions;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @92 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
    /* @96 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST animationElement;
    /* @100 */	jboolean playFill;
    /* @101 */	jboolean timingUpdate;
    /* @102 */	jboolean seeking;
    /* @103 */	jbyte ___pad485;
    /* com/sun/perseus/model/TimeContainerSupport */
    /* @104 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleTime;
    /* @108 */	struct Java_java_util_Vector * JVM_FIELD_CONST timedElementChildren;
    /* com/sun/perseus/model/TimeContainerRootSupport */
    /* @112 */	jlong beginWallClockTime;
    /* @120 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastSampleTime;
    /* @124 */	jboolean seekingBack;
    /* @125 */	jbyte ___pad486;
    /* @126 */	jbyte ___pad487;
    /* @127 */	jbyte ___pad488;
};

struct Java_com_sun_perseus_model_ModelEvent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelEvent */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST type;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST target;
    /* @12 */	struct Java_org_w3c_dom_events_EventTarget * JVM_FIELD_CONST currentTarget;
    /* @16 */	struct Java_com_sun_perseus_model_Anchor * JVM_FIELD_CONST anchor;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /* @24 */	jint repeatCount;
    /* @28 */	jchar keyChar;
    /* @30 */	jboolean stopPropagation;
    /* @31 */	jbyte ___pad489;
};

struct Java_org_w3c_dom_svg_SVGMatrix {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGMatrix */
};

struct Java_com_sun_perseus_j2d_Transform {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Transform */
    /*  @4 */	jfloat m0;
    /*  @8 */	jfloat m1;
    /* @12 */	jfloat m2;
    /* @16 */	jfloat m3;
    /* @20 */	jfloat m4;
    /* @24 */	jfloat m5;
};

struct Java_com_sun_perseus_j2d_RGB {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RGB */
    /*  @4 */	jint rgb;
};

struct Java_com_sun_perseus_j2d_RenderGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RenderContext */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @12 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @16 */	jint_array * JVM_FIELD_CONST strokeDashArray;
    /* @20 */	jint strokeWidth;
    /* @24 */	jint strokeMiterLimit;
    /* @28 */	jint strokeDashOffset;
    /* @32 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @36 */	jfloat fontSize;
    /* @40 */	jint pack;
    /* com/sun/perseus/j2d/PiscesRenderGraphics */
    /* @44 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintTransform;
    /* @52 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @56 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST transform;
    /* @60 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST imageTransform;
    /* @64 */	jint width;
    /* @68 */	jint height;
    /* @72 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST renderingTile;
    /* @76 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST primitiveTile;
    /* @80 */	jboolean needSetTransform;
    /* @81 */	jbyte ___pad490;
    /* @82 */	jbyte ___pad491;
    /* @83 */	jbyte ___pad492;
    /* com/sun/perseus/j2d/RenderGraphics */
};

struct Java_org_w3c_dom_events_EventTarget {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/events/EventTarget */
};

struct Java_com_sun_perseus_model_Anchor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad493;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad494;
    /* @75 */	jbyte ___pad495;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @140 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Anchor */
    /* @144 */	struct Java_java_lang_String * JVM_FIELD_CONST href;
    /* @148 */	struct Java_java_lang_String * JVM_FIELD_CONST target;
};

struct Java_com_sun_perseus_model_ImageLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ImageLoader */
};

struct Java_org_w3c_dom_DOMException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* org/w3c/dom/DOMException */
    /* @12 */	jshort code;
    /* @13 */	jbyte ___pad496;
    /* @14 */	jbyte ___pad497;
};

struct Java_com_sun_perseus_util_RunnableQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST state;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST stateLock;
    /* @12 */	struct Java_com_sun_perseus_util_Scheduler * JVM_FIELD_CONST scheduler;
    /* @16 */	struct Java_com_sun_perseus_util_DoublyLinkedList * JVM_FIELD_CONST list;
    /* @20 */	struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableQueueHandler * JVM_FIELD_CONST queueHandler;
    /* @24 */	struct Java_java_lang_Thread * JVM_FIELD_CONST runnableQueueThread;
};

struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue$RunnableHandler */
};

struct Java_com_sun_perseus_model_FontFace_0004Match {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/FontFace$Match */
    /*  @4 */	struct Java_com_sun_perseus_model_FontFace * JVM_FIELD_CONST fontFace;
    /*  @8 */	jint distance;
    /* @12 */	struct Java_com_sun_perseus_model_FontFace_0004Match * JVM_FIELD_CONST next;
};

struct Java_com_sun_perseus_j2d_TextProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/TextProperties */
};

struct Java_com_sun_perseus_model_Time {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Time */
    /*  @4 */	jlong value;
};

struct Java_org_w3c_dom_Node {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/Node */
};

struct Java_org_w3c_dom_Document {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/Document */
};

struct Java_com_sun_perseus_model_Transformable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Transformable */
};

struct Java_com_sun_perseus_j2d_Box {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Box */
    /*  @4 */	jfloat x;
    /*  @8 */	jfloat y;
    /* @12 */	jfloat width;
    /* @16 */	jfloat height;
};

struct Java_org_w3c_dom_events_EventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/events/EventListener */
};

struct Java_com_sun_perseus_j2d_Tile {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Tile */
    /*  @4 */	jint x;
    /*  @8 */	jint maxX;
    /* @12 */	jint y;
    /* @16 */	jint maxY;
};

struct Java_com_sun_perseus_j2d_Path {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Path */
    /*  @4 */	jshort_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint_array * JVM_FIELD_CONST offsets;
    /* @12 */	jobject_array * JVM_FIELD_CONST data;
    /* @16 */	jint nSegments;
    /* @20 */	jint nData;
};

struct Java_com_sun_perseus_model_Viewport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad498;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/Viewport */
    /* @36 */	jint width;
    /* @40 */	jint height;
    /* @44 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* @52 */	jint zoomAndPan;
};

struct Java_com_sun_perseus_model_IDRef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/IDRef */
};

struct Java_com_sun_perseus_builder_ModelBuilder_00042 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$2 */
    /*  @4 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044ul;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST val_044startedNode;
    /* @12 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_00043 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$3 */
    /*  @4 */	struct Java_com_sun_perseus_model_CompositeNode * JVM_FIELD_CONST val_044parent;
    /*  @8 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST val_044child;
    /* @12 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_00044 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$4 */
    /*  @4 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_00045 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$5 */
    /*  @4 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_ElementNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad499;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad500;
    /* @50 */	jbyte ___pad501;
    /* @51 */	jbyte ___pad502;
};

struct Java_com_sun_perseus_model_TraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad503;
    /* @30 */	jbyte ___pad504;
    /* @31 */	jbyte ___pad505;
};

struct Java_org_w3c_dom_svg_SVGRect {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGRect */
};

struct Java_org_w3c_dom_svg_SVGPath {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGPath */
};

struct Java_org_w3c_dom_svg_SVGRGBColor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGRGBColor */
};

struct Java_com_sun_perseus_j2d_PaintServer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PaintServer */
};

struct Java_com_sun_perseus_parser_Length {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/Length */
    /*  @4 */	jint unit;
    /*  @8 */	jfloat value;
};

struct Java_com_sun_perseus_j2d_PaintTarget {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PaintTarget */
};

struct Java_org_w3c_dom_svg_SVGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGElement */
};

struct Java_com_sun_perseus_builder_ModelBuilder_00046 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$6 */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044text;
    /*  @8 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044ul;
    /* @12 */	struct Java_com_sun_perseus_builder_ModelBuilder * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_builder_ModelBuilder_00047 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$7 */
    /*  @4 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044updateListener;
    /*  @8 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST val_044root;
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST val_044fgzipIS;
};

struct Java_com_sun_perseus_builder_ModelBuilder_00048 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/ModelBuilder$8 */
    /*  @4 */	struct Java_com_sun_perseus_model_UpdateListener * JVM_FIELD_CONST val_044updateListener;
    /*  @8 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST val_044root;
    /* @12 */	struct Java_java_lang_Exception * JVM_FIELD_CONST val_044e;
};

struct Java_com_sun_perseus_builder_SVGTinyModelFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/builder/SVGTinyModelFactory */
};

struct Java_com_sun_perseus_j2d_GraphicsProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/GraphicsProperties */
};

struct Java_com_sun_pisces_LineSink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
};

struct Java_com_sun_pisces_PathSink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
};

struct Java_com_sun_perseus_j2d_HitTester {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/perseus/j2d/HitTester */
    /*  @4 */	jint windingRule;
    /*  @8 */	jint px;
    /* @12 */	jint py;
    /* @16 */	jint x0;
    /* @20 */	jint y0;
    /* @24 */	jint sx0;
    /* @28 */	jint sy0;
    /* @32 */	jint crossings;
};

struct Java_com_sun_perseus_j2d_ImageLoaderUtil_0004Base64StringStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/j2d/ImageLoaderUtil$Base64StringStream */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST str;
    /*  @8 */	jint len;
    /* @12 */	jint offset;
};

struct Java_com_sun_perseus_j2d_RasterImage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RasterImage */
    /*  @4 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /*  @8 */	jint_array * JVM_FIELD_CONST argb;
};

struct Java_com_sun_perseus_j2d_ImageLoaderUtil {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/ImageLoaderUtil */
    /*  @4 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST brokenImage;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST loadingImage;
};

struct Java_com_sun_perseus_util_Base64DecodeStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/util/Base64DecodeStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST src;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST decodeBuffer;
    /* @12 */	jbyte_array * JVM_FIELD_CONST outBuffer;
    /* @16 */	jint outOffset;
    /* @20 */	jboolean eof;
    /* @21 */	jbyte ___pad506;
    /* @22 */	jbyte ___pad507;
    /* @23 */	jbyte ___pad508;
};

struct Java_com_sun_pisces_Transform6 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Transform4 */
    /*  @4 */	jint m00;
    /*  @8 */	jint m01;
    /* @12 */	jint m10;
    /* @16 */	jint m11;
    /* com/sun/pisces/Transform6 */
    /* @20 */	jint m02;
    /* @24 */	jint m12;
};

struct Java_com_sun_perseus_j2d_PiscesRenderGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RenderContext */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @12 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @16 */	jint_array * JVM_FIELD_CONST strokeDashArray;
    /* @20 */	jint strokeWidth;
    /* @24 */	jint strokeMiterLimit;
    /* @28 */	jint strokeDashOffset;
    /* @32 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @36 */	jfloat fontSize;
    /* @40 */	jint pack;
    /* com/sun/perseus/j2d/PiscesRenderGraphics */
    /* @44 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST paintTransform;
    /* @52 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @56 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST transform;
    /* @60 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST imageTransform;
    /* @64 */	jint width;
    /* @68 */	jint height;
    /* @72 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST renderingTile;
    /* @76 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST primitiveTile;
    /* @80 */	jboolean needSetTransform;
    /* @81 */	jbyte ___pad509;
    /* @82 */	jbyte ___pad510;
    /* @83 */	jbyte ___pad511;
};

struct Java_com_sun_pisces_PiscesRenderer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/PiscesRenderer */
    /*  @4 */	jlong nativePtr;
    /* @12 */	jint_array * JVM_FIELD_CONST gcm_fractions;
    /* @16 */	jint_array * JVM_FIELD_CONST gcm_rgba;
    /* @20 */	jint gcm_cycleMethod;
    /* @24 */	struct Java_com_sun_pisces_GradientColorMap * JVM_FIELD_CONST gradientColorMap;
};

struct Java_com_sun_perseus_j2d_PaintDef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PaintDef */
};

struct Java_com_sun_perseus_j2d_LinearGradientPaintDef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/LinearGradientPaintDef */
    /*  @4 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	jfloat x0;
    /* @12 */	jfloat y0;
    /* @16 */	jfloat x1;
    /* @20 */	jfloat y1;
    /* @24 */	jfloat_array * JVM_FIELD_CONST fractions;
    /* @28 */	jint_array * JVM_FIELD_CONST frac;
    /* @32 */	jint_array * JVM_FIELD_CONST rgba;
    /* @36 */	jint_array * JVM_FIELD_CONST lrgba;
    /* @40 */	jint lastPaintOpacity;
    /* @44 */	jint cycleMethod;
    /* @48 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST gradientTransform;
    /* @52 */	jboolean isObjectBBox;
    /* @53 */	jbyte ___pad512;
    /* @54 */	jbyte ___pad513;
    /* @55 */	jbyte ___pad514;
};

struct Java_com_sun_perseus_j2d_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Messages */
};

struct Java_com_sun_perseus_j2d_TileSink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/perseus/j2d/TileSink */
    /*  @4 */	jint minX;
    /*  @8 */	jint minY;
    /* @12 */	jint maxX;
    /* @16 */	jint maxY;
};

struct Java_com_sun_pisces_Transformer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/Transformer */
    /*  @4 */	struct Java_com_sun_pisces_PathSink * JVM_FIELD_CONST output;
    /*  @8 */	jlong m00;
    /* @16 */	jlong m01;
    /* @24 */	jlong m02;
    /* @32 */	jlong m10;
    /* @40 */	jlong m11;
    /* @48 */	jlong m12;
    /* @56 */	jboolean scaleAndTranslate;
    /* @57 */	jbyte ___pad515;
    /* @58 */	jbyte ___pad516;
    /* @59 */	jbyte ___pad517;
};

struct Java_com_sun_pisces_Transform4 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Transform4 */
    /*  @4 */	jint m00;
    /*  @8 */	jint m01;
    /* @12 */	jint m10;
    /* @16 */	jint m11;
};

struct Java_com_sun_perseus_j2d_PathSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/PathSupport */
};

struct Java_com_sun_pisces_Stroker {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/Stroker */
    /*  @4 */	struct Java_com_sun_pisces_LineSink * JVM_FIELD_CONST output;
    /*  @8 */	jint lineWidth;
    /* @12 */	jint capStyle;
    /* @16 */	jint joinStyle;
    /* @20 */	jint miterLimit;
    /* @24 */	struct Java_com_sun_pisces_Transform4 * JVM_FIELD_CONST transform;
    /* @28 */	jint m00;
    /* @32 */	jint m01;
    /* @36 */	jint m10;
    /* @40 */	jint m11;
    /* @44 */	jint lineWidth2;
    /* @48 */	jlong scaledLineWidth2;
    /* @56 */	jint numPenSegments;
    /* @60 */	jint_array * JVM_FIELD_CONST pen_dx;
    /* @64 */	jint_array * JVM_FIELD_CONST pen_dy;
    /* @68 */	jboolean_array * JVM_FIELD_CONST penIncluded;
    /* @72 */	jint_array * JVM_FIELD_CONST join;
    /* @76 */	jint_array * JVM_FIELD_CONST offset;
    /* @80 */	jint_array * JVM_FIELD_CONST reverse;
    /* @84 */	jint_array * JVM_FIELD_CONST miter;
    /* @88 */	jlong miterLimitSq;
    /* @96 */	jint prev;
    /* @100 */	jint rindex;
    /* @104 */	jint sx0;
    /* @108 */	jint sy0;
    /* @112 */	jint sx1;
    /* @116 */	jint sy1;
    /* @120 */	jint x0;
    /* @124 */	jint y0;
    /* @128 */	jint x1;
    /* @132 */	jint y1;
    /* @136 */	jint mx0;
    /* @140 */	jint my0;
    /* @144 */	jint mx1;
    /* @148 */	jint my1;
    /* @152 */	jint omx;
    /* @156 */	jint omy;
    /* @160 */	jint lx0;
    /* @164 */	jint ly0;
    /* @168 */	jint lx1;
    /* @172 */	jint ly1;
    /* @176 */	jint lx0p;
    /* @180 */	jint ly0p;
    /* @184 */	jint px0;
    /* @188 */	jint py0;
    /* @192 */	jdouble m00_2_m01_2;
    /* @200 */	jdouble m10_2_m11_2;
    /* @208 */	jdouble m00_m10_m01_m11;
    /* @216 */	jboolean started;
    /* @217 */	jboolean lineToOrigin;
    /* @218 */	jboolean joinToOrigin;
    /* @219 */	jboolean joinSegment;
};

struct Java_com_sun_pisces_Dasher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/Dasher */
    /*  @4 */	struct Java_com_sun_pisces_LineSink * JVM_FIELD_CONST output;
    /*  @8 */	jint_array * JVM_FIELD_CONST dash;
    /* @12 */	jint startPhase;
    /* @16 */	jint startIdx;
    /* @20 */	jint idx;
    /* @24 */	jint phase;
    /* @28 */	jint sx;
    /* @32 */	jint sy;
    /* @36 */	jint x0;
    /* @40 */	jint y0;
    /* @44 */	jint m00;
    /* @48 */	jint m01;
    /* @52 */	jint m10;
    /* @56 */	jint m11;
    /* @60 */	struct Java_com_sun_pisces_Transform4 * JVM_FIELD_CONST transform;
    /* @64 */	jlong ldet;
    /* @72 */	jint sx1;
    /* @76 */	jint sy1;
    /* @80 */	jboolean symmetric;
    /* @81 */	jboolean firstDashOn;
    /* @82 */	jboolean starting;
    /* @83 */	jbyte ___pad518;
};

struct Java_com_sun_pisces_Flattener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/Flattener */
    /*  @4 */	struct Java_com_sun_pisces_LineSink * JVM_FIELD_CONST output;
    /*  @8 */	jint flatness;
    /* @12 */	jint flatnessSq;
    /* @16 */	jint x0;
    /* @20 */	jint y0;
};

struct Java_com_sun_pisces_PathSource {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PathSource */
};

struct Java_com_sun_pisces_PathStore {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/PathSink */
    /* com/sun/pisces/PathStore */
    /*  @4 */	jint numSegments;
    /*  @8 */	jint_array * JVM_FIELD_CONST pathData;
    /* @12 */	jint dindex;
    /* @16 */	jbyte_array * JVM_FIELD_CONST pathTypes;
    /* @20 */	jint tindex;
    /* @24 */	jint x0;
    /* @28 */	jint y0;
    /* @32 */	jint sx0;
    /* @36 */	jint sy0;
    /* @40 */	jint xp;
    /* @44 */	jint yp;
};

struct Java_com_sun_perseus_j2d_RenderContext {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RenderContext */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @12 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @16 */	jint_array * JVM_FIELD_CONST strokeDashArray;
    /* @20 */	jint strokeWidth;
    /* @24 */	jint strokeMiterLimit;
    /* @28 */	jint strokeDashOffset;
    /* @32 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @36 */	jfloat fontSize;
    /* @40 */	jint pack;
};

struct Java_com_sun_perseus_j2d_TextRenderingProperties {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/TextRenderingProperties */
};

struct Java_org_w3c_dom_svg_SVGPoint {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGPoint */
};

struct Java_com_sun_perseus_j2d_Point {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Point */
    /*  @4 */	jfloat x;
    /*  @8 */	jfloat y;
};

struct Java_com_sun_perseus_j2d_RadialGradientPaintDef {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/RadialGradientPaintDef */
    /*  @4 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	jfloat cx;
    /* @12 */	jfloat cy;
    /* @16 */	jfloat fx;
    /* @20 */	jfloat fy;
    /* @24 */	jfloat r;
    /* @28 */	jfloat_array * JVM_FIELD_CONST fractions;
    /* @32 */	jint_array * JVM_FIELD_CONST frac;
    /* @36 */	jint_array * JVM_FIELD_CONST rgba;
    /* @40 */	jint_array * JVM_FIELD_CONST lrgba;
    /* @44 */	jint lastPaintOpacity;
    /* @48 */	jint cycleMethod;
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST gradientTransform;
    /* @56 */	jboolean isObjectBBox;
    /* @57 */	jbyte ___pad519;
    /* @58 */	jbyte ___pad520;
    /* @59 */	jbyte ___pad521;
};

struct Java_org_w3c_dom_svg_SVGException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* org/w3c/dom/svg/SVGException */
    /* @12 */	jshort code;
    /* @13 */	jbyte ___pad522;
    /* @14 */	jbyte ___pad523;
};

struct Java_com_sun_perseus_midp_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/Messages */
};

struct Java_com_sun_perseus_midp_SVGCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad524;
    /* @30 */	jbyte ___pad525;
    /* @31 */	jbyte ___pad526;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad527;
    /* @38 */	jbyte ___pad528;
    /* @39 */	jbyte ___pad529;
    /* com/sun/perseus/midp/SVGCanvas */
    /* @40 */	jint lastX;
    /* @44 */	jint lastY;
    /* @48 */	jint state;
    /* @52 */	struct Java_com_sun_perseus_model_SimpleCanvasManager * JVM_FIELD_CONST canvasManager;
    /* @56 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /* @60 */	struct Java_com_sun_pisces_NativeSurface * JVM_FIELD_CONST offscreen;
    /* @64 */	struct Java_com_sun_pisces_GraphicsSurfaceDestination * JVM_FIELD_CONST gsd;
    /* @68 */	jint offscreenWidth;
    /* @72 */	jint offscreenHeight;
    /* @76 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @80 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
    /* @84 */	struct Java_javax_microedition_m2g_SVGEventListener * JVM_FIELD_CONST svgEventListener;
    /* @88 */	struct Java_com_sun_perseus_util_RunnableQueue * JVM_FIELD_CONST updateQueue;
    /* @92 */	struct Java_com_sun_perseus_model_SMILSample * JVM_FIELD_CONST smilSample;
    /* @96 */	struct Java_com_sun_perseus_model_SMILSample_0004DocumentWallClock * JVM_FIELD_CONST clock;
    /* @100 */	jfloat timeIncrement;
    /* @104 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastMouseTarget;
    /* @108 */	jboolean lastWasPressed;
    /* @109 */	jboolean ignoreCanvasUpdate;
    /* @110 */	jbyte ___pad530;
    /* @111 */	jbyte ___pad531;
};

struct Java_javax_microedition_m2g_SVGImage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableImage */
    /* javax/microedition/m2g/SVGImage */
};

struct Java_javax_microedition_m2g_SVGEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/SVGEventListener */
};

struct Java_javax_microedition_m2g_SVGAnimator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/SVGAnimator */
};

struct Java_com_sun_perseus_midp_SVGAnimatorImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/SVGAnimator */
    /* com/sun/perseus/midp/SVGAnimatorImpl */
    /*  @4 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST svgCanvas;
};

struct Java_com_sun_perseus_model_SimpleCanvasManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SimpleCanvasManager */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
    /* @12 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /* @16 */	struct Java_com_sun_perseus_model_CanvasUpdateListener * JVM_FIELD_CONST canvasUpdateListener;
    /* @20 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST clearPaint;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager * JVM_FIELD_CONST dirtyAreaManager;
    /* @28 */	jboolean canvasConsumed;
    /* @29 */	jboolean needRepaint;
    /* @30 */	jboolean isOff;
    /* @31 */	jbyte ___pad532;
};

struct Java_com_sun_perseus_midp_SVGCanvas_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$1 */
    /*  @4 */	jint val_044width;
    /*  @8 */	jint val_044height;
    /* @12 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_00042 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$2 */
    /*  @4 */	jfloat_array * JVM_FIELD_CONST val_044pt;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044eventType;
    /* @12 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_00043 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$3 */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044eventType;
    /*  @8 */	jint val_044keyCode;
    /* @12 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_00044 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$4 */
    /*  @4 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_midp_SVGCanvas_00045 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/midp/SVGCanvas$5 */
    /*  @4 */	struct Java_com_sun_perseus_midp_SVGCanvas * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_SMILSample {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SMILSample */
    /*  @4 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST doc;
    /*  @8 */	struct Java_com_sun_perseus_model_TimeContainerRootSupport * JVM_FIELD_CONST root;
    /* @12 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST currentTime;
    /* @16 */	struct Java_com_sun_perseus_model_SMILSample_0004Clock * JVM_FIELD_CONST clock;
};

struct Java_com_sun_perseus_model_SMILSample_0004DocumentWallClock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SMILSample$DocumentWallClock */
    /*  @4 */	struct Java_com_sun_perseus_model_TimeContainerRootSupport * JVM_FIELD_CONST tcrs;
    /*  @8 */	jlong lastSample;
    /* @16 */	jboolean reset;
    /* @17 */	jbyte ___pad533;
    /* @18 */	jbyte ___pad534;
    /* @19 */	jbyte ___pad535;
};

struct Java_com_sun_perseus_model_CanvasUpdateListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/CanvasUpdateListener */
};

struct Java_com_sun_perseus_model_SMILSample_0004Clock {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SMILSample$Clock */
};

struct Java_com_sun_pisces_GraphicsSurfaceDestination {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/GraphicsSurfaceDestination */
    /*  @4 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST g;
};

struct Java_com_sun_pisces_NativeSurface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeSurface */
    /*  @4 */	jlong nativePtr;
};

struct Java_com_sun_pisces_Surface {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Surface */
};

struct Java_com_sun_perseus_model_DirtyAreaManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/UpdateAdapter */
    /*  @4 */	struct Java_java_lang_Exception * JVM_FIELD_CONST loadingFailedException;
    /*  @8 */	jboolean loadComplete;
    /*  @9 */	jboolean loadingFailed;
    /* @10 */	jboolean loadStarting;
    /* @11 */	jbyte ___pad536;
    /* com/sun/perseus/model/DirtyAreaManager */
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST dirtyNodes;
    /* @16 */	struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileElement * JVM_FIELD_CONST rootTile;
    /* @20 */	struct Java_com_sun_perseus_model_Viewport * JVM_FIELD_CONST vp;
    /* @24 */	jint tileMinSize;
    /* @28 */	jint lastWidth;
    /* @32 */	jint lastHeight;
    /* @36 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST lastRG;
};

struct Java_com_sun_pisces_NativeSurface_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeSurface$1 */
};

struct Java_com_sun_pisces_SurfaceDestination {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/SurfaceDestination */
};

struct Java_com_sun_perseus_model_RefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/RefValues */
};

struct Java_com_sun_perseus_model_TimedElementSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimedElementSupport */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /*  @8 */	jint state;
    /* @12 */	jint curIter;
    /* @16 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST dur;
    /* @20 */	jfloat repeatCount;
    /* @24 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST repeatDur;
    /* @28 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST implicitDuration;
    /* @32 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST min;
    /* @36 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST max;
    /* @40 */	jint restart;
    /* @44 */	jint fillBehavior;
    /* @48 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainer;
    /* @52 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST currentInterval;
    /* @56 */	jlong lastSampleTime;
    /* @64 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleDur;
    /* @68 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST previousInterval;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginInstances;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST endInstances;
    /* @80 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginConditions;
    /* @84 */	struct Java_java_util_Vector * JVM_FIELD_CONST endConditions;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @92 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
    /* @96 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST animationElement;
    /* @100 */	jboolean playFill;
    /* @101 */	jboolean timingUpdate;
    /* @102 */	jboolean seeking;
    /* @103 */	jbyte ___pad537;
};

struct Java_com_sun_perseus_model_BaseValue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/BaseValue */
};

struct Java_com_sun_perseus_model_Segment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Segment */
};

struct Java_com_sun_perseus_model_Animation {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad538;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad539;
    /* @75 */	jbyte ___pad540;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @84 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @88 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @92 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @108 */	jint type;
    /* @112 */	jboolean hasNoEffect;
    /* @113 */	jbyte ___pad541;
    /* @114 */	jbyte ___pad542;
    /* @115 */	jbyte ___pad543;
};

struct Java_com_sun_perseus_model_TimeContainerSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimedElementSupport */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST eventTime;
    /*  @8 */	jint state;
    /* @12 */	jint curIter;
    /* @16 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST dur;
    /* @20 */	jfloat repeatCount;
    /* @24 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST repeatDur;
    /* @28 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST implicitDuration;
    /* @32 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST min;
    /* @36 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST max;
    /* @40 */	jint restart;
    /* @44 */	jint fillBehavior;
    /* @48 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainer;
    /* @52 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST currentInterval;
    /* @56 */	jlong lastSampleTime;
    /* @64 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleDur;
    /* @68 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST previousInterval;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginInstances;
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST endInstances;
    /* @80 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginConditions;
    /* @84 */	struct Java_java_util_Vector * JVM_FIELD_CONST endConditions;
    /* @88 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @92 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
    /* @96 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST animationElement;
    /* @100 */	jboolean playFill;
    /* @101 */	jboolean timingUpdate;
    /* @102 */	jboolean seeking;
    /* @103 */	jbyte ___pad544;
    /* com/sun/perseus/model/TimeContainerSupport */
    /* @104 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST simpleTime;
    /* @108 */	struct Java_java_util_Vector * JVM_FIELD_CONST timedElementChildren;
};

struct Java_com_sun_perseus_model_TimedElementNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad545;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad546;
    /* @75 */	jbyte ___pad547;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
};

struct Java_com_sun_perseus_model_TimeCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad548;
    /* @10 */	jbyte ___pad549;
    /* @11 */	jbyte ___pad550;
};

struct Java_org_w3c_dom_svg_SVGAnimationElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGAnimationElement */
};

struct Java_com_sun_perseus_model_AbstractAnimate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad551;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad552;
    /* @75 */	jbyte ___pad553;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @84 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @88 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @92 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @108 */	jint type;
    /* @112 */	jboolean hasNoEffect;
    /* @113 */	jbyte ___pad554;
    /* @114 */	jbyte ___pad555;
    /* @115 */	jbyte ___pad556;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @132 */	jint calcMode;
    /* @136 */	jint actualCalcMode;
    /* @140 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @144 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @148 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @168 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @172 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @176 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @180 */	jboolean additive;
    /* @181 */	jboolean accumulate;
    /* @182 */	jboolean isToAnimation;
    /* @183 */	jbyte ___pad557;
};

struct Java_com_sun_perseus_model_RenderingManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/RenderingManager */
    /*  @4 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST node;
    /*  @8 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST rTile;
    /* @12 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST lastRenderedTile;
    /* @16 */	struct Java_com_sun_perseus_j2d_Tile * JVM_FIELD_CONST lrtCache;
    /* @20 */	jboolean rTileDirty;
    /* @21 */	jbyte ___pad558;
    /* @22 */	jbyte ___pad559;
    /* @23 */	jbyte ___pad560;
};

struct Java_com_sun_perseus_model_AbstractRenderingNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad561;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad562;
    /* @75 */	jbyte ___pad563;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
};

struct Java_com_sun_perseus_model_AbstractRenderingNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad564;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad565;
    /* @50 */	jbyte ___pad566;
    /* @51 */	jbyte ___pad567;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @60 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @64 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @72 */	jint fillRule;
    /* @76 */	jfloat strokeWidth;
    /* @80 */	jfloat strokeMiterLimit;
    /* @84 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @88 */	jfloat strokeDashOffset;
    /* @92 */	jint pack;
    /* com/sun/perseus/model/AbstractRenderingNodeProxy */
    /* @96 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
};

struct Java_org_w3c_dom_svg_SVGLocatableElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGLocatableElement */
};

struct Java_com_sun_perseus_model_DecoratedNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DecoratedNode */
};

struct Java_com_sun_perseus_model_GraphicsNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/GraphicsNode */
};

struct Java_com_sun_perseus_model_CompositeGraphicsNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad568;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad569;
    /* @75 */	jbyte ___pad570;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
};

struct Java_com_sun_perseus_model_CompositeGraphicsNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad571;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad572;
    /* @50 */	jbyte ___pad573;
    /* @51 */	jbyte ___pad574;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @60 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @64 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @72 */	jint fillRule;
    /* @76 */	jfloat strokeWidth;
    /* @80 */	jfloat strokeMiterLimit;
    /* @84 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @88 */	jfloat strokeDashOffset;
    /* @92 */	jint pack;
};

struct Java_com_sun_perseus_model_TransformSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TransformSegment */
    /*  @4 */	jfloat_array * JVM_FIELD_CONST start;
    /*  @8 */	jfloat_array * JVM_FIELD_CONST end;
    /* @12 */	jint type;
};

struct Java_com_sun_perseus_model_FloatSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/FloatSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST start;
    /*  @8 */	jobject_array * JVM_FIELD_CONST end;
};

struct Java_com_sun_perseus_model_FloatTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad575;
    /* @30 */	jbyte ___pad576;
    /* @31 */	jbyte ___pad577;
    /* com/sun/perseus/model/FloatTraitAnim */
};

struct Java_com_sun_perseus_model_TransformTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad578;
    /* @30 */	jbyte ___pad579;
    /* @31 */	jbyte ___pad580;
    /* com/sun/perseus/model/FloatTraitAnim */
    /* com/sun/perseus/model/TransformTraitAnim */
};

struct Java_com_sun_perseus_model_AnimateMotion {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad581;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad582;
    /* @75 */	jbyte ___pad583;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @84 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @88 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @92 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @108 */	jint type;
    /* @112 */	jboolean hasNoEffect;
    /* @113 */	jbyte ___pad584;
    /* @114 */	jbyte ___pad585;
    /* @115 */	jbyte ___pad586;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @132 */	jint calcMode;
    /* @136 */	jint actualCalcMode;
    /* @140 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @144 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @148 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @168 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @172 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @176 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @180 */	jboolean additive;
    /* @181 */	jboolean accumulate;
    /* @182 */	jboolean isToAnimation;
    /* @183 */	jbyte ___pad587;
    /* com/sun/perseus/model/AnimateMotion */
    /* @184 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @188 */	jfloat_array * JVM_FIELD_CONST keyPoints;
    /* @192 */	jfloat rotate;
    /* @196 */	jfloat cosRotate;
    /* @200 */	jfloat sinRotate;
    /* @204 */	jint rotateType;
    /* @208 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST pathRefValues;
    /* @212 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST mpathRefValues;
};

struct Java_com_sun_perseus_model_MotionSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/MotionSegment */
};

struct Java_com_sun_perseus_model_LeafMotionSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/LeafMotionSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST start;
    /*  @8 */	jobject_array * JVM_FIELD_CONST end;
};

struct Java_com_sun_perseus_model_MotionTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad588;
    /* @30 */	jbyte ___pad589;
    /* @31 */	jbyte ___pad590;
    /* com/sun/perseus/model/FloatTraitAnim */
    /* com/sun/perseus/model/TransformTraitAnim */
    /* com/sun/perseus/model/MotionTraitAnim */
};

struct Java_com_sun_perseus_model_AbstractShapeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad591;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad592;
    /* @75 */	jbyte ___pad593;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
};

struct Java_com_sun_perseus_model_AbstractShapeNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad594;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad595;
    /* @50 */	jbyte ___pad596;
    /* @51 */	jbyte ___pad597;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @60 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @64 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @72 */	jint fillRule;
    /* @76 */	jfloat strokeWidth;
    /* @80 */	jfloat strokeMiterLimit;
    /* @84 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @88 */	jfloat strokeDashOffset;
    /* @92 */	jint pack;
    /* com/sun/perseus/model/AbstractRenderingNodeProxy */
    /* @96 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNodeProxy */
};

struct Java_org_w3c_dom_events_Event {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/events/Event */
};

struct Java_com_sun_perseus_model_EventBaseCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad598;
    /* @10 */	jbyte ___pad599;
    /* @11 */	jbyte ___pad600;
    /* com/sun/perseus/model/EventBaseCondition */
    /* @12 */	jlong offset;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastEventTime;
    /* @24 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST eventBase;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST eventBaseId;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST eventType;
};

struct Java_com_sun_perseus_model_AccessKeyCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad601;
    /* @10 */	jbyte ___pad602;
    /* @11 */	jbyte ___pad603;
    /* com/sun/perseus/model/EventBaseCondition */
    /* @12 */	jlong offset;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastEventTime;
    /* @24 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST eventBase;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST eventBaseId;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST eventType;
    /* com/sun/perseus/model/AccessKeyCondition */
    /* @36 */	jchar accessKey;
    /* @37 */	jbyte ___pad604;
    /* @38 */	jbyte ___pad605;
};

struct Java_com_sun_perseus_model_StructureNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad606;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad607;
    /* @75 */	jbyte ___pad608;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
};

struct Java_com_sun_perseus_model_TextNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TextNode */
};

struct Java_com_sun_perseus_model_Group {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad609;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad610;
    /* @75 */	jbyte ___pad611;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @140 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
};

struct Java_com_sun_perseus_model_StringSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/StringSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST start;
    /*  @8 */	jobject_array * JVM_FIELD_CONST end;
};

struct Java_com_sun_perseus_model_StringTraitAnim {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TraitAnim */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST traitType;
    /*  @8 */	struct Java_com_sun_perseus_model_Animation * JVM_FIELD_CONST rootAnim;
    /* @12 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST specifiedTraitValue;
    /* @28 */	jboolean active;
    /* @29 */	jbyte ___pad612;
    /* @30 */	jbyte ___pad613;
    /* @31 */	jbyte ___pad614;
    /* com/sun/perseus/model/StringTraitAnim */
    /* @32 */	jobject_array * JVM_FIELD_CONST baseValue;
};

struct Java_com_sun_perseus_model_Animate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad615;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad616;
    /* @75 */	jbyte ___pad617;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @84 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @88 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @92 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @108 */	jint type;
    /* @112 */	jboolean hasNoEffect;
    /* @113 */	jbyte ___pad618;
    /* @114 */	jbyte ___pad619;
    /* @115 */	jbyte ___pad620;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @132 */	jint calcMode;
    /* @136 */	jint actualCalcMode;
    /* @140 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @144 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @148 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @168 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @172 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @176 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @180 */	jboolean additive;
    /* @181 */	jboolean accumulate;
    /* @182 */	jboolean isToAnimation;
    /* @183 */	jbyte ___pad621;
    /* com/sun/perseus/model/Animate */
    /* @184 */	struct Java_java_lang_String * JVM_FIELD_CONST traitQName;
};

struct Java_com_sun_perseus_model_AnimateTransform {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad622;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad623;
    /* @75 */	jbyte ___pad624;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @84 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @88 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @92 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @108 */	jint type;
    /* @112 */	jboolean hasNoEffect;
    /* @113 */	jbyte ___pad625;
    /* @114 */	jbyte ___pad626;
    /* @115 */	jbyte ___pad627;
    /* com/sun/perseus/model/AbstractAnimate */
    /* @116 */	struct Java_java_lang_String * JVM_FIELD_CONST to;
    /* @120 */	struct Java_java_lang_String * JVM_FIELD_CONST from;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST by;
    /* @128 */	struct Java_java_lang_String * JVM_FIELD_CONST values;
    /* @132 */	jint calcMode;
    /* @136 */	jint actualCalcMode;
    /* @140 */	jfloat_array * JVM_FIELD_CONST keyTimes;
    /* @144 */	jobject_array * JVM_FIELD_CONST keySplines;
    /* @148 */	jobject_array * JVM_FIELD_CONST refSplines;
    /* @152 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @156 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST toRefValues;
    /* @160 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST fromRefValues;
    /* @164 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST byRefValues;
    /* @168 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST valuesRefValues;
    /* @172 */	jfloat_array * JVM_FIELD_CONST refTimes;
    /* @176 */	jfloat_array * JVM_FIELD_CONST sisp;
    /* @180 */	jboolean additive;
    /* @181 */	jboolean accumulate;
    /* @182 */	jboolean isToAnimation;
    /* @183 */	jbyte ___pad628;
    /* com/sun/perseus/model/Animate */
    /* @184 */	struct Java_java_lang_String * JVM_FIELD_CONST traitQName;
    /* com/sun/perseus/model/AnimateTransform */
};

struct Java_com_sun_perseus_model_CanvasManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SimpleCanvasManager */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
    /* @12 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /* @16 */	struct Java_com_sun_perseus_model_CanvasUpdateListener * JVM_FIELD_CONST canvasUpdateListener;
    /* @20 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST clearPaint;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager * JVM_FIELD_CONST dirtyAreaManager;
    /* @28 */	jboolean canvasConsumed;
    /* @29 */	jboolean needRepaint;
    /* @30 */	jboolean isOff;
    /* @31 */	jbyte ___pad629;
    /* com/sun/perseus/model/CanvasManager */
    /* @32 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST progressiveNode;
    /* @36 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST needLoadNode;
    /* @40 */	struct Java_com_sun_perseus_model_SMILSample * JVM_FIELD_CONST sampler;
    /* @44 */	jlong smilRate;
    /* @52 */	jboolean loading;
    /* @53 */	jbyte ___pad630;
    /* @54 */	jbyte ___pad631;
    /* @55 */	jbyte ___pad632;
};

struct Java_com_sun_perseus_model_CanvasManager_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/CanvasManager$1 */
    /*  @4 */	struct Java_com_sun_perseus_model_CanvasManager * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_CompositeMotionSegment {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/CompositeMotionSegment */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jfloat length;
    /* @12 */	jfloat_array * JVM_FIELD_CONST nSegLength;
};

struct Java_com_sun_perseus_model_ConditionalProcessing {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ConditionalProcessing */
};

struct Java_com_sun_perseus_model_DefaultImageLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST cache;
    /*  @8 */	struct Java_com_sun_perseus_j2d_ImageLoaderUtil * JVM_FIELD_CONST loaderUtil;
};

struct Java_com_sun_perseus_model_DefaultImageLoader_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader$1 */
    /*  @4 */	struct Java_com_sun_perseus_model_DefaultImageLoader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_RasterImageConsumer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/RasterImageConsumer */
};

struct Java_com_sun_perseus_model_DefaultImageLoader_0004ImageLoadRunnable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader$ImageLoadRunnable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST uri;
    /*  @8 */	struct Java_com_sun_perseus_model_RasterImageConsumer * JVM_FIELD_CONST node;
    /* @12 */	struct Java_com_sun_perseus_model_DefaultImageLoader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_DefaultImageLoader_0004ImageSetter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader$ImageSetter */
    /*  @4 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST img;
    /*  @8 */	struct Java_com_sun_perseus_model_RasterImageConsumer * JVM_FIELD_CONST node;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST uri;
};

struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableQueueHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue$RunnableQueueHandler */
};

struct Java_com_sun_perseus_model_Defs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad633;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad634;
    /* @75 */	jbyte ___pad635;
    /* com/sun/perseus/model/Defs */
};

struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileQuadrant {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Tile */
    /*  @4 */	jint x;
    /*  @8 */	jint maxX;
    /* @12 */	jint y;
    /* @16 */	jint maxY;
    /* com/sun/perseus/model/DirtyAreaManager$TileElement */
    /* @20 */	struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileQuadrant * JVM_FIELD_CONST parent;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileElement * JVM_FIELD_CONST next;
    /* @28 */	jboolean hit;
    /* @29 */	jbyte ___pad636;
    /* @30 */	jbyte ___pad637;
    /* @31 */	jbyte ___pad638;
    /* com/sun/perseus/model/DirtyAreaManager$TileQuadrant */
    /* @32 */	jobject_array * JVM_FIELD_CONST children;
};

struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/j2d/Tile */
    /*  @4 */	jint x;
    /*  @8 */	jint maxX;
    /* @12 */	jint y;
    /* @16 */	jint maxY;
    /* com/sun/perseus/model/DirtyAreaManager$TileElement */
    /* @20 */	struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileQuadrant * JVM_FIELD_CONST parent;
    /* @24 */	struct Java_com_sun_perseus_model_DirtyAreaManager_0004TileElement * JVM_FIELD_CONST next;
    /* @28 */	jboolean hit;
    /* @29 */	jbyte ___pad639;
    /* @30 */	jbyte ___pad640;
    /* @31 */	jbyte ___pad641;
};

struct Java_com_sun_perseus_model_GenericElementNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad642;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad643;
    /* @75 */	jbyte ___pad644;
    /* com/sun/perseus/model/GenericElementNode */
    /* @76 */	struct Java_java_lang_String * JVM_FIELD_CONST namespaceURI;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* @84 */	struct Java_java_lang_String * JVM_FIELD_CONST content;
};

struct Java_com_sun_perseus_model_Ellipse {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad645;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad646;
    /* @75 */	jbyte ___pad647;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/Ellipse */
    /* @136 */	jfloat x;
    /* @140 */	jfloat y;
    /* @144 */	jfloat width;
    /* @148 */	jfloat height;
    /* @152 */	jboolean isCircle;
    /* @153 */	jbyte ___pad648;
    /* @154 */	jbyte ___pad649;
    /* @155 */	jbyte ___pad650;
};

struct Java_com_sun_perseus_model_FloatRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/FloatRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jobject_array * JVM_FIELD_CONST w;
    /* @12 */	jfloat length;
    /* @16 */	jfloat_array * JVM_FIELD_CONST segLength;
};

struct Java_com_sun_perseus_model_Glyph {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad651;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad652;
    /* @75 */	jbyte ___pad653;
    /* com/sun/perseus/model/Glyph */
    /* @76 */	struct Java_com_sun_perseus_j2d_Path * JVM_FIELD_CONST d;
    /* @80 */	jfloat horizontalAdvanceX;
    /* @84 */	jfloat computedHorizontalAdvanceX;
    /* @88 */	jfloat origin;
    /* @92 */	jfloat emSquareScale;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST unicode;
    /* @100 */	jobject_array * JVM_FIELD_CONST glyphName;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
};

struct Java_com_sun_perseus_model_HKern {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad654;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad655;
    /* @75 */	jbyte ___pad656;
    /* com/sun/perseus/model/HKern */
    /* @76 */	jobject_array * JVM_FIELD_CONST u1;
    /* @80 */	jobject_array * JVM_FIELD_CONST u2;
    /* @84 */	jobject_array * JVM_FIELD_CONST g1;
    /* @88 */	jobject_array * JVM_FIELD_CONST g2;
    /* @92 */	jfloat k;
    /* @96 */	struct Java_com_sun_perseus_model_HKern * JVM_FIELD_CONST nextHKern;
};

struct Java_com_sun_perseus_model_Font {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad657;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad658;
    /* @75 */	jbyte ___pad659;
    /* com/sun/perseus/model/Font */
    /* @76 */	jfloat horizontalOriginX;
    /* @80 */	jfloat horizontalAdvanceX;
    /* @84 */	struct Java_com_sun_perseus_model_FontFace * JVM_FIELD_CONST fontFace;
    /* @88 */	struct Java_com_sun_perseus_model_Glyph * JVM_FIELD_CONST missingGlyph;
    /* @92 */	struct Java_com_sun_perseus_model_HKern * JVM_FIELD_CONST firstHKern;
    /* @96 */	struct Java_com_sun_perseus_model_HKern * JVM_FIELD_CONST lastHKern;
};

struct Java_com_sun_perseus_model_GlyphProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/GlyphProxy */
    /*  @4 */	jfloat x;
    /*  @8 */	jfloat rotate;
    /* @12 */	struct Java_com_sun_perseus_model_Glyph * JVM_FIELD_CONST proxied;
    /* @16 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST nextSibling;
    /* @20 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST prevSibling;
};

struct Java_com_sun_perseus_model_GlyphLayout {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/GlyphLayout */
    /*  @4 */	jfloat advance;
    /*  @8 */	jfloat x;
    /* @12 */	jfloat y;
    /* @16 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST firstChild;
    /* @20 */	struct Java_com_sun_perseus_model_GlyphProxy * JVM_FIELD_CONST lastChild;
    /* @24 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST prevSibling;
    /* @28 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST nextSibling;
    /* @32 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
};

struct Java_com_sun_perseus_model_Stop {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad660;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad661;
    /* @75 */	jbyte ___pad662;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/Stop */
    /* @124 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST stopColor;
    /* @128 */	jfloat stopOpacity;
    /* @132 */	jfloat offset;
};

struct Java_com_sun_perseus_model_PaintElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad663;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad664;
    /* @75 */	jbyte ___pad665;
    /* com/sun/perseus/model/PaintElement */
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @80 */	jboolean isObjectBBox;
    /* @81 */	jbyte ___pad666;
    /* @82 */	jbyte ___pad667;
    /* @83 */	jbyte ___pad668;
};

struct Java_com_sun_perseus_model_GradientElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad669;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad670;
    /* @75 */	jbyte ___pad671;
    /* com/sun/perseus/model/PaintElement */
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @80 */	jboolean isObjectBBox;
    /* @81 */	jbyte ___pad672;
    /* @82 */	jbyte ___pad673;
    /* @83 */	jbyte ___pad674;
    /* com/sun/perseus/model/GradientElement */
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintDef * JVM_FIELD_CONST computedPaint;
    /* @88 */	jfloat_array * JVM_FIELD_CONST lastColorMapFractions;
    /* @92 */	jint_array * JVM_FIELD_CONST lastColorMapRGBA;
    /* @96 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
};

struct Java_com_sun_perseus_model_ImageNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad675;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad676;
    /* @75 */	jbyte ___pad677;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/ImageNode */
    /* @136 */	jfloat x;
    /* @140 */	jfloat y;
    /* @144 */	jfloat width;
    /* @148 */	jfloat height;
    /* @152 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST image;
    /* @156 */	struct Java_java_lang_String * JVM_FIELD_CONST href;
    /* @160 */	struct Java_java_lang_String * JVM_FIELD_CONST absoluteURI;
    /* @164 */	jint align;
    /* @168 */	jboolean imageLoaded;
    /* @169 */	jbyte ___pad678;
    /* @170 */	jbyte ___pad679;
    /* @171 */	jbyte ___pad680;
};

struct Java_com_sun_perseus_model_TimeInterval {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeInterval */
    /*  @4 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST begin;
    /*  @8 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST end;
    /* @12 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastDur;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST beginDependents;
    /* @20 */	struct Java_java_util_Vector * JVM_FIELD_CONST endDependents;
};

struct Java_com_sun_perseus_model_IntervalTimeInstance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeInstance */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST time;
    /* @12 */	jboolean clearOnReset;
    /* @13 */	jboolean isBegin;
    /* @14 */	jbyte ___pad681;
    /* @15 */	jbyte ___pad682;
    /* com/sun/perseus/model/IntervalTimeInstance */
    /* @16 */	jlong offset;
    /* @24 */	struct Java_com_sun_perseus_model_TimeInterval * JVM_FIELD_CONST timeInterval;
    /* @28 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST syncBase;
    /* @32 */	jboolean isBeginSync;
    /* @33 */	jbyte ___pad683;
    /* @34 */	jbyte ___pad684;
    /* @35 */	jbyte ___pad685;
};

struct Java_com_sun_perseus_model_TimeInstance {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeInstance */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST time;
    /* @12 */	jboolean clearOnReset;
    /* @13 */	jboolean isBegin;
    /* @14 */	jbyte ___pad686;
    /* @15 */	jbyte ___pad687;
};

struct Java_com_sun_perseus_model_Line {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad688;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad689;
    /* @75 */	jbyte ___pad690;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/Line */
    /* @136 */	jfloat x1;
    /* @140 */	jfloat y1;
    /* @144 */	jfloat x2;
    /* @148 */	jfloat y2;
};

struct Java_com_sun_perseus_model_LinearGradient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad691;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad692;
    /* @75 */	jbyte ___pad693;
    /* com/sun/perseus/model/PaintElement */
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @80 */	jboolean isObjectBBox;
    /* @81 */	jbyte ___pad694;
    /* @82 */	jbyte ___pad695;
    /* @83 */	jbyte ___pad696;
    /* com/sun/perseus/model/GradientElement */
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintDef * JVM_FIELD_CONST computedPaint;
    /* @88 */	jfloat_array * JVM_FIELD_CONST lastColorMapFractions;
    /* @92 */	jint_array * JVM_FIELD_CONST lastColorMapRGBA;
    /* @96 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* com/sun/perseus/model/LinearGradient */
    /* @100 */	jfloat x1;
    /* @104 */	jfloat y1;
    /* @108 */	jfloat x2;
    /* @112 */	jfloat y2;
};

struct Java_com_sun_perseus_model_Messages {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/Messages */
};

struct Java_com_sun_perseus_model_MotionRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/MotionRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jobject_array * JVM_FIELD_CONST w;
    /* @12 */	jfloat length;
    /* @16 */	jfloat_array * JVM_FIELD_CONST nSegLength;
    /* @20 */	jfloat_array * JVM_FIELD_CONST segLength;
    /* @24 */	struct Java_com_sun_perseus_model_AnimateMotion * JVM_FIELD_CONST motion;
};

struct Java_com_sun_perseus_model_OffsetCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad697;
    /* @10 */	jbyte ___pad698;
    /* @11 */	jbyte ___pad699;
    /* com/sun/perseus/model/OffsetCondition */
    /* @12 */	jlong offset;
};

struct Java_com_sun_perseus_model_PaintElement_0004Reference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/PaintElement$Reference */
    /*  @4 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST paintType;
    /* @12 */	struct Java_com_sun_perseus_model_PaintElement * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_PaintServerReference_0004Unresolved {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/PaintServerReference$Unresolved */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /*  @8 */	struct Java_com_sun_perseus_j2d_PaintTarget * JVM_FIELD_CONST paintTarget;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST paintType;
};

struct Java_com_sun_perseus_model_PaintServerReference {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/PaintServerReference */
};

struct Java_com_sun_perseus_model_RadialGradient {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad700;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad701;
    /* @75 */	jbyte ___pad702;
    /* com/sun/perseus/model/PaintElement */
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @80 */	jboolean isObjectBBox;
    /* @81 */	jbyte ___pad703;
    /* @82 */	jbyte ___pad704;
    /* @83 */	jbyte ___pad705;
    /* com/sun/perseus/model/GradientElement */
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintDef * JVM_FIELD_CONST computedPaint;
    /* @88 */	jfloat_array * JVM_FIELD_CONST lastColorMapFractions;
    /* @92 */	jint_array * JVM_FIELD_CONST lastColorMapRGBA;
    /* @96 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* com/sun/perseus/model/RadialGradient */
    /* @100 */	jfloat cx;
    /* @104 */	jfloat cy;
    /* @108 */	jfloat r;
};

struct Java_com_sun_perseus_model_Rect {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad706;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad707;
    /* @75 */	jbyte ___pad708;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/Rect */
    /* @136 */	jfloat width;
    /* @140 */	jfloat height;
    /* @144 */	jfloat x;
    /* @148 */	jfloat y;
    /* @152 */	jfloat aw;
    /* @156 */	jfloat ah;
};

struct Java_com_sun_perseus_model_RepeatCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad709;
    /* @10 */	jbyte ___pad710;
    /* @11 */	jbyte ___pad711;
    /* com/sun/perseus/model/EventBaseCondition */
    /* @12 */	jlong offset;
    /* @20 */	struct Java_com_sun_perseus_model_Time * JVM_FIELD_CONST lastEventTime;
    /* @24 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST eventBase;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST eventBaseId;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST eventType;
    /* com/sun/perseus/model/RepeatCondition */
    /* @36 */	jint repeatCount;
};

struct Java_org_w3c_dom_svg_SVGSVGElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* org/w3c/dom/svg/SVGSVGElement */
};

struct Java_com_sun_perseus_model_SVG {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad712;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad713;
    /* @75 */	jbyte ___pad714;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/SVG */
    /* @132 */	jobject_array * JVM_FIELD_CONST viewBox;
    /* @136 */	jint align;
    /* @140 */	jfloat width;
    /* @144 */	jfloat height;
    /* @148 */	jfloat currentScale;
    /* @152 */	jfloat tx;
    /* @156 */	jfloat ty;
    /* @160 */	jfloat currentRotate;
    /* @164 */	jfloat currentTimeDelta;
};

struct Java_com_sun_perseus_model_SVGImageImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableImage */
    /* javax/microedition/m2g/SVGImage */
    /* com/sun/perseus/model/SVGImageImpl */
    /*  @4 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST documentNode;
    /*  @8 */	struct Java_com_sun_perseus_model_SVGImageLoader * JVM_FIELD_CONST svgImageLoader;
    /* @12 */	struct Java_org_w3c_dom_svg_SVGElement * JVM_FIELD_CONST lastElement;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST waitURI;
    /* @20 */	jboolean isBrokenImage;
    /* @21 */	jbyte ___pad715;
    /* @22 */	jbyte ___pad716;
    /* @23 */	jbyte ___pad717;
};

struct Java_com_sun_perseus_model_SVGImageImpl_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SVGImageImpl$1 */
    /*  @4 */	jfloat val_044seconds;
    /*  @8 */	struct Java_com_sun_perseus_model_SVGImageImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_m2g_ExternalResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ExternalResourceHandler */
};

struct Java_com_sun_perseus_model_SVGImageLoader {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/DefaultImageLoader */
    /*  @4 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST cache;
    /*  @8 */	struct Java_com_sun_perseus_j2d_ImageLoaderUtil * JVM_FIELD_CONST __dup1__loaderUtil;
    /* com/sun/perseus/model/SVGImageLoader */
    /* @12 */	struct Java_javax_microedition_m2g_ExternalResourceHandler * JVM_FIELD_CONST handler;
    /* @16 */	struct Java_com_sun_perseus_model_SVGImageImpl * JVM_FIELD_CONST svgImage;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST rasterImageConsumerTable;
    /* @24 */	struct Java_com_sun_perseus_j2d_ImageLoaderUtil * JVM_FIELD_CONST loaderUtil;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST pendingNeedsURI;
    /* @32 */	jboolean documentLoaded;
    /* @33 */	jbyte ___pad718;
    /* @34 */	jbyte ___pad719;
    /* @35 */	jbyte ___pad720;
};

struct Java_javax_microedition_m2g_ScalableImage {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableImage */
};

struct Java_com_sun_perseus_model_SVGImageLoader_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SVGImageLoader$1 */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST val_044uri;
    /*  @8 */	struct Java_com_sun_perseus_j2d_RasterImage * JVM_FIELD_CONST val_044image;
    /* @12 */	struct Java_com_sun_perseus_model_SVGImageLoader * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_Set {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad721;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad722;
    /* @75 */	jbyte ___pad723;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/Animation */
    /* @84 */	struct Java_com_sun_perseus_model_TraitAnim * JVM_FIELD_CONST traitAnim;
    /* @88 */	struct Java_com_sun_perseus_model_BaseValue * JVM_FIELD_CONST baseVal;
    /* @92 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST targetElement;
    /* @96 */	struct Java_java_lang_String * JVM_FIELD_CONST traitName;
    /* @100 */	struct Java_java_lang_String * JVM_FIELD_CONST traitNamespace;
    /* @104 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @108 */	jint type;
    /* @112 */	jboolean hasNoEffect;
    /* @113 */	jbyte ___pad724;
    /* @114 */	jbyte ___pad725;
    /* @115 */	jbyte ___pad726;
    /* com/sun/perseus/model/Set */
    /* @116 */	jobject_array * JVM_FIELD_CONST to;
    /* @120 */	struct Java_com_sun_perseus_model_RefValues * JVM_FIELD_CONST refValues;
    /* @124 */	struct Java_java_lang_String * JVM_FIELD_CONST traitQName;
};

struct Java_com_sun_perseus_model_ShapeNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad727;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad728;
    /* @75 */	jbyte ___pad729;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/AbstractRenderingNode */
    /* @124 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @128 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @132 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* com/sun/perseus/model/AbstractShapeNode */
    /* com/sun/perseus/model/ShapeNode */
    /* @136 */	struct Java_com_sun_perseus_j2d_Path * JVM_FIELD_CONST path;
    /* @140 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
};

struct Java_com_sun_perseus_model_SimpleCanvasManager_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/SimpleCanvasManager$1 */
    /*  @4 */	struct Java_com_sun_perseus_model_SimpleCanvasManager * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_perseus_model_SolidColor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad730;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad731;
    /* @75 */	jbyte ___pad732;
    /* com/sun/perseus/model/PaintElement */
    /* @76 */	struct Java_java_util_Vector * JVM_FIELD_CONST references;
    /* @80 */	jboolean isObjectBBox;
    /* @81 */	jbyte ___pad733;
    /* @82 */	jbyte ___pad734;
    /* @83 */	jbyte ___pad735;
    /* com/sun/perseus/model/SolidColor */
    /* @84 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST solidColor;
    /* @88 */	jfloat solidOpacity;
    /* @92 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST compoundColor;
};

struct Java_com_sun_perseus_model_StrictElement {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad736;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad737;
    /* @75 */	jbyte ___pad738;
    /* com/sun/perseus/model/StrictElement */
    /* @76 */	jobject_array * JVM_FIELD_CONST requiredTraits;
    /* @80 */	jobject_array * JVM_FIELD_CONST requiredTraitsNS;
    /* @84 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* @88 */	struct Java_java_lang_String * JVM_FIELD_CONST namespaceURI;
};

struct Java_com_sun_perseus_model_StringRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/StringRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jfloat_array * JVM_FIELD_CONST length;
};

struct Java_com_sun_perseus_model_StructureNodeProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad739;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad740;
    /* @50 */	jbyte ___pad741;
    /* @51 */	jbyte ___pad742;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @60 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @64 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @72 */	jint fillRule;
    /* @76 */	jfloat strokeWidth;
    /* @80 */	jfloat strokeMiterLimit;
    /* @84 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @88 */	jfloat strokeDashOffset;
    /* @92 */	jint pack;
    /* com/sun/perseus/model/StructureNodeProxy */
    /* @96 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @100 */	jfloat fontSize;
};

struct Java_com_sun_perseus_model_Switch {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad743;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad744;
    /* @75 */	jbyte ___pad745;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @140 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Switch */
};

struct Java_com_sun_perseus_model_Symbol {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad746;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad747;
    /* @75 */	jbyte ___pad748;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @140 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Symbol */
    /* @144 */	jobject_array * JVM_FIELD_CONST viewBox;
};

struct Java_com_sun_perseus_model_TimeDependent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeDependent */
};

struct Java_com_sun_perseus_model_SyncBaseCondition {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TimeCondition */
    /*  @4 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElement;
    /*  @8 */	jboolean isBegin;
    /* @9 */	jbyte ___pad749;
    /* @10 */	jbyte ___pad750;
    /* @11 */	jbyte ___pad751;
    /* com/sun/perseus/model/SyncBaseCondition */
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST syncBaseId;
    /* @16 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST syncBase;
    /* @20 */	jlong offset;
    /* @28 */	jboolean isBeginSync;
    /* @29 */	jbyte ___pad752;
    /* @30 */	jbyte ___pad753;
    /* @31 */	jbyte ___pad754;
};

struct Java_com_sun_perseus_model_Text {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad755;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad756;
    /* @75 */	jbyte ___pad757;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @140 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Text */
    /* @144 */	struct Java_java_lang_String * JVM_FIELD_CONST content;
    /* @148 */	jfloat_array * JVM_FIELD_CONST x;
    /* @152 */	jfloat_array * JVM_FIELD_CONST y;
    /* @156 */	jfloat_array * JVM_FIELD_CONST rotate;
    /* @160 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST firstChunk;
    /* @164 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST lastChunk;
    /* @168 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
};

struct Java_com_sun_perseus_model_TextProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad758;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad759;
    /* @50 */	jbyte ___pad760;
    /* @51 */	jbyte ___pad761;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @60 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @64 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @72 */	jint fillRule;
    /* @76 */	jfloat strokeWidth;
    /* @80 */	jfloat strokeMiterLimit;
    /* @84 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @88 */	jfloat strokeDashOffset;
    /* @92 */	jint pack;
    /* com/sun/perseus/model/StructureNodeProxy */
    /* @96 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @100 */	jfloat fontSize;
    /* com/sun/perseus/model/TextProxy */
    /* @104 */	struct Java_com_sun_perseus_model_RenderingManager * JVM_FIELD_CONST renderingManager;
    /* @108 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST firstChunk;
    /* @112 */	struct Java_com_sun_perseus_model_GlyphLayout * JVM_FIELD_CONST lastChunk;
};

struct Java_com_sun_perseus_model_TimeContainerNode {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad762;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad763;
    /* @75 */	jbyte ___pad764;
    /* com/sun/perseus/model/TimedElementNode */
    /* @76 */	struct Java_com_sun_perseus_model_TimedElementSupport * JVM_FIELD_CONST timedElementSupport;
    /* @80 */	struct Java_java_lang_String * JVM_FIELD_CONST localName;
    /* com/sun/perseus/model/TimeContainerNode */
    /* @84 */	struct Java_com_sun_perseus_model_TimeContainerSupport * JVM_FIELD_CONST timeContainerSupport;
};

struct Java_com_sun_perseus_model_TransformRefValues {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/TransformRefValues */
    /*  @4 */	jobject_array * JVM_FIELD_CONST segments;
    /*  @8 */	jobject_array * JVM_FIELD_CONST w;
    /* @12 */	jfloat length;
    /* @16 */	jfloat_array * JVM_FIELD_CONST segLength;
};

struct Java_com_sun_perseus_model_Use {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad765;
    /* com/sun/perseus/model/CompositeNode */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST firstChild;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST lastChild;
    /* com/sun/perseus/model/ElementNode */
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST id;
    /* @40 */	struct Java_java_lang_String * JVM_FIELD_CONST uriBase;
    /* @44 */	jobject_array * JVM_FIELD_CONST requiredFeatures;
    /* @48 */	jobject_array * JVM_FIELD_CONST requiredExtensions;
    /* @52 */	jobject_array * JVM_FIELD_CONST systemLanguage;
    /* @56 */	jint xmlSpace;
    /* @60 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST firstProxy;
    /* @64 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST lastProxy;
    /* @68 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST traitAnimsNS;
    /* @72 */	jboolean paintNeedsLoad;
    /* @73 */	jboolean buildingProxy;
    /* @74 */	jbyte ___pad766;
    /* @75 */	jbyte ___pad767;
    /* com/sun/perseus/model/CompositeGraphicsNode */
    /* @76 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @80 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @84 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @88 */	jint fillRule;
    /* @92 */	jfloat strokeWidth;
    /* @96 */	jfloat strokeMiterLimit;
    /* @100 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @104 */	jfloat strokeDashOffset;
    /* @108 */	jint pack;
    /* @112 */	jint markers;
    /* @116 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @120 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* com/sun/perseus/model/StructureNode */
    /* @124 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @128 */	jfloat fontSize;
    /* com/sun/perseus/model/Group */
    /* @132 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST transform;
    /* @136 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST motion;
    /* @140 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTransform;
    /* com/sun/perseus/model/Use */
    /* @144 */	jfloat x;
    /* @148 */	jfloat y;
    /* @152 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST proxy;
    /* @156 */	struct Java_java_lang_String * JVM_FIELD_CONST idRef;
    /* @160 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST ref;
};

struct Java_com_sun_perseus_model_UseProxy {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/model/ModelNode */
    /*  @4 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST IDENTITY;
    /*  @8 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST parent;
    /* @12 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST nextSibling;
    /* @16 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST prevSibling;
    /* @20 */	struct Java_com_sun_perseus_model_DocumentNode * JVM_FIELD_CONST ownerDocument;
    /* @24 */	jboolean conditionsMet;
    /* @25 */	jboolean canRenderState;
    /* @26 */	jboolean loaded;
    /* @27 */	jbyte ___pad768;
    /* com/sun/perseus/model/ElementNodeProxy */
    /* @28 */	struct Java_com_sun_perseus_model_ElementNode * JVM_FIELD_CONST proxied;
    /* @32 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST nextProxy;
    /* @36 */	struct Java_com_sun_perseus_model_ElementNodeProxy * JVM_FIELD_CONST prevProxy;
    /* @40 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST firstExpandedChild;
    /* @44 */	struct Java_com_sun_perseus_model_ModelNode * JVM_FIELD_CONST lastExpandedChild;
    /* @48 */	jboolean expanded;
    /* @49 */	jbyte ___pad769;
    /* @50 */	jbyte ___pad770;
    /* @51 */	jbyte ___pad771;
    /* com/sun/perseus/model/CompositeGraphicsNodeProxy */
    /* @52 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST txf;
    /* @56 */	struct Java_com_sun_perseus_j2d_Transform * JVM_FIELD_CONST inverseTxf;
    /* @60 */	struct Java_com_sun_perseus_j2d_RGB * JVM_FIELD_CONST color;
    /* @64 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST fill;
    /* @68 */	struct Java_com_sun_perseus_j2d_PaintServer * JVM_FIELD_CONST stroke;
    /* @72 */	jint fillRule;
    /* @76 */	jfloat strokeWidth;
    /* @80 */	jfloat strokeMiterLimit;
    /* @84 */	jfloat_array * JVM_FIELD_CONST strokeDashArray;
    /* @88 */	jfloat strokeDashOffset;
    /* @92 */	jint pack;
    /* com/sun/perseus/model/StructureNodeProxy */
    /* @96 */	jobject_array * JVM_FIELD_CONST fontFamily;
    /* @100 */	jfloat fontSize;
    /* com/sun/perseus/model/UseProxy */
};

struct Java_com_sun_perseus_parser_AbstractParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
};

struct Java_com_sun_perseus_util_SVGConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/SVGConstants */
};

struct Java_com_sun_perseus_parser_NumberParser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/parser/AbstractParser */
    /*  @4 */	jint currentPos;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST s;
    /* @12 */	jint current;
    /* com/sun/perseus/parser/NumberParser */
};

struct Java_com_sun_perseus_platform_FilterInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/platform/FilterInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
};

struct Java_com_sun_perseus_platform_BufferedInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/platform/FilterInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /* com/sun/perseus/platform/BufferedInputStream */
    /*  @8 */	jbyte_array * JVM_FIELD_CONST buf;
    /* @12 */	jint count;
    /* @16 */	jint pos;
    /* @20 */	jint markpos;
    /* @24 */	jint marklimit;
};

struct Java_com_sun_perseus_platform_GZIPInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/perseus/platform/GZIPInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint count;
    /* @16 */	jint idx;
    /* @20 */	jint curByte;
    /* @24 */	jint curPos;
};

struct Java_com_sun_perseus_platform_GZIPSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/GZIPSupport */
};

struct Java_com_sun_perseus_platform_HuffmanTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/HuffmanTable */
    /*  @4 */	struct Java_com_sun_perseus_platform_GZIPInputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST codeTable;
    /* @12 */	jint minLen;
};

struct Java_com_sun_perseus_platform_MathSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/MathSupport */
};

struct Java_com_sun_perseus_platform_PURL {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/PURL */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST protocol;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST host;
    /* @12 */	jint port;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST file;
    /* @20 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST authority;
    /* @28 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /* @32 */	struct Java_java_lang_String * JVM_FIELD_CONST userInfo;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST ref;
    /* @40 */	struct Java_java_lang_Object * JVM_FIELD_CONST hostAddress;
    /* @44 */	jint hashCode;
};

struct Java_com_sun_perseus_platform_PURLStreamHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/PURLStreamHandler */
};

struct Java_com_sun_perseus_platform_Parts {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/Parts */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST path;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST query;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST ref;
};

struct Java_com_sun_perseus_platform_ResourceHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/ResourceHandler */
};

struct Java_com_sun_perseus_platform_ThreadSupport {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/ThreadSupport */
};

struct Java_com_sun_perseus_platform_URLResolver {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/platform/URLResolver */
};

struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList$Node */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST next;
    /*  @8 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST prev;
};

struct Java_com_sun_perseus_util_DoublyLinkedList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST head;
    /*  @8 */	jint size;
};

struct Java_com_sun_perseus_util_RunnableQueue_0004Link {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList$Node */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST next;
    /*  @8 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST prev;
    /* com/sun/perseus/util/RunnableQueue$Link */
    /* @12 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST runnable;
    /* @16 */	struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableHandler * JVM_FIELD_CONST runHandler;
};

struct Java_com_sun_perseus_util_RunnableQueue_0004LockableLink {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/DoublyLinkedList$Node */
    /*  @4 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST next;
    /*  @8 */	struct Java_com_sun_perseus_util_DoublyLinkedList_0004Node * JVM_FIELD_CONST prev;
    /* com/sun/perseus/util/RunnableQueue$Link */
    /* @12 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST runnable;
    /* @16 */	struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableHandler * JVM_FIELD_CONST runHandler;
    /* com/sun/perseus/util/RunnableQueue$LockableLink */
    /* @20 */	jboolean locked;
    /* @21 */	jbyte ___pad772;
    /* @22 */	jbyte ___pad773;
    /* @23 */	jbyte ___pad774;
};

struct Java_com_sun_perseus_util_RunnableQueue_0004VoidQueueHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/RunnableQueue$VoidQueueHandler */
};

struct Java_com_sun_perseus_util_Scheduler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/Scheduler */
    /*  @4 */	struct Java_com_sun_perseus_util_RunnableQueue * JVM_FIELD_CONST rq;
    /*  @8 */	jobject_array * JVM_FIELD_CONST entries;
};

struct Java_com_sun_perseus_util_Scheduler_0004Entry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/Scheduler$Entry */
    /*  @4 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST runnable;
    /*  @8 */	jlong interval;
    /* @16 */	jlong nextRun;
    /* @24 */	struct Java_com_sun_perseus_util_RunnableQueue_0004RunnableHandler * JVM_FIELD_CONST handler;
    /* @28 */	jboolean live;
    /* @29 */	jbyte ___pad775;
    /* @30 */	jbyte ___pad776;
    /* @31 */	jbyte ___pad777;
};

struct Java_com_sun_perseus_util_SimpleTokenizer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/perseus/util/SimpleTokenizer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST data;
    /*  @8 */	jint length;
    /* @12 */	jchar_array * JVM_FIELD_CONST del;
    /* @16 */	jint cur;
};

struct Java_com_sun_pisces_Face {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Face */
    /*  @4 */	jobject_array * JVM_FIELD_CONST paths;
    /*  @8 */	jint_array * JVM_FIELD_CONST minX;
    /* @12 */	jint_array * JVM_FIELD_CONST minY;
    /* @16 */	jint_array * JVM_FIELD_CONST width;
    /* @20 */	jint_array * JVM_FIELD_CONST height;
    /* @24 */	jdouble scale;
};

struct Java_com_sun_pisces_GZIPInputStream {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/InputStream */
    /* com/sun/pisces/GZIPInputStream */
    /*  @4 */	struct Java_java_io_InputStream * JVM_FIELD_CONST in;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST data;
    /* @12 */	jint count;
    /* @16 */	jint idx;
    /* @20 */	jint curByte;
    /* @24 */	jint curPos;
};

struct Java_com_sun_pisces_GradientColorMap {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/GradientColorMap */
    /*  @4 */	jint cycleMethod;
    /*  @8 */	jint_array * JVM_FIELD_CONST fractions;
    /* @12 */	jint_array * JVM_FIELD_CONST rgba;
    /* @16 */	jint_array * JVM_FIELD_CONST colors;
};

struct Java_com_sun_pisces_HuffmanTable {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/HuffmanTable */
    /*  @4 */	struct Java_com_sun_pisces_GZIPInputStream * JVM_FIELD_CONST in;
    /*  @8 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST codeTable;
    /* @12 */	jint minLen;
};

struct Java_com_sun_pisces_NativeSurface_0004NativeSurfaceDestination {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/NativeSurface$NativeSurfaceDestination */
    /*  @4 */	struct Java_com_sun_pisces_NativeSurface * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_pisces_Paint {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/Paint */
    /*  @4 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST transform;
    /*  @8 */	struct Java_com_sun_pisces_Transform6 * JVM_FIELD_CONST inverse;
};

struct Java_com_sun_pisces_PiscesFont {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PiscesFont */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	jint style;
    /* @12 */	jint size;
    /* @16 */	struct Java_com_sun_pisces_Face * JVM_FIELD_CONST face;
};

struct Java_com_sun_pisces_PiscesMath {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/PiscesMath */
};

struct Java_com_sun_pisces_RendererBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/pisces/LineSink */
    /* com/sun/pisces/RendererBase */
    /*  @4 */	jint imageType;
};

struct Java_com_sun_satsa_util_TLV {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/TLV */
    /*  @4 */	jint type;
    /*  @8 */	jint length;
    /* @12 */	jint valueOffset;
    /* @16 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST child;
    /* @20 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST next;
    /* @24 */	jbyte_array * JVM_FIELD_CONST data;
};

struct Java_com_sun_satsa_acl_JCRMIPermission {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/JCRMIPermission */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST hashModifier;
    /*  @8 */	jobject_array * JVM_FIELD_CONST classes;
    /* @12 */	jint_array * JVM_FIELD_CONST methods;
};

struct Java_com_sun_satsa_acl_ACEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACEntry */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST ACF;
    /*  @8 */	jobject_array * JVM_FIELD_CONST roots;
    /* @12 */	jint_array * JVM_FIELD_CONST APDUPermissions;
    /* @16 */	jobject_array * JVM_FIELD_CONST JCRMIPermissions;
};

struct Java_com_sun_satsa_util_TLVException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/io/IOException */
    /* com/sun/satsa/util/TLVException */
};

struct Java_com_sun_satsa_acl_ACIF_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACIF$1 */
};

struct Java_com_sun_satsa_acl_ACIF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
    /* com/sun/satsa/acl/ACIF */
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST ACIF;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST ACFs;
};

struct Java_com_sun_satsa_util_Location {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/Location */
    /*  @4 */	jshort_array * JVM_FIELD_CONST path;
    /*  @8 */	jint offset;
    /* @12 */	jint length;
};

struct Java_com_sun_satsa_acl_ACIF_0004ACF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACIF$ACF */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST AID;
    /*  @8 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @12 */	struct Java_com_sun_satsa_acl_ACIF * JVM_FIELD_CONST this_0440;
};

struct Java_com_sun_satsa_util_FileSystemAbstract {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/FileSystemAbstract */
    /*  @4 */	jshort_array * JVM_FIELD_CONST root;
    /*  @8 */	jint pathLength;
    /* @12 */	jshort_array * JVM_FIELD_CONST currentPath;
    /* @16 */	struct Java_com_sun_satsa_util_Connection * JVM_FIELD_CONST apdu;
    /* @20 */	jint currentFileSize;
    /* @24 */	jboolean isEFSelected;
    /* @25 */	jbyte ___pad778;
    /* @26 */	jbyte ___pad779;
    /* @27 */	jbyte ___pad780;
};

struct Java_com_sun_satsa_util_pkcs15_PKCS15File {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
};

struct Java_com_sun_satsa_acl_AclFileSystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/FileSystemAbstract */
    /*  @4 */	jshort_array * JVM_FIELD_CONST root;
    /*  @8 */	jint pathLength;
    /* @12 */	jshort_array * JVM_FIELD_CONST currentPath;
    /* @16 */	struct Java_com_sun_satsa_util_Connection * JVM_FIELD_CONST apdu;
    /* @20 */	jint currentFileSize;
    /* @24 */	jboolean isEFSelected;
    /* @25 */	jbyte ___pad781;
    /* @26 */	jbyte ___pad782;
    /* @27 */	jbyte ___pad783;
    /* com/sun/satsa/acl/AclFileSystem */
    /* @28 */	jbyte_array * JVM_FIELD_CONST ATR;
    /* @32 */	jint unitSize;
    /* @36 */	struct Java_com_sun_satsa_util_pkcs15_DIRF * JVM_FIELD_CONST DIR;
};

struct Java_com_sun_satsa_util_Connection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/Connection */
    /*  @4 */	jint lastSW;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST command;
    /* @12 */	jint offset;
    /* @16 */	struct Java_com_sun_midp_io_j2me_apdu_Handle * JVM_FIELD_CONST h;
    /* @20 */	jint unitSize;
    /* @24 */	jbyte CLAbyte;
    /* @25 */	jbyte ___pad784;
    /* @26 */	jbyte ___pad785;
    /* @27 */	jbyte ___pad786;
};

struct Java_com_sun_satsa_util_pkcs15_DIRF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
    /* com/sun/satsa/util/pkcs15/DIRF */
    /* @24 */	jbyte_array * JVM_FIELD_CONST PKCS_AID;
    /* @28 */	jshort_array * JVM_FIELD_CONST DIR_FILE;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST DIR;
};

struct Java_com_sun_satsa_acl_ACSlot {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACSlot */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST ACIFOID;
    /*  @8 */	jshort_array * JVM_FIELD_CONST ODF;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST ACLists;
    /* @16 */	struct Java_java_util_Vector * JVM_FIELD_CONST PINAttrs;
    /* @20 */	struct Java_com_sun_satsa_acl_AclFileSystem * JVM_FIELD_CONST files;
    /* @24 */	jboolean allGranted;
    /* @25 */	jboolean allRevoked;
    /* @26 */	jbyte ___pad787;
    /* @27 */	jbyte ___pad788;
};

struct Java_com_sun_satsa_acl_PINData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/PINData */
    /*  @4 */	jint id;
    /*  @8 */	jobject_array * JVM_FIELD_CONST commands;
};

struct Java_com_sun_satsa_acl_PINAttributes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/PINAttributes */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /*  @8 */	jint id;
    /* @12 */	jint pinType;
    /* @16 */	jint minLength;
    /* @20 */	jint storedLength;
    /* @24 */	jint maxLength;
    /* @28 */	jint pinReference;
    /* @32 */	jint padChar;
    /* @36 */	jint pinFlags;
    /* @40 */	jshort_array * JVM_FIELD_CONST path;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST PIN;
    /* @48 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST root;
};

struct Java_com_sun_satsa_acl_ACLPermissions {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/ACLPermissions */
    /*  @4 */	jint type;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST permissions;
    /* @12 */	jobject_array * JVM_FIELD_CONST pins;
    /* @16 */	struct Java_com_sun_satsa_acl_ACSlot * JVM_FIELD_CONST parent;
    /* @20 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST attr1;
    /* @24 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST attr2;
};

struct Java_com_sun_satsa_acl_ACList {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
    /* com/sun/satsa/acl/ACList */
    /* @24 */	jbyte_array * JVM_FIELD_CONST AID;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST ACF;
    /* @32 */	struct Java_com_sun_satsa_acl_ACEntry * JVM_FIELD_CONST ACE;
    /* @36 */	jobject_array * JVM_FIELD_CONST PINInfo;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST pin_info;
};

struct Java_com_sun_satsa_acl_AccessControlManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/AccessControlManager */
};

struct Java_com_sun_satsa_acl_PINEntryDialog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/acl/PINEntryDialog */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /*  @8 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @12 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @16 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @20 */	jint answer;
    /* @24 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf1;
    /* @28 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf2;
    /* @32 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST pin1;
    /* @36 */	struct Java_com_sun_satsa_acl_PINAttributes * JVM_FIELD_CONST pin2;
    /* @40 */	jbyte_array * JVM_FIELD_CONST data1;
    /* @44 */	jbyte_array * JVM_FIELD_CONST data2;
};

struct Java_java_security_spec_X509EncodedKeySpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/spec/EncodedKeySpec */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST encodedKey;
    /* java/security/spec/X509EncodedKeySpec */
};

struct Java_java_security_Key {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/Key */
};

struct Java_java_security_PublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/PublicKey */
};

struct Java_java_security_spec_KeySpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/spec/KeySpec */
};

struct Java_com_sun_satsa_crypto_RSAPublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/crypto/RSAPublicKey */
    /*  @4 */	struct Java_com_sun_midp_crypto_RSAPublicKey * JVM_FIELD_CONST key;
    /*  @8 */	jint keyLen;
    /* @12 */	struct Java_java_security_spec_X509EncodedKeySpec * JVM_FIELD_CONST keySpec;
};

struct Java_java_security_GeneralSecurityException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
};

struct Java_java_security_spec_InvalidKeySpecException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/spec/InvalidKeySpecException */
};

struct Java_com_sun_satsa_pki_Certificate {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/Certificate */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /*  @8 */	jbyte_array * JVM_FIELD_CONST id;
    /* @12 */	jbyte_array * JVM_FIELD_CONST requestId;
    /* @16 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST cert;
    /* @20 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST header;
    /* @24 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST body;
};

struct Java_com_sun_satsa_pki_Dialog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/Dialog */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayEventHandler * JVM_FIELD_CONST displayEventHandler;
    /*  @8 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST okCmd;
    /* @12 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancelCmd;
    /* @16 */	struct Java_java_lang_Object * JVM_FIELD_CONST preemptToken;
    /* @20 */	jint answer;
    /* @24 */	struct Java_javax_microedition_lcdui_Form * JVM_FIELD_CONST form;
};

struct Java_com_sun_satsa_pki_MessageDialog {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/MessageDialog */
};

struct Java_com_sun_satsa_pki_WIMApplication {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/WIMApplication */
    /*  @4 */	struct Java_com_sun_midp_security_SecurityToken * JVM_FIELD_CONST securityToken;
    /*  @8 */	struct Java_com_sun_satsa_util_Connection * JVM_FIELD_CONST apdu;
    /* @12 */	struct Java_com_sun_satsa_pki_WimFileSystem * JVM_FIELD_CONST files;
    /* @16 */	jint WIM_GENERIC_RSA_ID;
    /* @20 */	jint RSA_ALGORITHM_ID;
    /* @24 */	struct Java_java_lang_String * JVM_FIELD_CONST serialNumber;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST ODF;
    /* @32 */	jobject_array * JVM_FIELD_CONST PrKeys;
    /* @36 */	jobject_array * JVM_FIELD_CONST PuKeys;
    /* @40 */	jobject_array * JVM_FIELD_CONST PINs;
    /* @44 */	jobject_array * JVM_FIELD_CONST Certificates;
    /* @48 */	struct Java_java_util_Vector * JVM_FIELD_CONST certificateIDs;
    /* @52 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /* @56 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @60 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @64 */	jshort_array * JVM_FIELD_CONST UnusedSpacePath;
    /* @68 */	struct Java_java_util_Vector * JVM_FIELD_CONST updateLocations;
    /* @72 */	struct Java_java_util_Vector * JVM_FIELD_CONST updateData;
    /* @76 */	jboolean_array * JVM_FIELD_CONST updatePIN;
    /* @80 */	jboolean readOnly;
    /* @81 */	jbyte ___pad789;
    /* @82 */	jbyte ___pad790;
    /* @83 */	jbyte ___pad791;
};

struct Java_com_sun_satsa_pki_PKIManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/PKIManager */
};

struct Java_javax_microedition_pki_UserCredentialManagerException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/pki/UserCredentialManagerException */
    /* @12 */	jbyte reasonCode;
    /* @13 */	jbyte ___pad792;
    /* @14 */	jbyte ___pad793;
    /* @15 */	jbyte ___pad794;
};

struct Java_javax_microedition_securityservice_CMSMessageSignatureServiceException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/securityservice/CMSMessageSignatureServiceException */
    /* @12 */	jbyte reasonCode;
    /* @13 */	jbyte ___pad795;
    /* @14 */	jbyte ___pad796;
    /* @15 */	jbyte ___pad797;
};

struct Java_com_sun_satsa_pki_PrivateKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/PrivateKey */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /*  @8 */	jint authId;
    /* @12 */	jbyte_array * JVM_FIELD_CONST id;
    /* @16 */	jint keyReference;
    /* @20 */	jint modulusLength;
    /* @24 */	jshort_array * JVM_FIELD_CONST path;
    /* @28 */	jboolean authentication;
    /* @29 */	jboolean nonRepudiation;
    /* @30 */	jbyte ___pad798;
    /* @31 */	jbyte ___pad799;
};

struct Java_com_sun_satsa_pki_PublicKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/PublicKey */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST id;
    /*  @8 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST body;
};

struct Java_com_sun_satsa_pki_RFC2253Name {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/pki/RFC2253Name */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST src;
    /*  @8 */	jint index;
    /* @12 */	struct Java_java_lang_StringBuffer * JVM_FIELD_CONST tmp;
    /* @16 */	jboolean complete;
    /* @17 */	jboolean encoded;
    /* @18 */	jbyte ___pad800;
    /* @19 */	jbyte ___pad801;
};

struct Java_com_sun_satsa_pki_WimFileSystem {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/FileSystemAbstract */
    /*  @4 */	jshort_array * JVM_FIELD_CONST root;
    /*  @8 */	jint pathLength;
    /* @12 */	jshort_array * JVM_FIELD_CONST currentPath;
    /* @16 */	struct Java_com_sun_satsa_util_Connection * JVM_FIELD_CONST apdu;
    /* @20 */	jint currentFileSize;
    /* @24 */	jboolean isEFSelected;
    /* @25 */	jbyte ___pad802;
    /* @26 */	jbyte ___pad803;
    /* @27 */	jbyte ___pad804;
    /* com/sun/satsa/pki/WimFileSystem */
    /* @28 */	jint CARD_BUFFER;
    /* @32 */	jint P1_P2;
};

struct Java_com_sun_satsa_util_Utils {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/Utils */
};

struct Java_com_sun_satsa_util_pkcs15_AODF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
    /* com/sun/satsa/util/pkcs15/AODF */
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST AODF;
    /* @28 */	jint size;
    /* @32 */	jobject_array * JVM_FIELD_CONST Entries;
};

struct Java_com_sun_satsa_util_pkcs15_DODF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
    /* com/sun/satsa/util/pkcs15/DODF */
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST DODF;
    /* @28 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST typeTLV;
    /* @32 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST oidTLV;
    /* @36 */	struct Java_com_sun_satsa_util_TLV * JVM_FIELD_CONST valueTLV;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST OidDo;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST ExtIDo;
    /* @48 */	struct Java_java_util_Vector * JVM_FIELD_CONST OpaqueDo;
};

struct Java_com_sun_satsa_util_pkcs15_ODF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/satsa/util/pkcs15/PKCS15File */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderObjects;
    /*  @8 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderLocations;
    /* @12 */	struct Java_java_util_Vector * JVM_FIELD_CONST loaderFreeBlocks;
    /* @16 */	struct Java_com_sun_satsa_util_Location * JVM_FIELD_CONST location;
    /* @20 */	struct Java_com_sun_satsa_util_FileSystemAbstract * JVM_FIELD_CONST files;
    /* com/sun/satsa/util/pkcs15/ODF */
    /* @24 */	struct Java_java_util_Vector * JVM_FIELD_CONST pukdfPath;
    /* @28 */	struct Java_java_util_Vector * JVM_FIELD_CONST prkdfPath;
    /* @32 */	struct Java_java_util_Vector * JVM_FIELD_CONST cdfPath;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST skdfPath;
    /* @40 */	struct Java_java_util_Vector * JVM_FIELD_CONST aodfPath;
    /* @44 */	struct Java_java_util_Vector * JVM_FIELD_CONST dodfPath;
    /* @48 */	struct Java_java_util_Vector * JVM_FIELD_CONST ODF;
};

struct Java_com_sun_ukit_jaxp_Attrs {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/ukit/jaxp/Attrs */
    /*  @4 */	jobject_array * JVM_FIELD_CONST mItems;
    /*  @8 */	jchar mLength;
    /* @9 */	jbyte ___pad805;
    /* @10 */	jbyte ___pad806;
};

struct Java_com_sun_ukit_jaxp_Input {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/ukit/jaxp/Input */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST pubid;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST sysid;
    /* @12 */	struct Java_java_io_Reader * JVM_FIELD_CONST src;
    /* @16 */	jchar_array * JVM_FIELD_CONST chars;
    /* @20 */	jint chLen;
    /* @24 */	jint chIdx;
    /* @28 */	struct Java_com_sun_ukit_jaxp_Input * JVM_FIELD_CONST next;
};

struct Java_com_sun_ukit_jaxp_Pair {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/ukit/jaxp/Pair */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST name;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST value;
    /* @12 */	jchar_array * JVM_FIELD_CONST chars;
    /* @16 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST list;
    /* @20 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST next;
    /* @24 */	jchar id;
    /* @25 */	jbyte ___pad807;
    /* @26 */	jbyte ___pad808;
};

struct Java_com_sun_ukit_jaxp_Parser {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParser */
    /* com/sun/ukit/jaxp/Parser */
    /*  @4 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mNoNS;
    /*  @8 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mXml;
    /* @12 */	struct Java_org_xml_sax_helpers_DefaultHandler * JVM_FIELD_CONST mHand;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mEnt;
    /* @20 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST mPEnt;
    /* @24 */	jchar_array * JVM_FIELD_CONST mBuff;
    /* @28 */	jint mBuffIdx;
    /* @32 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mPref;
    /* @36 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mElm;
    /* @40 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mAttL;
    /* @44 */	struct Java_com_sun_ukit_jaxp_Input * JVM_FIELD_CONST mInp;
    /* @48 */	struct Java_com_sun_ukit_jaxp_Input * JVM_FIELD_CONST mDoc;
    /* @52 */	jchar_array * JVM_FIELD_CONST mChars;
    /* @56 */	jint mChLen;
    /* @60 */	jint mChIdx;
    /* @64 */	struct Java_com_sun_ukit_jaxp_Attrs * JVM_FIELD_CONST mAttrs;
    /* @68 */	jobject_array * JVM_FIELD_CONST mItems;
    /* @72 */	struct Java_com_sun_ukit_jaxp_Pair * JVM_FIELD_CONST mDltd;
    /* @76 */	jshort mSt;
    /* @78 */	jchar mESt;
    /* @80 */	jchar mAttrIdx;
    /* @82 */	jboolean mIsSAlone;
    /* @83 */	jboolean mIsNSAware;
};

struct Java_com_sun_ukit_jaxp_ReaderUTF8 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/ukit/jaxp/ReaderUTF8 */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST is;
};

struct Java_com_sun_ukit_jaxp_ReaderUTF16 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/io/Reader */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jchar_array * JVM_FIELD_CONST skipBuffer;
    /* com/sun/ukit/jaxp/ReaderUTF16 */
    /* @12 */	struct Java_java_io_InputStream * JVM_FIELD_CONST is;
    /* @16 */	jchar bo;
    /* @17 */	jbyte ___pad809;
    /* @18 */	jbyte ___pad810;
};

struct Java_com_sun_ukit_jaxp_ParserFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/parsers/SAXParserFactory */
    /*  @4 */	jboolean namespaceAware;
    /*  @5 */	jboolean validating;
    /* @6 */	jbyte ___pad811;
    /* @7 */	jbyte ___pad812;
    /* com/sun/ukit/jaxp/ParserFactory */
    /*  @8 */	jboolean namespaces;
    /*  @9 */	jboolean prefixes;
    /* @10 */	jbyte ___pad813;
    /* @11 */	jbyte ___pad814;
};

struct Java_org_xml_sax_SAXNotRecognizedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
    /* org/xml/sax/SAXNotRecognizedException */
};

struct Java_java_lang_Character {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Character */
    /*  @4 */	jchar value;
    /* @5 */	jbyte ___pad815;
    /* @6 */	jbyte ___pad816;
};

struct Java_java_lang_FloatingDecimal {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/FloatingDecimal */
    /*  @4 */	jint decExponent;
    /*  @8 */	jchar_array * JVM_FIELD_CONST digits;
    /* @12 */	jint nDigits;
    /* @16 */	jint bigIntExp;
    /* @20 */	jint bigIntNBits;
    /* @24 */	jint roundDir;
    /* @28 */	jboolean isExceptional;
    /* @29 */	jboolean isNegative;
    /* @30 */	jboolean mustSetRoundDir;
    /* @31 */	jbyte ___pad817;
};

struct Java_java_lang_FDBigInt {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/FDBigInt */
    /*  @4 */	jint nWords;
    /*  @8 */	jint_array * JVM_FIELD_CONST data;
};

struct Java_java_lang_UnsupportedOperationException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/lang/UnsupportedOperationException */
};

struct Java_java_security_DigestException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/DigestException */
};

struct Java_java_security_InvalidAlgorithmParameterException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/InvalidAlgorithmParameterException */
};

struct Java_java_security_KeyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/KeyException */
};

struct Java_java_security_InvalidKeyException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/KeyException */
    /* java/security/InvalidKeyException */
};

struct Java_java_security_KeyFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/KeyFactory */
};

struct Java_java_security_NoSuchAlgorithmException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/NoSuchAlgorithmException */
};

struct Java_java_security_MessageDigest {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/MessageDigest */
    /*  @4 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST messageDigest;
};

struct Java_java_security_MessageDigestImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/MessageDigest */
    /*  @4 */	struct Java_com_sun_midp_crypto_MessageDigest * JVM_FIELD_CONST messageDigest;
    /* java/security/MessageDigestImpl */
};

struct Java_java_security_Signature {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/Signature */
    /*  @4 */	struct Java_com_sun_midp_crypto_Signature * JVM_FIELD_CONST sign;
};

struct Java_java_security_SignatureImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/Signature */
    /*  @4 */	struct Java_com_sun_midp_crypto_Signature * JVM_FIELD_CONST sign;
    /* java/security/SignatureImpl */
};

struct Java_java_security_SignatureException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* java/security/SignatureException */
};

struct Java_java_security_spec_AlgorithmParameterSpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/spec/AlgorithmParameterSpec */
};

struct Java_java_security_spec_EncodedKeySpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/security/spec/EncodedKeySpec */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST encodedKey;
};

struct Java_java_util_EmptyStackException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/lang/RuntimeException */
    /* java/util/EmptyStackException */
};

struct Java_java_util_HashtableEntry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/HashtableEntry */
    /*  @4 */	jint hash;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST key;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST value;
    /* @16 */	struct Java_java_util_HashtableEntry * JVM_FIELD_CONST next;
};

struct Java_java_util_Hashtable_0004HashtableEnumerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Hashtable$HashtableEnumerator */
    /*  @4 */	jint index;
    /*  @8 */	jobject_array * JVM_FIELD_CONST table;
    /* @12 */	struct Java_java_util_HashtableEntry * JVM_FIELD_CONST entry;
    /* @16 */	struct Java_java_util_Hashtable * JVM_FIELD_CONST this_0440;
    /* @20 */	jboolean keys;
    /* @21 */	jbyte ___pad818;
    /* @22 */	jbyte ___pad819;
    /* @23 */	jbyte ___pad820;
};

struct Java_java_util_Random {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/Random */
    /*  @4 */	jlong seed;
};

struct Java_java_util_TaskQueue {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TaskQueue */
    /*  @4 */	jobject_array * JVM_FIELD_CONST queue;
    /*  @8 */	jint size;
};

struct Java_java_util_TimerThread {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* java/util/TimerThread */
    /* @28 */	struct Java_java_util_TaskQueue * JVM_FIELD_CONST queue;
    /* @32 */	jboolean newTasksMayBeScheduled;
    /* @33 */	jbyte ___pad821;
    /* @34 */	jbyte ___pad822;
    /* @35 */	jbyte ___pad823;
};

struct Java_java_util_VectorEnumerator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/VectorEnumerator */
    /*  @4 */	struct Java_java_util_Vector * JVM_FIELD_CONST vector;
    /*  @8 */	jint count;
};

struct Java_javax_bluetooth_DiscoveryAgent {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/bluetooth/DiscoveryAgent */
    /*  @4 */	struct Java_com_sun_kvem_jsr082_bluetooth_DiscoveryAgentImpl * JVM_FIELD_CONST discoveryAgentImpl;
};

struct Java_javax_crypto_BadPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* javax/crypto/BadPaddingException */
};

struct Java_javax_crypto_Cipher {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/crypto/Cipher */
    /*  @4 */	struct Java_com_sun_midp_crypto_Cipher * JVM_FIELD_CONST cipher;
};

struct Java_javax_crypto_NoSuchPaddingException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* javax/crypto/NoSuchPaddingException */
};

struct Java_javax_crypto_ShortBufferException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* javax/crypto/ShortBufferException */
};

struct Java_javax_crypto_IllegalBlockSizeException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* java/security/GeneralSecurityException */
    /* javax/crypto/IllegalBlockSizeException */
};

struct Java_javax_crypto_spec_IvParameterSpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/crypto/spec/IvParameterSpec */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST IV;
};

struct Java_javax_crypto_spec_SecretKeySpec {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/crypto/spec/SecretKeySpec */
    /*  @4 */	jbyte_array * JVM_FIELD_CONST keyData;
    /*  @8 */	struct Java_java_lang_String * JVM_FIELD_CONST algorithm;
};

struct Java_javax_microedition_io_CommConnection {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/CommConnection */
};

struct Java_javax_microedition_io_Connector {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/Connector */
};

struct Java_javax_microedition_io_PushRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/PushRegistry */
};

struct Java_javax_microedition_io_file_FileSystemEventHandler_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Thread */
    /*  @4 */	jint priority;
    /*  @8 */	struct Java_java_lang_Runnable * JVM_FIELD_CONST target;
    /* @12 */	struct Java_java_lang_Object * JVM_FIELD_CONST vm_thread;
    /* @16 */	jint is_terminated;
    /* @20 */	jint is_stillborn;
    /* @24 */	jchar_array * JVM_FIELD_CONST name;
    /* javax/microedition/io/file/FileSystemEventHandler$1 */
};

struct Java_javax_microedition_io_file_FileSystemEventHandlerBase {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemEventHandlerBase */
};

struct Java_javax_microedition_io_file_FileSystemEventHandler {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemEventHandlerBase */
    /* javax/microedition/io/file/FileSystemEventHandler */
};

struct Java_javax_microedition_io_file_FileSystemListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemListener */
};

struct Java_javax_microedition_io_file_FileSystemRegistry_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemRegistry$1 */
    /*  @4 */	jobject_array * JVM_FIELD_CONST roots;
    /*  @8 */	jint index;
};

struct Java_javax_microedition_io_file_FileSystemRegistry {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/io/file/FileSystemRegistry */
};

struct Java_javax_microedition_jcrmi_RemoteStub {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/jcrmi/RemoteStub */
    /*  @4 */	struct Java_javax_microedition_jcrmi_RemoteRef * JVM_FIELD_CONST ref;
};

struct Java_javax_microedition_lcdui_AbstractImageData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractImageData */
};

struct Java_javax_microedition_lcdui_ImageData {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageData */
    /*  @4 */	jint width;
    /*  @8 */	jint height;
    /* @12 */	jbyte_array * JVM_FIELD_CONST pixelData;
    /* @16 */	jbyte_array * JVM_FIELD_CONST alphaData;
    /* @20 */	jint nativePixelData;
    /* @24 */	jint nativeAlphaData;
    /* @28 */	jboolean isMutable;
    /* @29 */	jbyte ___pad824;
    /* @30 */	jbyte ___pad825;
    /* @31 */	jbyte ___pad826;
};

struct Java_javax_microedition_lcdui_AbstractImageDataFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/AbstractImageDataFactory */
};

struct Java_javax_microedition_lcdui_Alert_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Alert$1 */
    /*  @4 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_AlertLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @32 */	jint_array * JVM_FIELD_CONST viewable;
    /* @36 */	jint vScrollPosition;
    /* @40 */	jint vScrollProportion;
    /* @44 */	jboolean resetToTop;
    /* @45 */	jbyte ___pad827;
    /* @46 */	jbyte ___pad828;
    /* @47 */	jbyte ___pad829;
    /* javax/microedition/lcdui/AlertLFImpl */
    /* @48 */	jint clipx;
    /* @52 */	jint clipy;
    /* @56 */	jint clipw;
    /* @60 */	jint cliph;
    /* @64 */	jint maxScroll;
    /* @68 */	jint totalHeight;
    /* @72 */	struct Java_javax_microedition_lcdui_Alert * JVM_FIELD_CONST alert;
    /* @76 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST icon;
    /* @80 */	struct Java_java_util_TimerTask * JVM_FIELD_CONST timerTask;
    /* @84 */	jint titlex;
    /* @88 */	jint titley;
    /* @92 */	jint titlew;
    /* @96 */	jint titleh;
    /* @100 */	jint icony;
    /* @104 */	jint iconw;
    /* @108 */	jint iconh;
    /* @112 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @116 */	jboolean isLayoutValid;
    /* @117 */	jbyte ___pad830;
    /* @118 */	jbyte ___pad831;
    /* @119 */	jbyte ___pad832;
};

struct Java_javax_microedition_lcdui_AlertLFImpl_0004TimeoutTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/AlertLFImpl$TimeoutTask */
    /* @28 */	struct Java_javax_microedition_lcdui_AlertLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_TickerLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TickerLF */
};

struct Java_javax_microedition_lcdui_Display_0004DisplayAccessImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$DisplayAccessImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_DisplayableLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
};

struct Java_javax_microedition_lcdui_ScreenLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @32 */	jint_array * JVM_FIELD_CONST viewable;
    /* @36 */	jint vScrollPosition;
    /* @40 */	jint vScrollProportion;
    /* @44 */	jboolean resetToTop;
    /* @45 */	jbyte ___pad833;
    /* @46 */	jbyte ___pad834;
    /* @47 */	jbyte ___pad835;
};

struct Java_javax_microedition_lcdui_MMHelperImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/MMHelperImpl */
};

struct Java_javax_microedition_lcdui_CanvasLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/CanvasLFImpl */
    /* @32 */	struct Java_javax_microedition_lcdui_Canvas * JVM_FIELD_CONST canvas;
    /* @36 */	struct Java_java_util_Vector * JVM_FIELD_CONST embeddedVideos;
};

struct Java_javax_microedition_lcdui_ChamImageTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ChamImageTunnel */
};

struct Java_javax_microedition_lcdui_ItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad836;
    /* @43 */	jbyte ___pad837;
};

struct Java_javax_microedition_lcdui_ChoiceGroupLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad838;
    /* @43 */	jbyte ___pad839;
    /* javax/microedition/lcdui/ChoiceGroupLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @48 */	jint selectedIndex;
    /* @52 */	jint hilightedIndex;
    /* @56 */	jint contentX;
    /* @60 */	jint_array * JVM_FIELD_CONST elHeights;
    /* @64 */	jboolean traversedIn;
    /* @65 */	jbyte ___pad840;
    /* @66 */	jbyte ___pad841;
    /* @67 */	jbyte ___pad842;
};

struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad843;
    /* @43 */	jbyte ___pad844;
    /* javax/microedition/lcdui/ChoiceGroupLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ChoiceGroup * JVM_FIELD_CONST cg;
    /* @48 */	jint selectedIndex;
    /* @52 */	jint hilightedIndex;
    /* @56 */	jint contentX;
    /* @60 */	jint_array * JVM_FIELD_CONST elHeights;
    /* @64 */	jboolean traversedIn;
    /* @65 */	jbyte ___pad845;
    /* @66 */	jbyte ___pad846;
    /* @67 */	jbyte ___pad847;
    /* javax/microedition/lcdui/ChoiceGroupPopupLFImpl */
    /* @68 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl_0004CGPopupLayer * JVM_FIELD_CONST popupLayer;
    /* @72 */	jint_array * JVM_FIELD_CONST viewable;
    /* @76 */	jboolean popUpOpen;
    /* @77 */	jbyte ___pad848;
    /* @78 */	jbyte ___pad849;
    /* @79 */	jbyte ___pad850;
};

struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl_0004CGPopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad851;
    /* @43 */	jbyte ___pad852;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/ChoiceGroupPopupLFImpl$CGPopupLayer */
    /* @52 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl * JVM_FIELD_CONST lf;
    /* @56 */	jint_array * JVM_FIELD_CONST viewport;
    /* @60 */	struct Java_javax_microedition_lcdui_ChoiceGroupPopupLFImpl * JVM_FIELD_CONST this_0440;
    /* @64 */	jboolean popupDrawnDown;
    /* @65 */	jboolean sbVisible;
    /* @66 */	jbyte ___pad853;
    /* @67 */	jbyte ___pad854;
};

struct Java_javax_microedition_lcdui_CustomItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad855;
    /* @43 */	jbyte ___pad856;
    /* javax/microedition/lcdui/CustomItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_CustomItem * JVM_FIELD_CONST customItem;
    /* @48 */	jint preferredHeight;
    /* @52 */	jint preferredWidth;
    /* @56 */	jint minimumHeight;
    /* @60 */	jint minimumWidth;
    /* @64 */	jboolean validRequestedSizes;
    /* @65 */	jbyte ___pad857;
    /* @66 */	jbyte ___pad858;
    /* @67 */	jbyte ___pad859;
};

struct Java_javax_microedition_lcdui_DateEditor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad860;
    /* @43 */	jbyte ___pad861;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST __dup1__commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DateEditor */
    /* @52 */	struct Java_javax_microedition_lcdui_DateFieldLFImpl * JVM_FIELD_CONST lf;
    /* @56 */	struct Java_java_util_Calendar * JVM_FIELD_CONST editDate;
    /* @60 */	jint mode;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancel;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST set;
    /* @72 */	jobject_array * JVM_FIELD_CONST commands;
    /* @76 */	jint nextX;
    /* @80 */	jint nextY;
    /* @84 */	jint lastDay;
    /* @88 */	jint dayOffset;
    /* @92 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST monthPopup;
    /* @96 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST yearPopup;
    /* @100 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST hoursPopup;
    /* @104 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST minutesPopup;
    /* @108 */	jint focusOn;
    /* @112 */	jint hilightedDate;
    /* @116 */	jint selectedDate;
    /* @120 */	jint popupWidth;
    /* @124 */	jint popupHeight;
    /* @128 */	jint elementWidth;
    /* @132 */	jint elementHeight;
    /* @136 */	jint timeComponentsOffset;
    /* @140 */	jint calendarTopLimit;
    /* @144 */	jint calendarBottomLimit;
    /* @148 */	jint calendarRightLimit;
    /* @152 */	jint dateHilightX;
    /* @156 */	jint dateHilightY;
    /* @160 */	jboolean initialized;
    /* @161 */	jboolean popUpOpen;
    /* @162 */	jboolean amSelected;
    /* @163 */	jboolean amHilighted;
};

struct Java_javax_microedition_lcdui_DEPopupLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad862;
    /* @43 */	jbyte ___pad863;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DEPopupLayer */
    /* @52 */	struct Java_javax_microedition_lcdui_DateEditor * JVM_FIELD_CONST editor;
    /* @56 */	jint_array * JVM_FIELD_CONST viewport;
    /* @60 */	jint numElements;
    /* @64 */	jobject_array * JVM_FIELD_CONST elements;
    /* @68 */	jint elementWidth;
    /* @72 */	jint elementHeight;
    /* @76 */	jint elementsToFit;
    /* @80 */	jint startIndex;
    /* @84 */	jint endIndex;
    /* @88 */	jint hilightedIndex;
    /* @92 */	jboolean open;
    /* @93 */	jboolean sbVisible;
    /* @94 */	jboolean circularTraversal;
    /* @95 */	jbyte ___pad864;
};

struct Java_javax_microedition_lcdui_DateFieldLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad865;
    /* @43 */	jbyte ___pad866;
    /* javax/microedition/lcdui/DateFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_DateField * JVM_FIELD_CONST df;
    /* @48 */	struct Java_java_util_Calendar * JVM_FIELD_CONST currentDate;
    /* @52 */	jint mode;
    /* @56 */	struct Java_javax_microedition_lcdui_DateEditor * JVM_FIELD_CONST editor;
    /* @60 */	jboolean traversedIn;
    /* @61 */	jboolean popUpOpen;
    /* @62 */	jbyte ___pad867;
    /* @63 */	jbyte ___pad868;
};

struct Java_javax_microedition_lcdui_DateField {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/DateField */
    /* @44 */	struct Java_javax_microedition_lcdui_DateFieldLF * JVM_FIELD_CONST dateFieldLF;
    /* @48 */	jint mode;
    /* @52 */	struct Java_java_util_Calendar * JVM_FIELD_CONST currentDate;
    /* @56 */	jboolean initialized;
    /* @57 */	jbyte ___pad869;
    /* @58 */	jbyte ___pad870;
    /* @59 */	jbyte ___pad871;
};

struct Java_javax_microedition_lcdui_DateFieldLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DateFieldLF */
};

struct Java_javax_microedition_lcdui_Display_0004HeadlessAlert {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad872;
    /* @30 */	jbyte ___pad873;
    /* @31 */	jbyte ___pad874;
    /* javax/microedition/lcdui/Screen */
    /* javax/microedition/lcdui/Alert */
    /* @32 */	struct Java_javax_microedition_lcdui_AlertType * JVM_FIELD_CONST type;
    /* @36 */	struct Java_java_lang_String * JVM_FIELD_CONST text;
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST image;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST mutableImage;
    /* @48 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST indicator;
    /* @52 */	jint time;
    /* @56 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST returnScreen;
    /* @60 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST userCommandListener;
    /* @64 */	struct Java_javax_microedition_lcdui_AlertLF * JVM_FIELD_CONST alertLF;
    /* @68 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST implicitListener;
    /* javax/microedition/lcdui/Display$HeadlessAlert */
    /* @72 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$1 */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST val_044this_0440;
    /*  @8 */	struct Java_javax_microedition_lcdui_Display_0004HeadlessAlert * JVM_FIELD_CONST this_0441;
};

struct Java_javax_microedition_lcdui_Display_0004ChameleonTunnel {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$ChameleonTunnel */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_Display_0004DisplayEventConsumerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Display$DisplayEventConsumerImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_DisplayEventHandlerImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayEventHandlerImpl */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_main_MIDletControllerEventProducer * JVM_FIELD_CONST midletControllerEventProducer;
    /* @12 */	struct Java_com_sun_midp_lcdui_DisplayAccess * JVM_FIELD_CONST preemptingDisplay;
    /* @16 */	jboolean destroyPreemptingDisplay;
    /* @17 */	jbyte ___pad875;
    /* @18 */	jbyte ___pad876;
    /* @19 */	jbyte ___pad877;
};

struct Java_javax_microedition_lcdui_DisplayEventListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayEventListener */
    /*  @4 */	struct Java_com_sun_midp_lcdui_DisplayContainer * JVM_FIELD_CONST displayContainer;
    /*  @8 */	struct Java_com_sun_midp_events_EventQueue * JVM_FIELD_CONST eventQueue;
};

struct Java_javax_microedition_lcdui_LayoutManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LayoutManager */
    /*  @4 */	jint_array * JVM_FIELD_CONST sizingBox;
    /*  @8 */	jint viewportWidth;
    /* @12 */	jint viewportHeight;
};

struct Java_javax_microedition_lcdui_FormLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/DisplayableLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Display * JVM_FIELD_CONST currentDisplay;
    /*  @8 */	jint_array * JVM_FIELD_CONST viewport;
    /* @12 */	struct Java_javax_microedition_lcdui_Displayable * JVM_FIELD_CONST owner;
    /* @16 */	jint state;
    /* @20 */	jint stickyKeyMask;
    /* @24 */	jint currentKeyMask;
    /* @28 */	jboolean invalidScroll;
    /* @29 */	jboolean sizeChangeOccurred;
    /* @30 */	jboolean sawPointerPress;
    /* @31 */	jboolean sawKeyPress;
    /* javax/microedition/lcdui/ScreenLFImpl */
    /* @32 */	jint_array * JVM_FIELD_CONST viewable;
    /* @36 */	jint vScrollPosition;
    /* @40 */	jint vScrollProportion;
    /* @44 */	jboolean resetToTop;
    /* @45 */	jbyte ___pad878;
    /* @46 */	jbyte ___pad879;
    /* @47 */	jbyte ___pad880;
    /* javax/microedition/lcdui/FormLFImpl */
    /* @48 */	jint traverseIndex;
    /* @52 */	struct Java_javax_microedition_lcdui_ItemLFImpl * JVM_FIELD_CONST lastTraverseItem;
    /* @56 */	jint_array * JVM_FIELD_CONST visRect;
    /* @60 */	jobject_array * JVM_FIELD_CONST itemLFs;
    /* @64 */	jint numOfLFs;
    /* @68 */	jint lastScrollPosition;
    /* @72 */	jint lastScrollSize;
    /* @76 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST pendingCurrentItem;
    /* @80 */	jboolean itemTraverse;
    /* @81 */	jboolean itemsModified;
    /* @82 */	jboolean pointerPressed;
    /* @83 */	jboolean scrollInitialized;
    /* @84 */	jboolean firstShown;
    /* @85 */	jbyte ___pad881;
    /* @86 */	jbyte ___pad882;
    /* @87 */	jbyte ___pad883;
};

struct Java_javax_microedition_lcdui_GaugeLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad884;
    /* @43 */	jbyte ___pad885;
    /* javax/microedition/lcdui/GaugeLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_Gauge * JVM_FIELD_CONST gauge;
    /* @48 */	struct Java_javax_microedition_lcdui_GaugeLFImpl_0004GaugeUpdateTask * JVM_FIELD_CONST updateHelper;
    /* @52 */	jint percentWidth;
    /* @56 */	jint percentHeight;
    /* @60 */	jint focusBtn;
    /* @64 */	jint_array * JVM_FIELD_CONST percentLoc;
    /* @68 */	jint nextFrame;
    /* @72 */	jboolean initialTraverse;
    /* @73 */	jboolean intTraverse;
    /* @74 */	jbyte ___pad886;
    /* @75 */	jbyte ___pad887;
};

struct Java_javax_microedition_lcdui_GaugeLFImpl_0004GaugeUpdateTask {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/GaugeLFImpl$GaugeUpdateTask */
    /* @28 */	struct Java_javax_microedition_lcdui_GaugeLFImpl * JVM_FIELD_CONST myGaugeLF;
    /* @32 */	struct Java_javax_microedition_lcdui_GaugeLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_ImageDataFactory {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ImageDataFactory */
};

struct Java_javax_microedition_lcdui_ImageItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad888;
    /* @43 */	jbyte ___pad889;
    /* javax/microedition/lcdui/ImageItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_ImageItem * JVM_FIELD_CONST imgItem;
    /* @48 */	jint appearanceMode;
};

struct Java_javax_microedition_lcdui_KeyConverter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/KeyConverter */
};

struct Java_javax_microedition_lcdui_Spacer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Item */
    /*  @4 */	struct Java_javax_microedition_lcdui_ItemLF * JVM_FIELD_CONST itemLF;
    /*  @8 */	struct Java_javax_microedition_lcdui_ItemCommandListener * JVM_FIELD_CONST commandListener;
    /* @12 */	struct Java_java_lang_String * JVM_FIELD_CONST label;
    /* @16 */	struct Java_javax_microedition_lcdui_Screen * JVM_FIELD_CONST owner;
    /* @20 */	jint layout;
    /* @24 */	jobject_array * JVM_FIELD_CONST commands;
    /* @28 */	jint numCommands;
    /* @32 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST defaultCommand;
    /* @36 */	jint lockedWidth;
    /* @40 */	jint lockedHeight;
    /* javax/microedition/lcdui/Spacer */
    /* @44 */	struct Java_javax_microedition_lcdui_SpacerLF * JVM_FIELD_CONST spacerLF;
    /* @48 */	jint width;
    /* @52 */	jint height;
};

struct Java_javax_microedition_lcdui_SpacerLF {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/SpacerLF */
};

struct Java_javax_microedition_lcdui_LFFactoryImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/LFFactory */
    /* javax/microedition/lcdui/LFFactoryImpl */
};

struct Java_javax_microedition_lcdui_StringItemLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad890;
    /* @43 */	jbyte ___pad891;
    /* javax/microedition/lcdui/StringItemLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_StringItem * JVM_FIELD_CONST strItem;
    /* @48 */	jint appearanceMode;
    /* @52 */	jboolean skipTraverse;
    /* @53 */	jbyte ___pad892;
    /* @54 */	jbyte ___pad893;
    /* @55 */	jbyte ___pad894;
};

struct Java_javax_microedition_lcdui_SpacerLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad895;
    /* @43 */	jbyte ___pad896;
    /* javax/microedition/lcdui/SpacerLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_Spacer * JVM_FIELD_CONST spacer;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad897;
    /* @43 */	jbyte ___pad898;
    /* javax/microedition/lcdui/TextFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf;
    /* @48 */	struct Java_com_sun_midp_lcdui_TextCursor * JVM_FIELD_CONST cursor;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
    /* @56 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST interruptedIM;
    /* @60 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST inputMenu;
    /* @64 */	jobject_array * JVM_FIELD_CONST inputModes;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_InputModeLayer * JVM_FIELD_CONST inputModeIndicator;
    /* @72 */	jobject_array * JVM_FIELD_CONST pt_matches;
    /* @76 */	jint_array * JVM_FIELD_CONST inputModeAnchor;
    /* @80 */	jint_array * JVM_FIELD_CONST cachedSize;
    /* @84 */	jint xScrollOffset;
    /* @88 */	jint textWidth;
    /* @92 */	jint scrollWidth;
    /* @96 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @100 */	struct Java_java_util_Vector * JVM_FIELD_CONST timers;
    /* @104 */	struct Java_java_util_Timer * JVM_FIELD_CONST timerService;
    /* @108 */	jboolean editable;
    /* @109 */	jboolean firstTimeInTraverse;
    /* @110 */	jboolean pt_popupOpen;
    /* @111 */	jboolean showIMPopup;
    /* @112 */	jboolean usePreferredX;
    /* @113 */	jbyte ___pad899;
    /* @114 */	jbyte ___pad900;
    /* @115 */	jbyte ___pad901;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TextScrollPainter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/TextFieldLFImpl$TextScrollPainter */
    /* @28 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_00041 {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TextFieldLFImpl$1 */
};

struct Java_javax_microedition_lcdui_TextBoxLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/ItemLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_Item * JVM_FIELD_CONST item;
    /*  @8 */	jint_array * JVM_FIELD_CONST bounds;
    /* @12 */	jboolean_array * JVM_FIELD_CONST actualBoundsInvalid;
    /* @16 */	jint rowHeight;
    /* @20 */	jint_array * JVM_FIELD_CONST target;
    /* @24 */	jint cachedWidth;
    /* @28 */	jint_array * JVM_FIELD_CONST labelBounds;
    /* @32 */	jint_array * JVM_FIELD_CONST contentBounds;
    /* @36 */	jboolean hasFocus;
    /* @37 */	jboolean sizeChanged;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean isNewLine;
    /* @40 */	jboolean drawsTraversalIndicator;
    /* @41 */	jboolean layoutDone;
    /* @42 */	jbyte ___pad902;
    /* @43 */	jbyte ___pad903;
    /* javax/microedition/lcdui/TextFieldLFImpl */
    /* @44 */	struct Java_javax_microedition_lcdui_TextField * JVM_FIELD_CONST tf;
    /* @48 */	struct Java_com_sun_midp_lcdui_TextCursor * JVM_FIELD_CONST cursor;
    /* @52 */	struct Java_java_lang_String * JVM_FIELD_CONST initialInputMode;
    /* @56 */	struct Java_com_sun_midp_chameleon_input_InputMode * JVM_FIELD_CONST interruptedIM;
    /* @60 */	struct Java_com_sun_midp_chameleon_SubMenuCommand * JVM_FIELD_CONST inputMenu;
    /* @64 */	jobject_array * JVM_FIELD_CONST inputModes;
    /* @68 */	struct Java_com_sun_midp_chameleon_layers_InputModeLayer * JVM_FIELD_CONST inputModeIndicator;
    /* @72 */	jobject_array * JVM_FIELD_CONST pt_matches;
    /* @76 */	jint_array * JVM_FIELD_CONST inputModeAnchor;
    /* @80 */	jint_array * JVM_FIELD_CONST cachedSize;
    /* @84 */	jint xScrollOffset;
    /* @88 */	jint textWidth;
    /* @92 */	jint scrollWidth;
    /* @96 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TextScrollPainter * JVM_FIELD_CONST textScrollPainter;
    /* @100 */	struct Java_java_util_Vector * JVM_FIELD_CONST timers;
    /* @104 */	struct Java_java_util_Timer * JVM_FIELD_CONST timerService;
    /* @108 */	jboolean editable;
    /* @109 */	jboolean firstTimeInTraverse;
    /* @110 */	jboolean pt_popupOpen;
    /* @111 */	jboolean showIMPopup;
    /* @112 */	jboolean usePreferredX;
    /* @113 */	jbyte ___pad904;
    /* @114 */	jbyte ___pad905;
    /* @115 */	jbyte ___pad906;
    /* javax/microedition/lcdui/TextBoxLFImpl */
    /* @116 */	struct Java_com_sun_midp_lcdui_TextInfo * JVM_FIELD_CONST myInfo;
    /* @120 */	jboolean scrollInitialized;
    /* @121 */	jbyte ___pad907;
    /* @122 */	jbyte ___pad908;
    /* @123 */	jbyte ___pad909;
};

struct Java_javax_microedition_lcdui_TickerLFImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/TickerLFImpl */
    /*  @4 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST owner;
    /*  @8 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
};

struct Java_javax_microedition_lcdui_MiniDateEditor {
    /* java/lang/Object */
	void * __do_not_use__;
    /* com/sun/midp/chameleon/CLayer */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST layerID;
    /*  @8 */	jint_array * JVM_FIELD_CONST dirtyBounds;
    /* @12 */	jint bgColor;
    /* @16 */	jobject_array * JVM_FIELD_CONST bgImage;
    /* @20 */	jint_array * JVM_FIELD_CONST bounds;
    /* @24 */	struct Java_com_sun_midp_chameleon_CWindow * JVM_FIELD_CONST owner;
    /* @28 */	jint graphicsColor;
    /* @32 */	struct Java_javax_microedition_lcdui_Font * JVM_FIELD_CONST graphicsFont;
    /* @36 */	jboolean dirty;
    /* @37 */	jboolean transparent;
    /* @38 */	jboolean visible;
    /* @39 */	jboolean supportsInput;
    /* @40 */	jboolean opaque;
    /* @41 */	jboolean tileBG;
    /* @42 */	jbyte ___pad910;
    /* @43 */	jbyte ___pad911;
    /* com/sun/midp/chameleon/layers/PopupLayer */
    /* @44 */	jobject_array * JVM_FIELD_CONST __dup1__commands;
    /* @48 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* javax/microedition/lcdui/DateEditor */
    /* @52 */	struct Java_javax_microedition_lcdui_DateFieldLFImpl * JVM_FIELD_CONST lf;
    /* @56 */	struct Java_java_util_Calendar * JVM_FIELD_CONST editDate;
    /* @60 */	jint mode;
    /* @64 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST cancel;
    /* @68 */	struct Java_javax_microedition_lcdui_Command * JVM_FIELD_CONST set;
    /* @72 */	jobject_array * JVM_FIELD_CONST commands;
    /* @76 */	jint nextX;
    /* @80 */	jint nextY;
    /* @84 */	jint lastDay;
    /* @88 */	jint dayOffset;
    /* @92 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST monthPopup;
    /* @96 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST yearPopup;
    /* @100 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST hoursPopup;
    /* @104 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST minutesPopup;
    /* @108 */	jint focusOn;
    /* @112 */	jint hilightedDate;
    /* @116 */	jint selectedDate;
    /* @120 */	jint popupWidth;
    /* @124 */	jint popupHeight;
    /* @128 */	jint elementWidth;
    /* @132 */	jint elementHeight;
    /* @136 */	jint timeComponentsOffset;
    /* @140 */	jint calendarTopLimit;
    /* @144 */	jint calendarBottomLimit;
    /* @148 */	jint calendarRightLimit;
    /* @152 */	jint dateHilightX;
    /* @156 */	jint dateHilightY;
    /* @160 */	jboolean initialized;
    /* @161 */	jboolean popUpOpen;
    /* @162 */	jboolean amSelected;
    /* @163 */	jboolean amHilighted;
    /* javax/microedition/lcdui/MiniDateEditor */
    /* @164 */	struct Java_javax_microedition_lcdui_DEPopupLayer * JVM_FIELD_CONST dayPopup;
};

struct Java_javax_microedition_lcdui_TextFieldLFImpl_0004TimerKey {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/util/TimerTask */
    /*  @4 */	struct Java_java_lang_Object * JVM_FIELD_CONST lock;
    /*  @8 */	jint state;
    /* @12 */	jlong nextExecutionTime;
    /* @20 */	jlong period;
    /* javax/microedition/lcdui/TextFieldLFImpl$TimerKey */
    /* @28 */	jint key;
    /* @32 */	struct Java_javax_microedition_lcdui_TextFieldLFImpl * JVM_FIELD_CONST this_0440;
};

struct Java_javax_microedition_lcdui_game_GameCanvas {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/Displayable */
    /*  @4 */	jobject_array * JVM_FIELD_CONST commands;
    /*  @8 */	jint numCommands;
    /* @12 */	struct Java_javax_microedition_lcdui_CommandListener * JVM_FIELD_CONST listener;
    /* @16 */	struct Java_java_lang_String * JVM_FIELD_CONST title;
    /* @20 */	struct Java_javax_microedition_lcdui_Ticker * JVM_FIELD_CONST ticker;
    /* @24 */	struct Java_javax_microedition_lcdui_DisplayableLF * JVM_FIELD_CONST displayableLF;
    /* @28 */	jboolean isInFullScreenMode;
    /* @29 */	jbyte ___pad912;
    /* @30 */	jbyte ___pad913;
    /* @31 */	jbyte ___pad914;
    /* javax/microedition/lcdui/Canvas */
    /* @32 */	struct Java_javax_microedition_lcdui_CanvasLF * JVM_FIELD_CONST canvasLF;
    /* @36 */	jboolean suppressKeyEvents;
    /* @37 */	jbyte ___pad915;
    /* @38 */	jbyte ___pad916;
    /* @39 */	jbyte ___pad917;
    /* javax/microedition/lcdui/game/GameCanvas */
    /* @40 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST offscreen_buffer;
};

struct Java_javax_microedition_lcdui_game_Layer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad918;
    /* @22 */	jbyte ___pad919;
    /* @23 */	jbyte ___pad920;
};

struct Java_javax_microedition_lcdui_game_LayerManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/LayerManager */
    /*  @4 */	jint nlayers;
    /*  @8 */	jobject_array * JVM_FIELD_CONST component;
    /* @12 */	jint viewX;
    /* @16 */	jint viewY;
    /* @20 */	jint viewWidth;
    /* @24 */	jint viewHeight;
};

struct Java_javax_microedition_lcdui_game_Sprite {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad921;
    /* @22 */	jbyte ___pad922;
    /* @23 */	jbyte ___pad923;
    /* javax/microedition/lcdui/game/Sprite */
    /* @24 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sourceImage;
    /* @28 */	jint numberFrames;
    /* @32 */	jint_array * JVM_FIELD_CONST frameCoordsX;
    /* @36 */	jint_array * JVM_FIELD_CONST frameCoordsY;
    /* @40 */	jint srcFrameWidth;
    /* @44 */	jint srcFrameHeight;
    /* @48 */	jint_array * JVM_FIELD_CONST frameSequence;
    /* @52 */	jint sequenceIndex;
    /* @56 */	jint dRefX;
    /* @60 */	jint dRefY;
    /* @64 */	jint collisionRectX;
    /* @68 */	jint collisionRectY;
    /* @72 */	jint collisionRectWidth;
    /* @76 */	jint collisionRectHeight;
    /* @80 */	jint t_currentTransformation;
    /* @84 */	jint t_collisionRectX;
    /* @88 */	jint t_collisionRectY;
    /* @92 */	jint t_collisionRectWidth;
    /* @96 */	jint t_collisionRectHeight;
    /* @100 */	jboolean customSequenceDefined;
    /* @101 */	jbyte ___pad924;
    /* @102 */	jbyte ___pad925;
    /* @103 */	jbyte ___pad926;
};

struct Java_javax_microedition_lcdui_game_TiledLayer {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/lcdui/game/Layer */
    /*  @4 */	jint x;
    /*  @8 */	jint y;
    /* @12 */	jint width;
    /* @16 */	jint height;
    /* @20 */	jboolean visible;
    /* @21 */	jbyte ___pad927;
    /* @22 */	jbyte ___pad928;
    /* @23 */	jbyte ___pad929;
    /* javax/microedition/lcdui/game/TiledLayer */
    /* @24 */	jint cellHeight;
    /* @28 */	jint cellWidth;
    /* @32 */	jint rows;
    /* @36 */	jint columns;
    /* @40 */	jobject_array * JVM_FIELD_CONST cellMatrix;
    /* @44 */	struct Java_javax_microedition_lcdui_Image * JVM_FIELD_CONST sourceImage;
    /* @48 */	jint numberOfTiles;
    /* @52 */	jint_array * JVM_FIELD_CONST tileSetX;
    /* @56 */	jint_array * JVM_FIELD_CONST tileSetY;
    /* @60 */	jint_array * JVM_FIELD_CONST anim_to_static;
    /* @64 */	jint numOfAnimTiles;
};

struct Java_javax_microedition_m2g_ScalableGraphics {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/m2g/ScalableGraphics */
    /*  @4 */	struct Java_javax_microedition_lcdui_Graphics * JVM_FIELD_CONST g;
    /*  @8 */	struct Java_com_sun_pisces_GraphicsSurfaceDestination * JVM_FIELD_CONST gsd;
    /* @12 */	jint qualityMode;
    /* @16 */	struct Java_com_sun_perseus_model_DirtyAreaManager * JVM_FIELD_CONST dirtyAreaManager;
    /* @20 */	jfloat alpha;
    /* @24 */	struct Java_com_sun_pisces_NativeSurface * JVM_FIELD_CONST offscreen;
    /* @28 */	struct Java_com_sun_pisces_PiscesRenderer * JVM_FIELD_CONST pr;
    /* @32 */	jint offscreenWidth;
    /* @36 */	jint offscreenHeight;
    /* @40 */	struct Java_com_sun_perseus_j2d_RenderGraphics * JVM_FIELD_CONST rg;
};

struct Java_javax_microedition_media_Manager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/media/Manager */
};

struct Java_javax_microedition_midlet_MIDletTunnelImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/midlet/MIDletTunnelImpl */
};

struct Java_javax_microedition_pki_UserCredentialManager {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/pki/UserCredentialManager */
};

struct Java_javax_microedition_rms_RecordComparator {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordComparator */
};

struct Java_javax_microedition_rms_RecordEnumeration {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordEnumeration */
};

struct Java_javax_microedition_rms_RecordFilter {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordFilter */
};

struct Java_javax_microedition_rms_RecordListener {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordListener */
};

struct Java_javax_microedition_rms_RecordEnumerationImpl {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/rms/RecordEnumerationImpl */
    /*  @4 */	struct Java_javax_microedition_rms_RecordStore * JVM_FIELD_CONST recordStore;
    /*  @8 */	struct Java_javax_microedition_rms_RecordFilter * JVM_FIELD_CONST filter;
    /* @12 */	struct Java_javax_microedition_rms_RecordComparator * JVM_FIELD_CONST comparator;
    /* @16 */	jint index;
    /* @20 */	jint_array * JVM_FIELD_CONST records;
    /* @24 */	jboolean keepEnumUpdated;
    /* @25 */	jbyte ___pad930;
    /* @26 */	jbyte ___pad931;
    /* @27 */	jbyte ___pad932;
};

struct Java_javax_microedition_rms_RecordStoreNotOpenException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* javax/microedition/rms/RecordStoreException */
    /* javax/microedition/rms/RecordStoreNotOpenException */
};

struct Java_javax_microedition_securityservice_CMSMessageSignatureService {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/microedition/securityservice/CMSMessageSignatureService */
};

struct Java_javax_obex_ResponseCodes {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/obex/ResponseCodes */
};

struct Java_javax_xml_parsers_FactoryConfigurationError {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Error */
    /* javax/xml/parsers/FactoryConfigurationError */
};

struct Java_javax_xml_rpc_NamespaceConstants {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/rpc/NamespaceConstants */
};

struct Java_javax_xml_rpc_Stub {
    /* java/lang/Object */
	void * __do_not_use__;
    /* javax/xml/rpc/Stub */
};

struct Java_org_xml_sax_SAXNotSupportedException {
    /* java/lang/Object */
	void * __do_not_use__;
    /* java/lang/Throwable */
    /*  @4 */	struct Java_java_lang_String * JVM_FIELD_CONST detailMessage;
    /*  @8 */	struct Java_java_lang_Object * JVM_FIELD_CONST backtrace;
    /* java/lang/Exception */
    /* org/xml/sax/SAXException */
    /* org/xml/sax/SAXNotSupportedException */
};

#ifdef __cplusplus
}
#endif

#endif /*_ROM_STRUCTS_H_*/
