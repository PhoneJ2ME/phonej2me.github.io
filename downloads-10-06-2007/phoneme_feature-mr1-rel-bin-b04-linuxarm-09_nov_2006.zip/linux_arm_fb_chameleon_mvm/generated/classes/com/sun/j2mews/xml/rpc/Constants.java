
/**
 * Copyright 1990-2006 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * These are constant defines both in native and Java layers.
 * NOTE: DO NOT EDIT. THIS FILE IS GENERATED. If you want to 
 * edit it, you need to modify the corresponding XML files.
 *
 * Patent pending.
 */
package com.sun.j2mews.xml.rpc;

public class Constants {

    /**
     * Maximal number of 'Object moved' http responses that we will handle
     */
    public final static int MAX_REDIRECT_ATTEMPTS = 10;

}
