/*
 *
 * Copyright  1990-2006 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation. 
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt). 
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA 
 * 
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa
 * Clara, CA 95054 or visit www.sun.com if you need additional
 * information or have any questions. 
 */
package com.sun.midp.jsr082;

import com.sun.midp.security.SecurityToken;
import com.sun.midp.security.ImplicitlyTrustedClass;

/**
 * A utility class that initializes internal security token for 
 * JSR 82 implemenation classes. Modify this class instead of  
 * com.sun.midp.security.SecurityInitializer each time another 
 * JSR 82 implementation class requires initializing security token.
 */
public final class SecurityInitializer implements ImplicitlyTrustedClass {

    /**
     * Ensures that security initialization is done only once.
     */
    private static boolean initialized = false;

    /**
     * Initializes system security token for JSR 82 classes that require it.
     * That security token allows performing actions that a normal MIDlet 
     * suite cannot.
     *
     * @param token the system security token.
     */
    public synchronized void initSecurityToken(SecurityToken token) {
        
        if (initialized) {
            throw new SecurityException();
        }
        
        initialized = true;
        
        // Add security token initializations here
        
        
        com.sun.midp.jsr82emul.EmulationServer.initSecurityToken(token);
        com.sun.midp.jsr82emul.EmulationClient.initSecurityToken(token);
        com.sun.midp.jsr82emul.NotifierEmul.initSecurityToken(token);
        
        
        com.sun.kvem.jsr082.bluetooth.SDP.initSecurityToken(token);

        // Initialize security token for OBEX over different transports
        com.sun.midp.io.j2me.tcpobex.Protocol.initSecurityToken(token);
        com.sun.midp.io.j2me.btgoep.Protocol.initSecurityToken(token);
        


    }
}
