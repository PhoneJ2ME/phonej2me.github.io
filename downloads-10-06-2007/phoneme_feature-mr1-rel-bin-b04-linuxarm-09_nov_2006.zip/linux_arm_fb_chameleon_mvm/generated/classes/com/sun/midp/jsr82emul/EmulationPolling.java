/*
 *
 * Copyright  1990-2006 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation. 
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt). 
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA 
 * 
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa
 * Clara, CA 95054 or visit www.sun.com if you need additional
 * information or have any questions. 
 */
package com.sun.midp.jsr82emul;





/**
 * Performs polling requests for emulation and passes them for
 * processing. It is launched only if there are no active instances
 * even in other isolates.
 */
public class EmulationPolling implements Runnable {
    /** Thread that processes emulation requests. */
    private static Thread thread;
    /** Identifies if this instance performs polling and processing. */
    private static boolean started = false;

    /** Size of buffer for requests. */
    private static final int REQ_BUF_SIZE = Const.DEFAULT_QUEUE_SIZE;
    /** Current requests queue length. */
    private int length;
    /** Buffer that contain current requests queue. */
    private byte[] requestBuf = new byte[REQ_BUF_SIZE];
    /** Wraps requests queue for easy processing. */
    private BytePack request = new BytePack();

    /** Constructs the only instance. */
    private EmulationPolling() {}

    /** Starts polling unless it is already running. */
    public synchronized static void start() {
        if (!started) {
            started = true;
            if (start0()) {
                startPolling();
            }
        }
    }

    /** Starts polling. */
    private static void startPollingThread() {
        thread = new Thread (new EmulationPolling());
        thread.setPriority(
            (Thread.MAX_PRIORITY + Thread.NORM_PRIORITY) / 2);
        thread.start();
    }


    /** Starts polling in separate isolate. */
    





































    private static void startPolling() {
        startPollingThread();
    }
    

    /** Performs polling in a separate thread. Implements Runnable. */
    public void run() {
        while (true) {
            getRequest();
            if (length > 0) {
                request.reset(requestBuf);

                while (length > request.offset) {
                    try{
                        MainCaller.getInstance().process(request);
                    } catch (RuntimeException e) {
                        Log.log("Unexpected request to emulation " + e);
                        // thurther processing current request
                        // has no sense
                        break;
                    }
                }

            } else {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    // nothing to do
                }
            }
        }
    }

    /** Clears native resources allocated. */
    private native void finalize();

    /**
     * Checks if polling is aready running.
     * @return <code>true</code> if polling is running in some isolate,
     *         <code>false</code> otherwize
     */
    private static native boolean start0();

    /**
     * Retrieves requests for emulation queued in native code.
     * Resets <code>requestBuf</code> to either new byte array containing
     *        requests or <code>null</code> if there are no requests.
     */
    private native void getRequest();
}
