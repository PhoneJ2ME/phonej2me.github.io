// This file is auto-generated. Don't edit!
package com.sun.midp.l10n;
abstract class LocalizedStringsBase {
    native static String getContent(int index);
}
