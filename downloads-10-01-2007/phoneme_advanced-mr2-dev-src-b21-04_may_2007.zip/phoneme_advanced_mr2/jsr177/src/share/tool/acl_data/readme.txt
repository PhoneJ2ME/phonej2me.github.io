
 Copyright  2007  Sun Microsystems, Inc. All rights reserved.

This directory contains a project for the ACL data encoder.

This utility is intended to help to tranclate ACL data from text format to 
ANSI 1.0 DER encoded format.

Format of the input text file is described in the HowToUseACL.txt file.
Input file "acl_0" should be placed in the current directory.

Output files, containig DER encoded information will be generated in the 
<output_dir>/jsr177/acl_data/files directory.
This directory will contain files of the file system that could be downloaded into 
a card file system.
