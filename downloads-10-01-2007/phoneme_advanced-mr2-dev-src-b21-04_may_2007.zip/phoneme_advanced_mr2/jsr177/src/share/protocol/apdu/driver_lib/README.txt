
 Copyright  2007  Sun Microsystems, Inc. All rights reserved.

This directory should contain a third party library with the card device driver
which must export the native interface defined in
<JavaCall_Dir>/include/jsr177_satsa/javacall_carddevice.h.

See the Porting Guide for details.
