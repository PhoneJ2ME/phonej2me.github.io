/*
 *
 * Copyright  1990-2006 Sun Microsystems, Inc. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation. 
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt). 
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA 
 * 
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa
 * Clara, CA 95054 or visit www.sun.com if you need additional
 * information or have any questions. 
 */
package com.sun.midp.midletsuite;

import java.io.DataInputStream;
import java.io.IOException;

import javax.microedition.io.Connector;

import com.sun.midp.io.j2me.storage.RandomAccessStream;

/**
 * Information about a MIDlet that is to be installed.
 */
public class InstallInfo {

    /** URL of the JAD. */
    String jadUrl;

    /** URL of the JAR. */
    String jarUrl;

    /**
     * Authorization path, staring with the most trusted CA authorizing
     * the suite, for secure installing.
     */
    String[] authPath;

    /** Security domain of the suite, for secure installing. */
    String domain;

    /** Flag for trusted suites. If true the system trust icon is displayed. */
    boolean trusted;

    /** Hash value of the suite with preverified classes */
    protected byte[] verifyHash;

    /** MIDlet Suite. */
    private MIDletSuiteImpl midletSuite;

    /** The suite's id. */
    String id;

    /**
     * Package private for constructor for InstallInfo to be called
     * when storing a new suite.
     */
    private InstallInfo() {
    }

    /**
     * Package private for constructor for InstallInfo.
     *
     * @param theMidletSuite MIDletSuite object
     */
    InstallInfo(MIDletSuiteImpl theMidletSuite, String theId) {
        midletSuite = theMidletSuite;
        id = theId;
    }

    /**
     * Gets the JAD URL of the suite. This is only for the installer.
     *
     * @return URL of the JAD can be null
     */
    public String getJadUrl() {
        return jadUrl;
    }

    /**
     * Gets the JAR URL of the suite. This is only for the installer.
     *
     * @return URL of the JAR, never null, even in development environments
     */
    public String getJarUrl() {
        return jarUrl;
    }

    /**
     * Gets the name of CA that authorized this suite.
     *
     * @return name of a CA or null if the suite was not signed
     */
    public String getCA() {
        if (authPath == null || authPath.length == 0) {
            return null;
        }

        return authPath[0];
    }

    /**
     * Gets the authoriztion path of this suite. The path starts with
     * the most trusted CA that authorized this suite.
     *
     * @return array of CA names or null if the suite was not signed
     */
    public String[] getAuthPath() {
        if (authPath == null) {
            return authPath;
        }

        String[] result = new String[authPath.length];

        System.arraycopy(authPath, 0, result, 0, authPath.length);

        return result;
    }

    /**
     * Gets the security domain of this suite.
     *
     * @return name of a security domain
     */
    public String getSecurityDomain() {
        return domain;
    }

    /**
     * Indicates if this suite is trusted.
     * (not to be confused with a domain named "trusted",
     * this is used to determine if a trusted symbol should be displayed
     * to the user and not used for permissions)
     *
     * @return true if the suite is trusted false if not
     */
    public boolean isTrusted() {
        return trusted;
    }


    /**
     * Gets hash value for the suite with all classes successfully
     * verified during the suite installation, otherwise null value
     * will be returned
     *
     * @return suite hash value
     */
    public final byte[] getVerifyHash() {
        return verifyHash;
    }

    /**
     * Gets the URL that the suite was downloaded from.
     *
     * @return URL of the JAD, or JAR for a JAR only suite, never null,
     * even in development environments
     */
    public String getDownloadUrl() {
        String url = getJadUrl();

        if (url != null) {
            return url;
        }

        return getJarUrl();
    }

    /**
     * Gets push setting for interrupting other MIDlets.
     * Reuses the Permissions.
     *
     * @return push setting for interrupting MIDlets the value
     *        will be permission level from {@link Permissions}
     */
    public int getPushInterruptSetting() {
        return midletSuite.getPushInterruptSetting();
    }

    /**
     * Gets list of permissions for this suite.
     *
     * @return array of permissions from {@link Permissions}
     */
    public byte[] getPermissions() {
        return midletSuite.getPermissions();
    }

    /**
     * Gets the unique ID of the suite.
     *
     * @return suite ID
     */
    public String getID() {
        return midletSuite.getID();
    }

    /**
     * Populates this InstallInfo instance from persistent store.
     *
     * @throws IOException if the information cannot be read
     */
    native void load() throws IOException;

    /**
     * Saves the Suite Install Info from persistent store
     */
    // native void save();
}
